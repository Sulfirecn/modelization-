from __future__ import annotations

"""C题问题三：SAA-MPC 日内滚动购电模型。

核心思路：
1) 0:00 制定初始合同购电计划；
2) 6:00 / 12:00 / 18:00 获得新的未来24小时光伏整点预报；
3) 负荷采用严格 walk-forward 的 7/14/21 日同刻加权预测；
4) 使用最近28个完整日的净负荷预测残差曲线，并用 k-medoids 缩减为 K=7 个场景；
5) 采用 SAA + MPC 滚动线性规划；
6) 初始计划按 p 计费；上调差额按 1.5p；下调取消部分按 0.5p 价值退回；
7) 实际供电不足时按 5p 紧急购电；
8) 主推荐策略为 0:00 + 6:00 + 12:00，同时可比较 0、0+6、0+6+12、0+6+12+18。
9) 6000 kWh仅作为2025-01-01初始状态，之后SOC严格跨日连续；
10) 每次日内更新均采用固定48小时滚动窗口，并在窗口末端计入剩余电量价值。

每天0:00制定计划；官方模板记录0:10-0:20至次日0:00-0:10的144个执行区间。
官方模板若存在则尽量按模板写入；否则自动生成结构化 result3.xlsx。

运行：python 问题3/problem3.py
回测并绘图：python 问题3/problem3.py --plot
仅用已有Excel绘图：python 问题3/problem3.py --plot-only
"""

import argparse
import math
import re
import shutil
import sys
import warnings
import unicodedata
from dataclasses import dataclass
from datetime import date, datetime, time
from pathlib import Path
from typing import Iterable

sys.dont_write_bytecode = True

import numpy as np
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from scipy.optimize import linprog, minimize
from scipy.sparse import csr_matrix, lil_matrix


BASE_DIR = Path(__file__).resolve().parent
PERIODS = 144
DT_HOURS = 1.0 / 6.0
BLOCK_SIZE = 24
RELEASES = (0, 6, 12, 18)
RECOMMENDED_UPDATES = (6, 12)
POLICIES = {
    "only_0": (),
    "0+6": (6,),
    "0+6+12": (6, 12),
    "0+6+12+18": (6, 12, 18),
}
POLICY_LABELS = {
    "only_0": "仅0:00",
    "0+6": "0:00+6:00",
    "0+6+12": "0:00+6:00+12:00",
    "0+6+12+18": "0:00+6:00+12:00+18:00",
}
BLOCK_LABELS = [
    "0:00-4:00",
    "4:00-8:00",
    "8:00-12:00",
    "12:00-16:00",
    "16:00-20:00",
    "20:00-24:00",
]
EPS = 1e-8
EMERGENCY_THRESHOLD = 1e-6


@dataclass(frozen=True)
class ModelParameters:
    capacity_min: float = 1200.0
    capacity_max: float = 10800.0
    initial_soc: float = 6000.0
    lookahead_days: int = 1
    terminal_value_scale: float = 1.0
    max_power_kw: float = 5000.0
    charge_efficiency: float = 0.90
    discharge_efficiency: float = 0.90
    emergency_multiplier: float = 5.0
    increase_multiplier: float = 1.5
    cancellation_refund_multiplier: float = 0.5
    residual_days: int = 28
    k_scenarios: int = 7
    load_weight_window: int = 28

    @property
    def max_energy_per_slot(self) -> float:
        return self.max_power_kw * DT_HOURS


def terminal_energy_value(price: np.ndarray, params: ModelParameters) -> float:
    """滚动窗口末端每剩余1 kWh电量的近似经济价值（元/kWh）。"""
    return float(
        params.terminal_value_scale
        * params.discharge_efficiency
        * np.median(np.asarray(price, dtype=float))
    )


@dataclass(frozen=True)
class ProblemData:
    dates: list[date]
    raw_time_labels: list[object]
    price: np.ndarray                 # (144,), yuan/kWh
    load_kw: np.ndarray               # (days,144)
    pv_kw: np.ndarray                 # (days,144)
    pv_hourly: dict[date, dict[int, np.ndarray]]  # day -> release -> 24 hourly forecasts


@dataclass(frozen=True)
class ScenarioSet:
    residual_kw: np.ndarray           # (K,144), medoid net-load residual curves
    probabilities: np.ndarray         # (K,)
    medoid_history_days: tuple[int, ...]
    history_size: int


@dataclass(frozen=True)
class StagePlan:
    grid: np.ndarray                  # full 144 current contract version
    charge: np.ndarray                # full 144 storage plan
    discharge: np.ndarray             # full 144 storage plan
    primary_objective: float
    expected_emergency_cost: float
    used_secondary: bool
    scenario_count: int


@dataclass(frozen=True)
class DayRun:
    date_value: date
    policy_key: str
    initial_grid: np.ndarray          # 0:00 plan version
    final_grid: np.ndarray            # final actually applicable contract version
    executed_charge: np.ndarray       # contract window 144
    executed_discharge: np.ndarray
    emergency: np.ndarray
    waste: np.ndarray
    soc: np.ndarray                   # 145 states, contract start 0:10 -> next day 0:10
    adjustment_plus: np.ndarray       # cumulative actual up-adjustment by slot
    adjustment_minus: np.ndarray      # cumulative actual down-adjustment by slot
    initial_plan_cost: float
    adjustment_net_cost: float
    emergency_cost: float
    total_cost: float
    emergency_kwh: float
    waste_kwh: float
    load_weights: np.ndarray


def discover_input(parent: Path, exact_name: str, prefix: str) -> Path:
    exact = parent / exact_name
    if exact.exists():
        return exact
    candidates = sorted(parent.glob(f"{prefix}*.xlsx"))
    candidates = [p for p in candidates if not p.name.startswith("~$")]
    if not candidates:
        raise FileNotFoundError(
            f"在 {parent} 中找不到 {exact_name}，也没有匹配 {prefix}*.xlsx 的文件。"
        )
    return candidates[0]


def contract_labels() -> list[str]:
    """问题三官方模板口径：0:10-0:20 ... 次日0:00-0:10。"""
    labels: list[str] = []
    for i in range(PERIODS):
        start = 10 + i * 10
        end = start + 10
        labels.append(f"{format_clock(start)}-{format_clock(end)}")
    return labels


def format_clock(minutes: int) -> str:
    if minutes == 1440:
        return "0:00+1"
    if minutes == 1450:
        return "0:10+1"
    if minutes > 1440:
        h, m = divmod(minutes - 1440, 60)
        return f"{h}:{m:02d}+1"
    h, m = divmod(minutes, 60)
    return f"{h}:{m:02d}"


def natural_interval_label(slot: int) -> str:
    start = slot * 10
    end = (slot + 1) * 10
    return f"{format_clock(start)}-{format_clock(end)}"


def parse_date_like(value: object) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", text)
    if m:
        return date(*(int(x) for x in m.groups()))
    raise ValueError(f"无法识别日期：{value!r}")


def parse_release_hour(value: object) -> int:
    if isinstance(value, datetime):
        return value.hour
    if isinstance(value, time):
        return value.hour
    text = str(value).strip()
    m = re.match(r"(\d{1,2}):", text)
    if not m:
        raise ValueError(f"无法识别预报时刻：{value!r}")
    return int(m.group(1))


def read_price(path: Path) -> tuple[list[object], np.ndarray]:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    wb.close()
    if len(rows) != PERIODS:
        raise ValueError(f"附件1应有144个时段，实际读取 {len(rows)}。")
    labels = [r[0] for r in rows]
    price = np.asarray([r[1] for r in rows], dtype=float)
    if not np.all(np.isfinite(price)) or np.any(price < 0):
        raise ValueError("附件1电价包含空值、非数值或负数。")
    return labels, price


def read_actual_year(path: Path) -> tuple[list[date], list[object], np.ndarray, np.ndarray]:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    required = ["小区负载", "光伏发电实际功率"]
    for name in required:
        if name not in wb.sheetnames:
            wb.close()
            raise ValueError(f"附件2缺少工作表：{name}")

    load_rows = list(wb[required[0]].iter_rows(values_only=True))
    pv_rows = list(wb[required[1]].iter_rows(values_only=True))
    wb.close()

    if len(load_rows) != len(pv_rows):
        raise ValueError("附件2负载和光伏行数不一致。")
    if len(load_rows[0]) != PERIODS + 1 or len(pv_rows[0]) != PERIODS + 1:
        raise ValueError("附件2每行应为1列日期+144个十分钟值。")

    time_labels = list(load_rows[0][1:])
    dates = [parse_date_like(r[0]) for r in load_rows[1:]]
    pv_dates = [parse_date_like(r[0]) for r in pv_rows[1:]]
    if dates != pv_dates:
        raise ValueError("附件2负载与光伏日期不一致。")

    load = np.asarray([r[1:] for r in load_rows[1:]], dtype=float)
    pv = np.asarray([r[1:] for r in pv_rows[1:]], dtype=float)
    if load.shape[1] != PERIODS or pv.shape[1] != PERIODS:
        raise ValueError("附件2数据列数不是144。")
    if not (np.all(np.isfinite(load)) and np.all(np.isfinite(pv))):
        raise ValueError("附件2存在空值或非数值。")
    if np.any(load < 0) or np.any(pv < 0):
        raise ValueError("附件2负载或光伏存在负数。")
    return dates, time_labels, load, pv


def read_pv_hourly_forecasts(path: Path) -> dict[date, dict[int, np.ndarray]]:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    wb.close()

    result: dict[date, dict[int, np.ndarray]] = {}
    current_date: date | None = None
    for row in rows:
        if row[0] not in (None, ""):
            current_date = parse_date_like(row[0])
        if current_date is None:
            continue
        release = parse_release_hour(row[1])
        values = np.asarray(row[2:26], dtype=float)
        if values.size != 24:
            raise ValueError(f"附件3 {current_date} {release}:00 不是24小时预报。")
        if not np.all(np.isfinite(values)):
            raise ValueError(f"附件3 {current_date} {release}:00 含空值或非数值。")
        result.setdefault(current_date, {})[release] = np.clip(values, 0.0, None)

    return result


def load_problem_data(price_path: Path, actual_path: Path, pv_forecast_path: Path) -> ProblemData:
    _, price = read_price(price_path)
    dates, labels, load_kw, pv_kw = read_actual_year(actual_path)
    pv_hourly = read_pv_hourly_forecasts(pv_forecast_path)
    missing = [d for d in dates if d not in pv_hourly]
    if missing:
        warnings.warn(f"附件3缺少 {len(missing)} 个日期的光伏预报；涉及日期将无法求解。")
    return ProblemData(
        dates=dates,
        raw_time_labels=labels,
        price=price,
        load_kw=load_kw,
        pv_kw=pv_kw,
        pv_hourly=pv_hourly,
    )


# 预测：负荷 walk-forward + 光伏日内更新插值
def fit_simplex_weights(X: np.ndarray, y: np.ndarray) -> np.ndarray:
    """三维 simplex 约束最小二乘的快速精确枚举解。

    求 min ||Xw-y||^2, s.t. w>=0, sum(w)=1。
    只有3个权重，因此检查内部解、三条边和三个顶点即可，
    比逐日调用通用SLSQP快很多。
    """
    if X.size == 0 or y.size == 0:
        return np.full(3, 1.0 / 3.0)

    candidates: list[np.ndarray] = []
    H = X.T @ X
    b = X.T @ y
    KKT = np.block([[H, np.ones((3, 1))], [np.ones((1, 3)), np.zeros((1, 1))]])
    rhs = np.r_[b, 1.0]
    try:
        sol = np.linalg.lstsq(KKT, rhs, rcond=None)[0][:3]
        if np.all(sol >= -1e-10):
            sol = np.clip(sol, 0.0, None)
            candidates.append(sol / sol.sum())
    except np.linalg.LinAlgError:
        pass

    # 每条边：第k个权重=0，另外两个之和=1。
    for k in range(3):
        ij = [i for i in range(3) if i != k]
        a, bidx = ij
        # w_a=t, w_b=1-t，转成一维最小二乘并截断到[0,1]。
        z = X[:, a] - X[:, bidx]
        target = y - X[:, bidx]
        denom = float(z @ z)
        t = float(z @ target / denom) if denom > 1e-14 else 0.5
        t = min(1.0, max(0.0, t))
        w = np.zeros(3, dtype=float)
        w[a] = t
        w[bidx] = 1.0 - t
        candidates.append(w)

    candidates.extend([np.eye(3)[i] for i in range(3)])

    best = min(candidates, key=lambda w: float(np.sum((X @ w - y) ** 2)))
    return np.asarray(best, dtype=float)


def build_load_forecasts(data: ProblemData, params: ModelParameters) -> tuple[np.ndarray, np.ndarray]:
    """为全年每一天预计算严格 walk-forward 负荷预测与当天权重。"""
    n_days = len(data.dates)
    pred = np.full_like(data.load_kw, np.nan, dtype=float)
    weights = np.full((n_days, 3), np.nan, dtype=float)

    for d in range(n_days):
        if d < 21:
            continue
        train_start = max(21, d - params.load_weight_window)
        train_days = list(range(train_start, d))

        if train_days:
            X_parts = []
            y_parts = []
            for j in train_days:
                Xj = np.column_stack([
                    data.load_kw[j - 7],
                    data.load_kw[j - 14],
                    data.load_kw[j - 21],
                ])
                X_parts.append(Xj)
                y_parts.append(data.load_kw[j])
            X = np.vstack(X_parts)
            y = np.concatenate(y_parts)
            w = fit_simplex_weights(X, y)
        else:
            w = np.full(3, 1.0 / 3.0)

        weights[d] = w
        pred[d] = (
            w[0] * data.load_kw[d - 7]
            + w[1] * data.load_kw[d - 14]
            + w[2] * data.load_kw[d - 21]
        )
        pred[d] = np.clip(pred[d], 0.0, None)

    return pred, weights


def observed_pv_at_release(data: ProblemData, day_idx: int, release_hour: int) -> float:
    """发布时刻已经观测到的实际光伏功率，作为线性插值左端点。"""
    if release_hour == 0:
        # 夜间通常为0；若前一日存在，则取前一日最后一个观测更连续。
        if day_idx > 0:
            return float(max(0.0, data.pv_kw[day_idx - 1, -1]))
        return 0.0
    idx = release_hour * 6 - 1  # 6:00 对应第36个原始时点
    return float(max(0.0, data.pv_kw[day_idx, idx]))


def interpolate_pv_forecast(
    data: ProblemData,
    day_idx: int,
    release_hour: int,
) -> np.ndarray:
    """把附件3的未来24个整点预报线性插值到问题三144个合同格。"""
    d = data.dates[day_idx]
    releases = data.pv_hourly.get(d, {})
    if release_hour not in releases:
        raise ValueError(f"附件3缺少 {d} {release_hour}:00 预报。")

    hourly = releases[release_hour]
    release_min = release_hour * 60
    anchor = observed_pv_at_release(data, day_idx, release_hour)
    x = np.asarray([release_min] + [release_min + 60 * k for k in range(1, 25)], dtype=float)
    y = np.concatenate([[anchor], hourly.astype(float)])

    # 合同模板时点：0:10,0:20,...,24:00。数值直接与模板144格对齐。
    q = np.arange(1, PERIODS + 1, dtype=float) * 10.0
    forecast = np.interp(q, x, y)
    forecast[q < release_min] = np.nan  # 过去时段不使用新预报
    return np.clip(forecast, 0.0, None)


# 场景生成与 k-medoids 场景缩减
def pairwise_euclidean(X: np.ndarray) -> np.ndarray:
    sq = np.sum(X * X, axis=1, keepdims=True)
    dist2 = np.maximum(sq + sq.T - 2.0 * X @ X.T, 0.0)
    return np.sqrt(dist2)


def k_medoids(X: np.ndarray, k: int, max_iter: int = 50) -> tuple[np.ndarray, np.ndarray]:
    """小样本确定性 PAM 风格 k-medoids；返回 medoid 行号与簇标签。"""
    n = X.shape[0]
    if n == 0:
        raise ValueError("k-medoids输入为空。")
    k = max(1, min(k, n))
    D = pairwise_euclidean(X)

    # 初始化：先取总距离最小的中心，再依次取离已有中心最远的点。
    medoids = [int(np.argmin(D.sum(axis=1)))]
    while len(medoids) < k:
        nearest = np.min(D[:, medoids], axis=1)
        nearest[medoids] = -1.0
        medoids.append(int(np.argmax(nearest)))
    medoids = np.asarray(medoids, dtype=int)

    labels = np.argmin(D[:, medoids], axis=1)
    for _ in range(max_iter):
        new_medoids = medoids.copy()
        for c in range(k):
            members = np.where(labels == c)[0]
            if members.size == 0:
                continue
            sub = D[np.ix_(members, members)]
            new_medoids[c] = members[int(np.argmin(sub.sum(axis=1)))]
        new_medoids = np.asarray(sorted(set(new_medoids.tolist())), dtype=int)
        # 极少数情况下簇合并导致中心数下降，补最远点。
        while new_medoids.size < k:
            nearest = np.min(D[:, new_medoids], axis=1)
            nearest[new_medoids] = -1.0
            candidate = int(np.argmax(nearest))
            new_medoids = np.append(new_medoids, candidate)
        new_labels = np.argmin(D[:, new_medoids], axis=1)
        if np.array_equal(np.sort(medoids), np.sort(new_medoids)) and np.array_equal(labels, new_labels):
            medoids = new_medoids
            labels = new_labels
            break
        medoids = new_medoids
        labels = new_labels

    return medoids, labels


def build_scenario_set(
    data: ProblemData,
    load_forecast_kw: np.ndarray,
    target_day: int,
    release_hour: int,
    params: ModelParameters,
) -> ScenarioSet:
    """最近28个完整日的净负荷残差曲线 -> k-medoids代表场景。"""
    start_hist = max(21, target_day - params.residual_days)
    history_days: list[int] = []
    residuals: list[np.ndarray] = []
    active_start = release_hour * 6

    for h in range(start_hist, target_day):
        if not np.all(np.isfinite(load_forecast_kw[h])):
            continue
        try:
            pv_pred = interpolate_pv_forecast(data, h, release_hour)
        except (ValueError, KeyError):
            continue
        forecast_net = load_forecast_kw[h] - pv_pred
        actual_net = data.load_kw[h] - data.pv_kw[h]
        residual = actual_net - forecast_net
        # 过去段的 NaN 不参与距离；置0即可，因为优化只取 active_start 之后。
        residual[:active_start] = 0.0
        if not np.all(np.isfinite(residual[active_start:])):
            continue
        history_days.append(h)
        residuals.append(residual)

    if not residuals:
        # 理论上默认2月1日之后不会进入这里；保守回退为零残差场景。
        return ScenarioSet(
            residual_kw=np.zeros((1, PERIODS), dtype=float),
            probabilities=np.ones(1, dtype=float),
            medoid_history_days=(),
            history_size=0,
        )

    R = np.vstack(residuals)
    segment = R[:, active_start:]
    # 为避免全年负荷量级造成数值尺度问题，按该历史池的全局标准差标准化距离。
    scale = float(np.std(segment))
    X = segment / scale if scale > 1e-9 else segment.copy()
    medoid_rows, labels = k_medoids(X, params.k_scenarios)

    probs = np.asarray([(labels == c).mean() for c in range(len(medoid_rows))], dtype=float)
    medoid_days = tuple(history_days[i] for i in medoid_rows)
    return ScenarioSet(
        residual_kw=R[medoid_rows],
        probabilities=probs,
        medoid_history_days=medoid_days,
        history_size=len(history_days),
    )


def build_tail_net_forecast(
    data: ProblemData,
    day_idx: int,
    lookahead_days: int,
    fallback_net_kw: np.ndarray,
    start_slot: int = 0,
) -> np.ndarray:
    """仅用已知历史日构造固定长度的跨日前视净负荷。

    lookahead_days=1时，无论在0/6/12/18时更新，总优化长度均保持288格，
    即从当前更新时刻向前滚动48小时。前视只用于决策，不进入当天现金结算。
    """
    days = max(0, int(lookahead_days))
    if days == 0:
        return np.empty(0, dtype=float)
    if not 0 <= int(start_slot) < PERIODS:
        raise ValueError("start_slot必须位于[0,143]。")
    fallback = np.asarray(fallback_net_kw, dtype=float)
    if fallback.shape != (PERIODS,) or not np.all(np.isfinite(fallback)):
        raise ValueError("跨日前视fallback净负荷必须是144个有限值。")

    tail_slots = days * PERIODS + int(start_slot)
    required_future_days = days + (1 if start_slot else 0)
    pieces: list[np.ndarray] = []
    for step in range(1, required_future_days + 1):
        target_idx = day_idx + step
        hist_idx = [
            target_idx - lag
            for lag in (7, 14, 21)
            if 0 <= target_idx - lag <= day_idx
        ]
        if hist_idx:
            net_hat = (
                np.mean(data.load_kw[hist_idx], axis=0)
                - np.mean(data.pv_kw[hist_idx], axis=0)
            )
        else:
            net_hat = fallback.copy()
        pieces.append(np.asarray(net_hat, dtype=float))
    return np.concatenate(pieces)[:tail_slots]


# SAA-MPC 线性规划
def solve_stage(
    *,
    price: np.ndarray,
    base_net_kw: np.ndarray,
    scenarios: ScenarioSet,
    params: ModelParameters,
    start_slot: int,
    start_soc: float,
    previous_grid: np.ndarray | None,
    previous_charge: np.ndarray | None,
    previous_discharge: np.ndarray | None,
    tail_net_kw: np.ndarray | None = None,
) -> StagePlan:
    """求当前发布时刻起的固定滚动窗口。

    previous_grid=None 表示 0:00 初始计划；否则为日内调整。
    past [0,start_slot) 原样保留；下一日辅助变量只影响决策，不写入结果。
    """
    n = PERIODS - start_slot
    if n <= 0:
        raise ValueError("start_slot越界。")
    active = slice(start_slot, PERIODS)
    p = price[active]

    base = np.asarray(base_net_kw[active], dtype=float)
    R = np.asarray(scenarios.residual_kw[:, active], dtype=float)
    probs = np.asarray(scenarios.probabilities, dtype=float)
    K = R.shape[0]
    scenario_net_kwh = (base[None, :] + R) * DT_HOURS

    tail = (
        np.asarray(tail_net_kw, dtype=float).reshape(-1)
        if tail_net_kw is not None else np.empty(0, dtype=float)
    )
    if tail.size and not np.all(np.isfinite(tail)):
        raise ValueError("tail_net_kw含NaN/Inf。")
    m = int(tail.size)
    tail_net_kwh = tail * DT_HOURS
    tail_price = np.resize(np.asarray(price, dtype=float), m) if m else np.empty(0)

    is_update = previous_grid is not None

    # 变量布局：G,C,D,S(0..n), [A+,A-], 每场景 H,W
    g0 = 0
    c0 = g0 + n
    d0 = c0 + n
    s0 = d0 + n
    cursor = s0 + n + 1
    if is_update:
        ap0 = cursor
        am0 = ap0 + n
        cursor = am0 + n
    else:
        ap0 = am0 = -1
    scenario_size = 2 * n
    h_starts = []
    w_starts = []
    for _ in range(K):
        h_starts.append(cursor)
        w_starts.append(cursor + n)
        cursor += scenario_size

    if m:
        tg0 = cursor
        tc0 = tg0 + m
        td0 = tc0 + m
        th0 = td0 + m
        tw0 = th0 + m
        ts0 = tw0 + m
        cursor = ts0 + m + 1
    else:
        tg0 = tc0 = td0 = th0 = tw0 = ts0 = -1
    n_vars = cursor

    eq_rows = K * n + n + (n if is_update else 0)
    if m:
        eq_rows += 1 + 2 * m
    Aeq = lil_matrix((eq_rows, n_vars), dtype=float)
    beq = np.zeros(eq_rows, dtype=float)
    row = 0

    # 各场景供需平衡：G + H + D - C - W = 净负荷
    for k in range(K):
        h0 = h_starts[k]
        w0 = w_starts[k]
        for i in range(n):
            Aeq[row, g0 + i] = 1.0
            Aeq[row, d0 + i] = 1.0
            Aeq[row, c0 + i] = -1.0
            Aeq[row, h0 + i] = 1.0
            Aeq[row, w0 + i] = -1.0
            beq[row] = scenario_net_kwh[k, i]
            row += 1

    # SOC动力学
    for i in range(n):
        Aeq[row, s0 + i] = -1.0
        Aeq[row, s0 + i + 1] = 1.0
        Aeq[row, c0 + i] = -params.charge_efficiency
        Aeq[row, d0 + i] = 1.0 / params.discharge_efficiency
        row += 1

    # 调整关系 G_new = G_old + A+ - A-
    old_active = None
    if is_update:
        old_active = np.asarray(previous_grid[active], dtype=float)
        for i in range(n):
            Aeq[row, g0 + i] = 1.0
            Aeq[row, ap0 + i] = -1.0
            Aeq[row, am0 + i] = 1.0
            beq[row] = old_active[i]
            row += 1

    if m:
        Aeq[row, ts0] = 1.0
        Aeq[row, s0 + n] = -1.0
        row += 1
        for i in range(m):
            Aeq[row, tg0 + i] = 1.0
            Aeq[row, td0 + i] = 1.0
            Aeq[row, th0 + i] = 1.0
            Aeq[row, tc0 + i] = -1.0
            Aeq[row, tw0 + i] = -1.0
            beq[row] = tail_net_kwh[i]
            row += 1
        for i in range(m):
            Aeq[row, ts0 + i] = -1.0
            Aeq[row, ts0 + i + 1] = 1.0
            Aeq[row, tc0 + i] = -params.charge_efficiency
            Aeq[row, td0 + i] = 1.0 / params.discharge_efficiency
            row += 1

    assert row == eq_rows

    bounds: list[tuple[float | None, float | None]] = []
    bounds.extend([(0.0, None)] * n)  # G
    bounds.extend([(0.0, params.max_energy_per_slot)] * n)  # C
    bounds.extend([(0.0, params.max_energy_per_slot)] * n)  # D
    bounds.append((start_soc, start_soc))
    bounds.extend([(params.capacity_min, params.capacity_max)] * n)

    if is_update:
        bounds.extend([(0.0, None)] * n)  # A+
        assert old_active is not None
        bounds.extend([(0.0, float(v)) for v in old_active])  # A-<=old G

    for _ in range(K):
        bounds.extend([(0.0, None)] * n)  # H
        bounds.extend([(0.0, None)] * n)  # W

    if m:
        bounds.extend([(0.0, None)] * m)  # tail G
        bounds.extend([(0.0, params.max_energy_per_slot)] * m)  # tail C
        bounds.extend([(0.0, params.max_energy_per_slot)] * m)  # tail D
        bounds.extend([(0.0, None)] * m)  # tail H
        bounds.extend([(0.0, None)] * m)  # tail W
        bounds.extend([(params.capacity_min, params.capacity_max)] * (m + 1))

    primary_obj = np.zeros(n_vars, dtype=float)
    if is_update:
        primary_obj[ap0:ap0+n] = params.increase_multiplier * p
        primary_obj[am0:am0+n] = -params.cancellation_refund_multiplier * p
    else:
        primary_obj[g0:g0+n] = p
    for k in range(K):
        primary_obj[h_starts[k]:h_starts[k]+n] = (
            probs[k] * params.emergency_multiplier * p
        )
    if m:
        primary_obj[tg0:tg0+m] = tail_price
        primary_obj[th0:th0+m] = params.emergency_multiplier * tail_price

    terminal_value = terminal_energy_value(price, params)
    terminal_soc_index = ts0 + m if m else s0 + n
    primary_obj[terminal_soc_index] -= terminal_value

    # 极小的字典序近似项只负责打破退化解，不改变经济结论，
    # 避免为每个MPC时刻再求一次二级LP，从而把全年回放时间大幅降低。
    solve_obj = primary_obj.copy()
    tie = 1e-8
    solve_obj[c0:c0+n] += tie
    solve_obj[d0:d0+n] += tie
    for k in range(K):
        solve_obj[w_starts[k]:w_starts[k]+n] += probs[k] * tie * 1e-3
    if m:
        solve_obj[tc0:tc0+m] += tie
        solve_obj[td0:td0+m] += tie
        solve_obj[tw0:tw0+m] += tie * 1e-3

    primary = linprog(
        solve_obj,
        A_eq=Aeq.tocsr(),
        b_eq=beq,
        bounds=bounds,
        method="highs",
    )
    if not primary.success:
        raise RuntimeError(f"SAA-MPC主优化失败(start={start_slot})：{primary.message}")

    x = np.where(np.abs(primary.x) < EPS, 0.0, primary.x)

    if previous_grid is None:
        full_g = np.zeros(PERIODS, dtype=float)
        full_c = np.zeros(PERIODS, dtype=float)
        full_d = np.zeros(PERIODS, dtype=float)
    else:
        full_g = np.asarray(previous_grid, dtype=float).copy()
        full_c = np.asarray(previous_charge, dtype=float).copy()
        full_d = np.asarray(previous_discharge, dtype=float).copy()

    full_g[active] = x[g0:g0+n]
    full_c[active] = x[c0:c0+n]
    full_d[active] = x[d0:d0+n]

    expected_emergency = 0.0
    for k in range(K):
        H = x[h_starts[k]:h_starts[k]+n]
        expected_emergency += probs[k] * float(params.emergency_multiplier * p @ H)

    return StagePlan(
        grid=full_g,
        charge=full_c,
        discharge=full_d,
        primary_objective=float(primary_obj @ x),
        expected_emergency_cost=expected_emergency,
        used_secondary=False,
        scenario_count=K,
    )


# 单日滚动执行
def execute_segment(
    *,
    data: ProblemData,
    day_idx: int,
    params: ModelParameters,
    grid: np.ndarray,
    charge: np.ndarray,
    discharge: np.ndarray,
    start_slot: int,
    end_slot: int,
    soc: np.ndarray,
    emergency: np.ndarray,
    waste: np.ndarray,
) -> None:
    """执行 [start_slot,end_slot)；G/C/D固定，H/W根据真实源荷补救。"""
    actual_net_kwh = (data.load_kw[day_idx] - data.pv_kw[day_idx]) * DT_HOURS
    for t in range(start_slot, end_slot):
        available = grid[t] + discharge[t] - charge[t]
        gap = actual_net_kwh[t] - available
        emergency[t] = max(0.0, gap)
        waste[t] = max(0.0, -gap)
        soc[t + 1] = (
            soc[t]
            + params.charge_efficiency * charge[t]
            - discharge[t] / params.discharge_efficiency
        )
        if soc[t + 1] < params.capacity_min - 1e-5 or soc[t + 1] > params.capacity_max + 1e-5:
            raise RuntimeError(f"{data.dates[day_idx]} 时段{t}实际执行SOC越界：{soc[t+1]}")


def base_net_forecast(
    data: ProblemData,
    load_forecast_kw: np.ndarray,
    day_idx: int,
    release_hour: int,
) -> np.ndarray:
    pv_pred = interpolate_pv_forecast(data, day_idx, release_hour)
    return load_forecast_kw[day_idx] - pv_pred


def run_one_day(
    *,
    data: ProblemData,
    load_forecast_kw: np.ndarray,
    load_weights: np.ndarray,
    params: ModelParameters,
    day_idx: int,
    policy_key: str,
    scenario_cache: dict[tuple[int, int], ScenarioSet],
    start_soc: float | None = None,
) -> DayRun:
    start_soc = params.initial_soc if start_soc is None else float(start_soc)
    updates = POLICIES[policy_key]
    d = data.dates[day_idx]
    if not np.all(np.isfinite(load_forecast_kw[day_idx])):
        raise ValueError(f"{d} 的负荷历史不足，无法进行21日滞后预测。")

    def scenarios_for(release: int) -> ScenarioSet:
        key = (day_idx, release)
        if key not in scenario_cache:
            scenario_cache[key] = build_scenario_set(
                data, load_forecast_kw, day_idx, release, params
            )
        return scenario_cache[key]

    # 0:00 初始计划
    net0 = base_net_forecast(data, load_forecast_kw, day_idx, 0)
    tail_net = build_tail_net_forecast(
        data, day_idx, params.lookahead_days, net0, start_slot=0
    )
    plan = solve_stage(
        price=data.price,
        base_net_kw=net0,
        scenarios=scenarios_for(0),
        params=params,
        start_slot=0,
        start_soc=start_soc,
        previous_grid=None,
        previous_charge=None,
        previous_discharge=None,
        tail_net_kw=tail_net,
    )
    initial_grid = plan.grid.copy()
    current_grid = plan.grid.copy()
    current_c = plan.charge.copy()
    current_d = plan.discharge.copy()

    emergency = np.zeros(PERIODS, dtype=float)
    waste = np.zeros(PERIODS, dtype=float)
    soc = np.full(PERIODS + 1, np.nan, dtype=float)
    soc[0] = start_soc
    adj_plus = np.zeros(PERIODS, dtype=float)
    adj_minus = np.zeros(PERIODS, dtype=float)
    adjustment_cost = 0.0

    executed_until = 0
    for release in updates:
        start_slot = release * 6
        # 更新从“下一10分钟”生效，因此先执行到 start_slot，即包含 release:00-release:10旧计划。
        execute_segment(
            data=data,
            day_idx=day_idx,
            params=params,
            grid=current_grid,
            charge=current_c,
            discharge=current_d,
            start_slot=executed_until,
            end_slot=start_slot,
            soc=soc,
            emergency=emergency,
            waste=waste,
        )
        executed_until = start_slot

        old_grid = current_grid.copy()
        old_c = current_c.copy()
        old_d = current_d.copy()
        net_new = base_net_forecast(data, load_forecast_kw, day_idx, release)
        rolling_tail = build_tail_net_forecast(
            # net_new在发布时刻之前按设计含NaN；跨日fallback必须使用0:00时
            # 已经形成的完整144格预测，避免把“过去时段不可用”误判为数据损坏。
            data, day_idx, params.lookahead_days, net0, start_slot=start_slot
        )
        new_plan = solve_stage(
            price=data.price,
            base_net_kw=net_new,
            scenarios=scenarios_for(release),
            params=params,
            start_slot=start_slot,
            start_soc=float(soc[start_slot]),
            previous_grid=old_grid,
            previous_charge=old_c,
            previous_discharge=old_d,
            tail_net_kw=rolling_tail,
        )

        diff = new_plan.grid[start_slot:] - old_grid[start_slot:]
        plus = np.maximum(diff, 0.0)
        minus = np.maximum(-diff, 0.0)
        adj_plus[start_slot:] += plus
        adj_minus[start_slot:] += minus
        p = data.price[start_slot:]
        adjustment_cost += float(
            params.increase_multiplier * p @ plus
            - params.cancellation_refund_multiplier * p @ minus
        )

        current_grid = new_plan.grid
        current_c = new_plan.charge
        current_d = new_plan.discharge

    # 最后一段执行到底
    execute_segment(
        data=data,
        day_idx=day_idx,
        params=params,
        grid=current_grid,
        charge=current_c,
        discharge=current_d,
        start_slot=executed_until,
        end_slot=PERIODS,
        soc=soc,
        emergency=emergency,
        waste=waste,
    )

    initial_cost = float(data.price @ initial_grid)
    emergency_cost = float(params.emergency_multiplier * data.price @ emergency)
    total_cost = initial_cost + adjustment_cost + emergency_cost

    return DayRun(
        date_value=d,
        policy_key=policy_key,
        initial_grid=initial_grid,
        final_grid=current_grid.copy(),
        executed_charge=current_c.copy(),
        executed_discharge=current_d.copy(),
        emergency=emergency,
        waste=waste,
        soc=soc,
        adjustment_plus=adj_plus,
        adjustment_minus=adj_minus,
        initial_plan_cost=initial_cost,
        adjustment_net_cost=adjustment_cost,
        emergency_cost=emergency_cost,
        total_cost=total_cost,
        emergency_kwh=float(emergency.sum()),
        waste_kwh=float(waste.sum()),
        load_weights=np.asarray(load_weights[day_idx], dtype=float).copy(),
    )


# 策略年度回放
def run_policy(
    *,
    data: ProblemData,
    load_forecast_kw: np.ndarray,
    load_weights: np.ndarray,
    params: ModelParameters,
    start_idx: int,
    end_idx: int,
    policy_key: str,
    scenario_cache: dict[tuple[int, int], ScenarioSet],
    verbose: bool,
    initial_previous: DayRun | None,
    initial_soc: float,
) -> tuple[DayRun | None, list[DayRun]]:
    if policy_key not in POLICIES:
        raise ValueError(f"未知策略：{policy_key}")

    previous = initial_previous
    energy = float(initial_soc)

    results: list[DayRun] = []
    total = end_idx - start_idx + 1
    for k, day_idx in enumerate(range(start_idx, end_idx + 1), start=1):
        r = run_one_day(
            data=data,
            load_forecast_kw=load_forecast_kw,
            load_weights=load_weights,
            params=params,
            day_idx=day_idx,
            policy_key=policy_key,
            scenario_cache=scenario_cache,
            start_soc=energy,
        )
        if previous is not None and abs(r.soc[0] - previous.soc[-1]) > 1e-6:
            raise RuntimeError("相邻日期SOC不连续。")
        results.append(r)
        previous = r
        energy = float(r.soc[-1])
        if verbose or k == 1 or k == total or k % 20 == 0:
            print(
                f"[{POLICY_LABELS[policy_key]}] {k:3d}/{total} {r.date_value} | "
                f"initial={r.initial_plan_cost:9.2f} | adj={r.adjustment_net_cost:8.2f} | "
                f"em={r.emergency_cost:8.2f} | total={r.total_cost:9.2f}"
            )
    return initial_previous, results


def build_common_warmup(
    *, data: ProblemData, load_forecast_kw: np.ndarray, load_weights: np.ndarray,
    params: ModelParameters, start_idx: int,
    scenario_cache: dict[tuple[int, int], ScenarioSet], verbose: bool,
) -> tuple[DayRun | None, float]:
    """从成熟预测起跨日预热到评价期，所有策略共享同一期初SOC。

    1月1日至第21个历史日沿用problem3.py原预测口径（不产生模型预测），储能保持
    题给6000 kWh；预测成熟后逐日连续运行，不再做任何日初或日末重置。
    """
    previous: DayRun | None = None
    energy = float(params.initial_soc)
    for day_idx in range(21, start_idx):
        r = run_one_day(
            data=data, load_forecast_kw=load_forecast_kw, load_weights=load_weights,
            params=params, day_idx=day_idx, policy_key="only_0",
            scenario_cache=scenario_cache, start_soc=energy,
        )
        if previous is not None and abs(r.soc[0] - previous.soc[-1]) > 1e-6:
            raise RuntimeError("预热阶段SOC不连续。")
        previous = r
        energy = float(r.soc[-1])
        if verbose and (day_idx % 10 == 0 or day_idx == start_idx - 1):
            print(f"[共同预热] {r.date_value} SOC={r.soc[0]:.2f}->{r.soc[-1]:.2f}")
    return previous, energy


def summarize_policy(results: list[DayRun]) -> dict[str, float]:
    soc_all = np.concatenate([r.soc for r in results])
    end_soc = np.asarray([r.soc[-1] for r in results])
    continuity_error = max(
        (abs(results[i].soc[0] - results[i - 1].soc[-1])
         for i in range(1, len(results))), default=0.0,
    )
    return {
        "days": float(len(results)),
        "start_soc_kwh": float(results[0].soc[0]),
        "end_soc_kwh": float(results[-1].soc[-1]),
        "min_soc_kwh": float(np.min(soc_all)),
        "max_soc_kwh": float(np.max(soc_all)),
        "soc_continuity_error_kwh": float(continuity_error),
        "end_near_min_days": float(np.sum(end_soc <= 1201.0)),
        "end_near_max_days": float(np.sum(end_soc >= 10799.0)),
        "initial_plan_cost_yuan": float(sum(r.initial_plan_cost for r in results)),
        "adjustment_net_cost_yuan": float(sum(r.adjustment_net_cost for r in results)),
        "emergency_cost_yuan": float(sum(r.emergency_cost for r in results)),
        "total_cost_yuan": float(sum(r.total_cost for r in results)),
        "emergency_kwh": float(sum(r.emergency_kwh for r in results)),
        "waste_kwh": float(sum(r.waste_kwh for r in results)),
    }


# 更新预测精度与 VOI
def forecast_update_accuracy(
    data: ProblemData,
    start_idx: int,
    end_idx: int,
) -> list[dict[str, float]]:
    rows: list[dict[str, float]] = []
    pairs = [(6, 0), (12, 6), (18, 12)]
    for new_release, old_release in pairs:
        old_err: list[np.ndarray] = []
        new_err: list[np.ndarray] = []
        start = new_release * 6
        for d in range(start_idx, end_idx + 1):
            try:
                old = interpolate_pv_forecast(data, d, old_release)
                new = interpolate_pv_forecast(data, d, new_release)
            except ValueError:
                continue
            actual = data.pv_kw[d]
            old_err.append(actual[start:] - old[start:])
            new_err.append(actual[start:] - new[start:])
        if not old_err:
            continue
        oe = np.concatenate(old_err)
        ne = np.concatenate(new_err)
        old_mae = float(np.mean(np.abs(oe)))
        new_mae = float(np.mean(np.abs(ne)))
        old_rmse = float(np.sqrt(np.mean(oe ** 2)))
        new_rmse = float(np.sqrt(np.mean(ne ** 2)))
        rows.append({
            "update_hour": float(new_release),
            "old_mae_kw": old_mae,
            "new_mae_kw": new_mae,
            "mae_reduction_pct": 100.0 * (old_mae - new_mae) / old_mae if old_mae > 0 else 0.0,
            "old_rmse_kw": old_rmse,
            "new_rmse_kw": new_rmse,
        })
    return rows


def build_daily_voi(
    policy_results: dict[str, list[DayRun]],
) -> list[dict[str, object]]:
    required = ["only_0", "0+6", "0+6+12", "0+6+12+18"]
    if not all(k in policy_results for k in required):
        return []
    n = min(len(policy_results[k]) for k in required)
    rows = []
    for i in range(n):
        r0 = policy_results["only_0"][i]
        r6 = policy_results["0+6"][i]
        r12 = policy_results["0+6+12"][i]
        r18 = policy_results["0+6+12+18"][i]
        rows.append({
            "date": r0.date_value.isoformat(),
            "voi_6_yuan": r0.total_cost - r6.total_cost,
            "voi_12_yuan": r6.total_cost - r12.total_cost,
            "voi_18_yuan": r12.total_cost - r18.total_cost,
        })
    return rows


def naturalize_series(previous: DayRun | None, current: DayRun, attr: str) -> np.ndarray:
    cur = np.asarray(getattr(current, attr), dtype=float)
    if previous is None:
        first = 0.0
    else:
        first = float(np.asarray(getattr(previous, attr), dtype=float)[-1])
    # 自然日0:00-0:10来自前一合同日最后一格；0:10-24:00来自当前合同前143格。
    return np.concatenate([[first], cur[:143]])


def natural_soc_endpoints(previous: DayRun | None, current: DayRun) -> tuple[float, float]:
    # 合同SOC索引143 = 24:00；索引144 = 次日0:10。
    if previous is None:
        e0 = float(current.soc[0])
    else:
        e0 = float(previous.soc[143])
    e24 = float(current.soc[143])
    return e0, e24


def merge_emergency_natural(previous: DayRun | None, current: DayRun) -> list[tuple[str, float]]:
    e = naturalize_series(previous, current, "emergency")
    out: list[tuple[str, float]] = []
    t = 0
    while t < PERIODS:
        if e[t] <= EMERGENCY_THRESHOLD:
            t += 1
            continue
        start = t
        amount = 0.0
        while t < PERIODS and e[t] > EMERGENCY_THRESHOLD:
            amount += float(e[t])
            t += 1
        end = t
        out.append((f"{format_clock(start*10)}-{format_clock(end*10)}", amount))
    return out


def style_number(cell, value: float) -> None:
    cell.value = float(value)
    cell.number_format = "0.0000"
    cell.alignment = Alignment(horizontal="center", vertical="center")


def create_result3_fallback(
    output: Path,
    previous_day: DayRun | None,
    results: list[DayRun],
    policy_summary: dict[str, dict[str, float]] | None = None,
) -> None:
    wb = Workbook()
    ws0 = wb.active
    ws0.title = "计划购电量"
    ws1 = wb.create_sheet("调整购电量")
    ws2 = wb.create_sheet("充放电量")
    ws3 = wb.create_sheet("紧急购电量")
    ws4 = wb.create_sheet("策略汇总")

    labels = contract_labels()
    for ws in (ws0, ws1):
        ws.cell(1, 1, "日期")
        for j, label in enumerate(labels, start=2):
            ws.cell(1, j, label)
        ws.cell(1, PERIODS + 2, "全天购电费(元)")

    for i, r in enumerate(results, start=2):
        ws0.cell(i, 1, r.date_value)
        ws0.cell(i, 1).number_format = "yyyy/m/d"
        ws1.cell(i, 1, r.date_value)
        ws1.cell(i, 1).number_format = "yyyy/m/d"
        for j, v in enumerate(r.initial_grid, start=2):
            style_number(ws0.cell(i, j), v)
        for j, v in enumerate(r.final_grid, start=2):
            style_number(ws1.cell(i, j), v)
        style_number(ws0.cell(i, PERIODS + 2), r.initial_plan_cost)
        style_number(ws1.cell(i, PERIODS + 2), r.initial_plan_cost + r.adjustment_net_cost)

    headers = ["日期"]
    for label in BLOCK_LABELS:
        headers.extend([f"{label}充电量(kWh)", f"{label}放电量(kWh)"])
    headers.extend(["0:00储电量(kWh)", "24:00储电量(kWh)"])
    for j, h in enumerate(headers, start=1):
        ws2.cell(1, j, h)

    prev = previous_day
    for i, r in enumerate(results, start=2):
        ws2.cell(i, 1, r.date_value)
        ws2.cell(i, 1).number_format = "yyyy/m/d"
        c_nat = naturalize_series(prev, r, "executed_charge")
        d_nat = naturalize_series(prev, r, "executed_discharge")
        c_blocks = c_nat.reshape(6, BLOCK_SIZE).sum(axis=1)
        d_blocks = d_nat.reshape(6, BLOCK_SIZE).sum(axis=1)
        col = 2
        for cv, dv in zip(c_blocks, d_blocks):
            style_number(ws2.cell(i, col), cv)
            style_number(ws2.cell(i, col + 1), dv)
            col += 2
        e0, e24 = natural_soc_endpoints(prev, r)
        style_number(ws2.cell(i, col), e0)
        style_number(ws2.cell(i, col + 1), e24)
        prev = r

    ws3.append(["日期", "紧急购电时间段", "紧急购电量(kWh)"])
    prev = previous_day
    for r in results:
        merged = merge_emergency_natural(prev, r)
        if not merged:
            ws3.append([r.date_value, "无", 0.0])
            ws3.cell(ws3.max_row, 1).number_format = "yyyy/m/d"
            style_number(ws3.cell(ws3.max_row, 3), 0.0)
        else:
            for j, (label, amount) in enumerate(merged):
                ws3.append([r.date_value if j == 0 else None, label, amount])
                if j == 0:
                    ws3.cell(ws3.max_row, 1).number_format = "yyyy/m/d"
                style_number(ws3.cell(ws3.max_row, 3), amount)
        prev = r

    ws4.append([
        "策略", "全年总费用(元)", "初始计划费(元)", "调整净费用(元)",
        "紧急购电费(元)", "紧急购电量(kWh)", "富余电量(kWh)"
    ])
    if policy_summary:
        for key in POLICIES:
            if key not in policy_summary:
                continue
            s = policy_summary[key]
            ws4.append([
                POLICY_LABELS[key],
                s["total_cost_yuan"],
                s["initial_plan_cost_yuan"],
                s["adjustment_net_cost_yuan"],
                s["emergency_cost_yuan"],
                s["emergency_kwh"],
                s["waste_kwh"],
            ])
            for c in range(2, 8):
                style_number(ws4.cell(ws4.max_row, c), ws4.cell(ws4.max_row, c).value)

    for ws in wb.worksheets:
        ws.sheet_view.showGridLines = False
        ws.freeze_panes = "B2" if ws.title in ("计划购电量", "调整购电量", "充放电量") else "A2"
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.column_dimensions["A"].width = 14

    ws3.column_dimensions["B"].width = 22
    ws3.column_dimensions["C"].width = 20
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)
    wb.close()


def try_fill_official_template(
    template: Path,
    output: Path,
    previous_day: DayRun | None,
    results: list[DayRun],
) -> bool:
    """保守适配：仅在明确识别到四个工作表时按常见宽表布局填写。"""
    if not template.exists():
        return False
    shutil.copy2(template, output)
    wb = openpyxl.load_workbook(output)
    required = ["计划购电量", "调整购电量", "充放电量", "紧急购电量"]
    if any(name not in wb.sheetnames for name in required):
        wb.close()
        output.unlink(missing_ok=True)
        return False

    ws0, ws1, ws2, ws3 = [wb[n] for n in required]
    if ws0.max_column < PERIODS + 1 or ws1.max_column < PERIODS + 1:
        wb.close()
        output.unlink(missing_ok=True)
        return False

    start_row = 2
    for ws in (ws0, ws1):
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.value = None

    for i, r in enumerate(results):
        rr = start_row + i
        for ws in (ws0, ws1):
            ws.cell(rr, 1, r.date_value)
            ws.cell(rr, 1).number_format = "yyyy/m/d"
        for j, v in enumerate(r.initial_grid, start=2):
            style_number(ws0.cell(rr, j), v)
        for j, v in enumerate(r.final_grid, start=2):
            style_number(ws1.cell(rr, j), v)

        # 官方147列：日期+144个区间+全天购电量+全天购电费。
        if ws0.max_column >= PERIODS + 3:
            style_number(ws0.cell(rr, PERIODS + 2), float(r.initial_grid.sum()))
            style_number(ws0.cell(rr, PERIODS + 3), r.initial_plan_cost)
        if ws1.max_column >= PERIODS + 3:
            style_number(ws1.cell(rr, PERIODS + 2), float(r.final_grid.sum()))
            style_number(ws1.cell(rr, PERIODS + 3), r.initial_plan_cost + r.adjustment_net_cost)

    # 充放电量常见布局：日期+12个4h充放+2个SOC
    if ws2.max_column == 6:
        # 官方模板：每个自然日6行，列为日期、4h时段、充电、放电、SOC时刻、SOC。
        for row in ws2.iter_rows(min_row=2):
            for cell in row:
                cell.value = None
        prev = previous_day
        for i, r in enumerate(results):
            cb = naturalize_series(prev, r, "executed_charge").reshape(6, BLOCK_SIZE).sum(axis=1)
            db = naturalize_series(prev, r, "executed_discharge").reshape(6, BLOCK_SIZE).sum(axis=1)
            e0, e24 = natural_soc_endpoints(prev, r)
            for b in range(6):
                rr = start_row + 6 * i + b
                values = [
                    r.date_value if b == 0 else None,
                    BLOCK_LABELS[b], float(cb[b]), float(db[b]),
                    "0:00" if b == 0 else ("24:00" if b == 1 else None),
                    e0 if b == 0 else (e24 if b == 1 else None),
                ]
                for col, value in enumerate(values, start=1):
                    ws2.cell(rr, col, value)
                if b == 0:
                    ws2.cell(rr, 1).number_format = "yyyy/m/d"
                for col in (3, 4, 6):
                    if isinstance(ws2.cell(rr, col).value, (int, float)):
                        ws2.cell(rr, col).number_format = "0.0000"
            prev = r
    elif ws2.max_column >= 15:
        # 兼容日期+12个4h充放电量+2个SOC的宽表。
        prev = previous_day
        for i, r in enumerate(results):
            rr = start_row + i
            c_nat = naturalize_series(prev, r, "executed_charge")
            d_nat = naturalize_series(prev, r, "executed_discharge")
            cb = c_nat.reshape(6, BLOCK_SIZE).sum(axis=1)
            db = d_nat.reshape(6, BLOCK_SIZE).sum(axis=1)
            col = 2
            for cv, dv in zip(cb, db):
                style_number(ws2.cell(rr, col), cv)
                style_number(ws2.cell(rr, col + 1), dv)
                col += 2
            e0, e24 = natural_soc_endpoints(prev, r)
            style_number(ws2.cell(rr, col), e0)
            style_number(ws2.cell(rr, col + 1), e24)
            prev = r

    if ws3.max_row > 1:
        ws3.delete_rows(2, ws3.max_row - 1)
    prev = previous_day
    for r in results:
        merged = merge_emergency_natural(prev, r)
        if not merged:
            ws3.append([r.date_value, "无", 0.0])
            ws3.cell(ws3.max_row, 1).number_format = "yyyy/m/d"
            style_number(ws3.cell(ws3.max_row, 3), 0.0)
        else:
            for j, (label, amount) in enumerate(merged):
                ws3.append([r.date_value if j == 0 else None, label, amount])
                if j == 0:
                    ws3.cell(ws3.max_row, 1).number_format = "yyyy/m/d"
                style_number(ws3.cell(ws3.max_row, 3), amount)
        prev = r

    wb.save(output)
    wb.close()
    return True


def write_result3(
    template: Path | None,
    output: Path,
    previous_day: DayRun | None,
    results: list[DayRun],
    policy_summary: dict[str, dict[str, float]] | None,
) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    if template is not None and template.exists():
        if try_fill_official_template(template, output, previous_day, results):
            return
        warnings.warn("检测到result3模板，但无法安全识别布局；改为生成结构化备用结果。")
    create_result3_fallback(output, previous_day, results, policy_summary)


def write_diagnostic_sheets(output: Path, summary_rows: list[dict],
                            accuracy_rows: list[dict], voi_rows: list[dict]) -> None:
    """合并原CSV数据，保留题目模板工作表；数值保留原精度，显示四位小数。"""
    wb = openpyxl.load_workbook(output)
    tables = [
        ("年度策略汇总", summary_rows, ["policy", "days", "initial_plan_cost_yuan",
          "adjustment_net_cost_yuan", "emergency_cost_yuan", "total_cost_yuan", "emergency_kwh", "waste_kwh"]),
        ("预测更新精度", accuracy_rows, ["update_hour", "old_mae_kw", "new_mae_kw",
          "mae_reduction_pct", "old_rmse_kw", "new_rmse_kw"]),
        ("逐日VOI", voi_rows, ["date", "voi_6_yuan", "voi_12_yuan", "voi_18_yuan"]),
    ]
    for title, rows, defaults in tables:
        if title in wb.sheetnames:
            del wb[title]
        ws = wb.create_sheet(title)
        keys = list(rows[0]) if rows else defaults
        ws.append(keys)
        for row in rows:
            ws.append([row.get(key) for key in keys])
        if not rows:
            ws.cell(2, 1, "当前运行未产生此项数据（逐日VOI需要全部对比策略）。")
        ws.freeze_panes = "A2"
        ws.sheet_view.showGridLines = False
        if rows:
            ws.auto_filter.ref = ws.dimensions
        for cell in ws[1]:
            cell.font = Font(name="微软雅黑", bold=True)
            cell.alignment = Alignment(horizontal="center")
            ws.column_dimensions[cell.column_letter].width = max(18, min(len(str(cell.value))+3, 30))
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                if isinstance(cell.value, (int, float)):
                    cell.number_format = "0.0000"
    wb.save(output)
    wb.close()


def print_paper_tables(previous_day: DayRun | None, results: list[DayRun]) -> None:
    """指定日期三张终端表；复用Excel口径，显示两位但不舍入计算数据。"""
    days = [date(2025, 3, 20), date(2025, 6, 21),
            date(2025, 9, 23), date(2025, 12, 21)]
    by_day = {}
    prev = previous_day
    for current in results:
        by_day[current.date_value] = (prev, current)
        prev = current

    def width(text):
        return sum(0 if unicodedata.combining(c) else
                   2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in text)

    def center(text, size):
        padding = size - width(text)
        return " " * (padding // 2) + text + " " * (padding - padding // 2)

    def table(headers, rows, groups=None):
        widths = [max(width(row[i]) for row in [headers, *rows]) + 2
                  for i in range(len(headers))]
        if groups:
            for i, label in enumerate(groups):
                extra = max(0, width(label) + 2 - sum(widths[2*i:2*i+2]) - 1)
                widths[2*i+1] += extra
        border = "+" + "+".join("-" * w for w in widths) + "+"
        if groups:
            spans = [sum(widths[i:i+2]) + 1 for i in range(0, len(widths), 2)]
            print("+" + "+".join("-" * w for w in spans) + "+")
            print("|" + "|".join(center(t, w) for t, w in zip(groups, spans)) + "|")
        print(border)
        for row in [headers, *rows]:
            print("|" + "|".join(center(t, w) for t, w in zip(row, widths)) + "|")
            print(border)

    labels = [f"{h:02d}:00-{h:02d}:10" for h in (10, 12, 14, 16, 18, 20)]
    rows_a, rows_b, emergency_groups = [], [], []
    for day in days:
        day_label = f"{day.year}/{day.month}/{day.day}"
        if day not in by_day:
            rows_a.append([day_label] + ["未计算"] * 12)
            rows_b.append([day_label] + ["未计算"] * 14)
            emergency_groups.append([("未计算", "—")])
            continue
        previous, current = by_day[day]
        # 合同首格为0:10，故自然日h:00起点的合同索引为6h-1。
        values = [current.final_grid[h * 6 - 1] for h in (10, 12, 14, 16, 18, 20)]
        contract_kwh = float(np.sum(current.final_grid))
        contract_cost = current.initial_plan_cost + current.adjustment_net_cost
        emergency_kwh = current.emergency_kwh
        emergency_cost = current.emergency_cost
        total_kwh = contract_kwh + emergency_kwh
        total_cost = contract_cost + emergency_cost
        if abs(total_cost - current.total_cost) > 1e-6:
            raise RuntimeError(f"{day} 总购电费用分项与模型总费用不一致。")
        values += [contract_kwh, contract_cost, emergency_kwh,
                   emergency_cost, total_kwh, total_cost]
        rows_a.append([day_label] + [f"{v:.2f}" for v in values])
        charge = naturalize_series(previous, current, "executed_charge").reshape(6, BLOCK_SIZE).sum(axis=1)
        discharge = naturalize_series(previous, current, "executed_discharge").reshape(6, BLOCK_SIZE).sum(axis=1)
        values = [v for pair in zip(charge, discharge) for v in pair]
        values += list(natural_soc_endpoints(previous, current))
        rows_b.append([day_label] + [f"{v:.2f}" for v in values])
        emergency_groups.append([(label, f"{amount:.2f}") for label, amount in
                                 merge_emergency_natural(previous, current)] or [("无", "0.00")])

    print("\n表A  四个指定日期的合同与总购电结果（电量：kWh；费用：元）")
    table(["日期", *labels, "全天合同购电量", "合同购电结算费",
           "紧急购电量", "紧急购电费", "全天总购电量", "全天总购电费"], rows_a)
    print("注：时段值及全天合同购电量采用调整后的合同；合同购电结算费=初始计划费+调整净费用；")
    print("    全天总购电量=全天合同购电量+紧急购电量，全天总购电费=合同购电结算费+紧急购电费。")
    print("    表A合同窗口沿用官方result3模板，为0:10至次日0:10；表C另列紧急购电发生时段。")
    print("\n表B  四个指定日期的储能运行结果（单位：kWh）")
    headers = ["时间段"]
    for day in days:
        headers.extend([f"{day.month}/{day.day} 充电", f"{day.month}/{day.day} 放电"])
    storage_rows = []
    for block, h in enumerate(range(0, 24, 4)):
        storage_rows.append(
            [f"{h}:00–{h+4}:00"] +
            [value for row in rows_b for value in row[1+2*block:3+2*block]]
        )
    table(headers, storage_rows)
    print("首尾储电量（0:00 / 24:00，单位：kWh）：")
    for day, row in zip(days, rows_b):
        print(f"  {day.month}/{day.day}：{row[-2]} / {row[-1]}")
    print("\n表C  四个指定日期的紧急购电（单位：kWh）")
    rows_c = []
    for i in range(max(map(len, emergency_groups))):
        rows_c.append([v for group in emergency_groups
                       for v in (group[i] if i < len(group) else ("—", "—"))])
    table(["时间段", "购电量"] * 4, rows_c,
          [f"{d.year}/{d.month}/{d.day}" for d in days])
    print("注：表B、C按0:00至24:00自然日统计；连续紧急购电时段合并，无表示全天无事件，—为补位。")


def print_policy_summary(summary: dict[str, dict[str, float]]) -> None:
    def table(headers, rows):
        def width(text):
            return sum(0 if unicodedata.combining(c) else
                       2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in text)
        widths = [max(width(row[i]) for row in [headers, *rows])
                  for i in range(len(headers))]
        border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
        def line(row, header=False):
            cells = []
            for i, (value, size) in enumerate(zip(row, widths)):
                pad = " " * (size - width(value))
                cells.append(" " + (value + pad if header or i == 0 else pad + value) + " ")
            return "|" + "|".join(cells) + "|"
        print(border)
        print(line(headers, True))
        print(border)
        for row in rows:
            print(line(row))
        print(border)

    print("\n问题3策略年度汇总")
    fields = ["total_cost_yuan", "initial_plan_cost_yuan", "adjustment_net_cost_yuan",
              "emergency_cost_yuan", "emergency_kwh"]
    rows = [[POLICY_LABELS[key]] + [f"{summary[key][field]:.2f}" for field in fields]
            for key in POLICIES if key in summary]
    table(["策略", "总费用/元", "初始计划费/元", "调整净费用/元",
           "紧急购电费/元", "紧急购电量/kWh"], rows)

    soc_rows = [[
        POLICY_LABELS[key],
        f"{summary[key]['start_soc_kwh']:.2f}",
        f"{summary[key]['end_soc_kwh']:.2f}",
        f"{summary[key]['min_soc_kwh']:.2f}",
        f"{summary[key]['max_soc_kwh']:.2f}",
        f"{summary[key]['soc_continuity_error_kwh']:.2e}",
    ] for key in POLICIES if key in summary]
    print("\n跨日SOC连续性诊断")
    table(["策略", "期初SOC", "期末SOC", "全期最小", "全期最大", "连续残差"], soc_rows)
    if all(k in summary for k in POLICIES):
        transitions = [("6:00", "only_0", "0+6"),
                       ("12:00", "0+6", "0+6+12"),
                       ("18:00", "0+6+12", "0+6+12+18")]
        rows = [[hour, f"{summary[before]['total_cost_yuan'] - summary[after]['total_cost_yuan']:.2f}"]
                for hour, before, after in transitions]
        print("\n边际信息价值 VOI")
        table(["新增更新时刻", "边际信息价值/元"], rows)


def print_accuracy(rows: list[dict[str, float]]) -> None:
    if not rows:
        return
    print("\n================ 光伏更新预测精度 ================")
    for r in rows:
        print(
            f"{int(r['update_hour']):02d}:00 | "
            f"MAE {r['old_mae_kw']:.2f} -> {r['new_mae_kw']:.2f} kW "
            f"({r['mae_reduction_pct']:.2f}%下降) | "
            f"RMSE {r['old_rmse_kw']:.2f} -> {r['new_rmse_kw']:.2f} kW"
        )


def generate_figures(workbook: Path, figure_dir: Path) -> list[Path]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager, colors
    from matplotlib.ticker import MaxNLocator

    wb = openpyxl.load_workbook(workbook, read_only=True, data_only=True)
    def records(name):
        if name not in wb.sheetnames:
            return []
        rows = iter(wb[name].values)
        keys = next(rows)
        return [dict(zip(keys, row)) for row in rows if row[0] is not None]
    try:
        accuracy = records("预测更新精度")
        policies = records("年度策略汇总")
        voi = [r for r in records("逐日VOI") if isinstance(r.get("voi_6_yuan"), (int, float))]
        plans = records("计划购电量")
        adjusted = records("调整购电量")
    finally:
        wb.close()
    available = {f.name for f in font_manager.fontManager.ttflist}
    font = next((f for f in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC") if f in available), "DejaVu Sans")
    if font == "DejaVu Sans":
        warnings.warn("未找到中文字体，请安装微软雅黑或黑体后重新绘图。")
    figure_dir.mkdir(parents=True, exist_ok=True)
    navy, teal, orange, purple = "#243E59", "#159E98", "#EAA44B", "#8071B3"
    outputs = []
    style = {"font.family": font, "font.size": 8, "axes.titlesize": 10,
             "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7,
             "text.color": navy, "axes.labelcolor": navy, "axes.edgecolor": "#C6D2DB",
             "xtick.color": "#63788A", "ytick.color": "#63788A", "axes.unicode_minus": False,
             "svg.fonttype": "none", "pdf.fonttype": 42, "ps.fonttype": 42,
             "savefig.facecolor": "white"}
    def clean(ax):
        ax.spines[["top", "right"]].set_visible(False)
        ax.set_axisbelow(True)
        ax.grid(axis="x", color="#E9EEF2", linewidth=.6)
        ax.tick_params(length=2.5)
    def finish(fig, name):
        for suffix in ("png", "svg", "pdf"):
            path = figure_dir / f"{name}.{suffix}"
            fig.savefig(path, dpi=600, facecolor="white")
            outputs.append(path)
        plt.close(fig)
    def heading(fig, title, subtitle):
        fig.text(.5, .945, title, ha="center", fontsize=12, weight="bold", va="top")
        if subtitle:
            fig.text(.08, .875, subtitle, fontsize=7, color="#63788A", va="top")
    def month_of(value):
        return value.month if hasattr(value, "month") else datetime.fromisoformat(str(value)).month

    with plt.rc_context(style):
        if accuracy:
            fig, axes = plt.subplots(1, 2, figsize=(6.7, 3.0))
            fig.subplots_adjust(left=.12, right=.965, bottom=.17, top=.71, wspace=.32)
            heading(fig, "光伏预测更新前后误差对比", "")
            y = np.arange(len(accuracy))[::-1]
            for ax, metric in zip(axes, ("mae", "rmse")):
                old = np.array([r[f"old_{metric}_kw"] for r in accuracy])
                new = np.array([r[f"new_{metric}_kw"] for r in accuracy])
                for i, (a, b, yy) in enumerate(zip(old, new, y)):
                    ax.axhspan(yy-.33, yy+.33, color="#F3F7FA", zorder=0)
                    ax.plot([b, a], [yy, yy], color="#B6C9D5", lw=4, solid_capstyle="round")
                    ax.annotate(f"{b:.2f} ← {a:.2f}", ((a+b)/2, yy), xytext=(0, -17),
                                textcoords="offset points", ha="center", fontsize=6.5)
                    rate = 100*(a-b)/a if a else 0
                    ax.text(.98, yy, f"{rate:.2f}%", transform=ax.get_yaxis_transform(),
                            ha="right", va="center", color=teal, fontsize=7)
                ax.scatter(old, y, s=52, facecolor="white", edgecolor=orange, linewidth=1.6, zorder=3, label="更新前")
                ax.scatter(new, y, s=44, color=teal, edgecolor="white", linewidth=.6, zorder=4, label="更新后")
                ax.set(yticks=y, yticklabels=[f"{int(r['update_hour']):02d}:00" for r in accuracy],
                       ylim=(-.65, len(y)-.35), xlim=(-max(old)*.07, max(old)*1.42), xlabel=f"{metric.upper()} / kW")
                clean(ax)
            handles, labels = axes[0].get_legend_handles_labels()
            fig.legend(handles, labels, loc="upper right", bbox_to_anchor=(.96, .825), frameon=False, ncol=2, fontsize=7)
            finish(fig, "fig3_1_forecast_update_accuracy")

        if policies:
            from matplotlib.patches import FancyBboxPatch
            fig = plt.figure(figsize=(6.7, 3.0))
            heading(fig, "不同更新策略的经济性与购电结果", "")
            ax = fig.add_axes([.075, .07, .88, .76])
            ax.set(xlim=(-1.18, 3.58), ylim=(-.66, 2.98)); ax.axis("off")
            fields = [
                ("total_cost_yuan", "总购电费用", "万元", 10000.0),
                ("emergency_kwh", "紧急购电量", "万kWh", 10000.0),
                ("waste_kwh", "富余电量", "万kWh", 10000.0),
            ]
            values = {key: np.array([float(r[key]) for r in policies]) for key, *_ in fields}
            base = {key: arr[0] for key, arr in values.items()}
            gain_color = colors.LinearSegmentedColormap.from_list("fingerprint", ["#EFF3F6", "#B7DDD9", "#168F89"])
            # 推荐策略由题目主模型约定决定，而不是按图中结果事后挑选。
            recommended_idx = next((i for i, r in enumerate(policies) if r["policy"] == "0:00+6:00+12:00"), None)
            for j, r in enumerate(policies):
                if j == recommended_idx:
                    ax.add_patch(FancyBboxPatch((j-.45, -.57), .90, 3.45,
                                 boxstyle="round,pad=0.018,rounding_size=.07",
                                 facecolor="#F2F8F7", edgecolor=teal, linewidth=1.1, zorder=-2))
                    ax.text(j, 2.82, "本文策略", ha="center", va="center", fontsize=6.2,
                            color="white", bbox=dict(boxstyle="round,pad=.28", fc=teal, ec="none"))
                ax.text(j, 2.55, chr(65+j), ha="center", va="center", fontsize=8, weight="bold",
                        color="white", bbox=dict(boxstyle="circle,pad=.34", fc=navy if j != recommended_idx else teal, ec="none"))
                ax.text(j, 2.28, str(r["policy"]), ha="center", va="center", fontsize=7.2,
                        weight="bold" if j == recommended_idx else "normal")
            for row, (key, label, unit, scale) in enumerate(fields):
                yy = 1.55-row*.88
                arr = values[key]
                improvements = 100*(base[key]-arr)/base[key] if base[key] else np.zeros_like(arr)
                max_gain = max(float(improvements.max()), 1e-9)
                ax.text(-1.10, yy+.08, label, ha="left", va="center", fontsize=7.5, weight="bold")
                ax.text(-1.10, yy-.17, unit, ha="left", va="center", fontsize=6, color="#53616C")
                for j, value in enumerate(arr):
                    strength = max(0.0, float(improvements[j])/max_gain)
                    face = gain_color(.12+.78*strength)
                    edge = teal if j == recommended_idx else "#D8E1E7"
                    ax.add_patch(FancyBboxPatch((j-.39, yy-.29), .78, .58,
                                 boxstyle="round,pad=0.015,rounding_size=.055",
                                 facecolor=face, edgecolor=edge, linewidth=1.0 if j == recommended_idx else .7))
                    dark = strength > .58
                    txt = "white" if dark else navy
                    ax.text(j, yy+.065, f"{value/scale:.2f}", ha="center", va="center",
                            fontsize=8, weight="bold", color=txt)
                    delta = ("基准" if j == 0 else
                             f"较基准降低{improvements[j]:.2f}%" if improvements[j] >= 0 else
                             f"较基准增加{abs(improvements[j]):.2f}%")
                    ax.text(j, yy-.16, delta, ha="center", va="center",
                            fontsize=6, color=txt if dark else "#53616C")
            finish(fig, "fig3_2_policy_tradeoff")

        if voi:
            fig = plt.figure(figsize=(6.7, 3.0))
            heading(fig, "预测更新的边际信息价值", "")
            fig.text(.2875, .825, "逐日分布（百分比为费用降低日占比）",
                     ha="center", fontsize=7.2, weight="bold")
            fig.text(.73, .825, "月内日均信息价值", ha="center", fontsize=8, weight="bold")
            ax = fig.add_axes([.085, .17, .405, .58])
            heat = fig.add_axes([.55, .17, .36, .58])
            cax = fig.add_axes([.93, .17, .016, .58])
            values = [np.array([r[f"voi_{h}_yuan"] for r in voi], dtype=float) for h in (6,12,18)]
            for j, arr in enumerate(values):
                if len(arr) > 1 and np.ptp(arr) > 1e-9:
                    v = ax.violinplot([arr], positions=[j], widths=.72, showextrema=False)
                    v['bodies'][0].set(facecolor=[teal, orange, purple][j], alpha=.25, edgecolor="none")
                q1, med, q3 = np.percentile(arr, [25,50,75])
                ax.plot([j,j], [q1,q3], color=[teal,orange,purple][j], lw=4, solid_capstyle="round")
                ax.scatter([j], [med], color="white", edgecolor=[teal,orange,purple][j], s=24, zorder=4)
                ax.text(j, 1.035, f"{100*np.mean(arr>0):.2f}%", transform=ax.get_xaxis_transform(),
                        ha="center", va="bottom", fontsize=6, color="#53616C")
            ax.axhline(0, color="#8495A4", lw=.8, ls="--")
            ax.set(xticks=range(3), xticklabels=["6:00", "12:00", "18:00"], ylabel="逐日边际信息价值 / 元", xlabel="更新时刻")
            clean(ax); ax.grid(False); ax.grid(axis="y", color="#E9EEF2", lw=.6)
            months = sorted({month_of(r['date']) for r in voi})
            matrix = np.array([[np.mean([r[f'voi_{h}_yuan'] for r in voi if month_of(r['date']) == m])
                                for h in (6,12,18)] for m in months])
            limit = max(float(np.abs(matrix).max()), 1e-9)
            cmap = colors.LinearSegmentedColormap.from_list("voi", ["#C96761", "#F8FAFB", teal])
            im = heat.imshow(matrix, cmap=cmap, vmin=-limit, vmax=limit, aspect="auto")
            heat.set(xticks=range(3), xticklabels=["6:00", "12:00", "18:00"], yticks=range(len(months)),
                     yticklabels=[f"{m}月" for m in months], xlabel="更新时刻")
            for i in range(len(months)):
                for j in range(3):
                    heat.text(j, i, f"{matrix[i,j]:.2f}", ha="center", va="center", fontsize=5.8,
                              color="white" if abs(matrix[i,j])>.65*limit else navy)
            heat.tick_params(length=0)
            for spine in heat.spines.values(): spine.set_visible(False)
            fig.colorbar(im, cax=cax)
            cax.tick_params(labelsize=6, pad=2)
            cax.set_title("元/日", fontsize=6.5, pad=8)
            finish(fig, "fig3_3_information_value")

        if plans and adjusted:
            # 按日期匹配，不假定两个工作表的行序一致；只取144个合同电量列。
            def plan_map(rows):
                result = {}
                for row in rows:
                    vals = list(row.values())
                    numbers = vals[1:145]
                    if len(numbers) == PERIODS and all(isinstance(v, (int,float)) for v in numbers):
                        result[str(vals[0])] = (month_of(vals[0]), np.array(numbers, dtype=float))
                return result
            initial, final = plan_map(plans), plan_map(adjusted)
            common = sorted(set(initial) & set(final))
            if common:
                months = sorted({initial[k][0] for k in common})
                matrix = np.array([np.mean([(final[k][1]-initial[k][1]).reshape(24,6).sum(axis=1)
                                            for k in common if initial[k][0] == m], axis=0) for m in months])
                fig = plt.figure(figsize=(6.7, 3.0))
                heading(fig, "合同购电净调整量的月内小时均值", "")
                # 三维投影自身会在坐标区内部保留透视边距，因此适当向左扩展面板；
                # z轴标题改为画布文字，防止扩展后被裁切。
                ax = fig.add_axes([-.035, .08, .62, .78], projection="3d")
                heat = fig.add_axes([.535, .16, .37, .62])
                cax = fig.add_axes([.92, .16, .016, .62])
                xx, yy = np.meshgrid(np.arange(24)+.5+1/6, months)
                limit = max(float(np.abs(matrix).max()), 1e-9)
                # 高对比离散色阶；中间保留窄中性区，缩放后仍能看清单元格。
                palette_adjustment = [
                    "#006D5B", "#2A9D8F", "#76C7B7", "#CFEAE3",
                    "#F7F7F7",
                    "#FEE0B6", "#FDB863", "#E08214", "#B35806",
                ]
                cmap = colors.ListedColormap(palette_adjustment, name="adjustment_discrete")
                bounds = limit*np.array([-1.00, -.75, -.50, -.25, -.08, .08, .25, .50, .75, 1.00])
                norm = colors.BoundaryNorm(bounds, cmap.N, clip=True)
                if len(months) > 1:
                    facecolors = cmap(norm(matrix))
                    ax.plot_surface(xx, yy, matrix, facecolors=facecolors, linewidth=.18,
                                    edgecolor="#7D8D9A", antialiased=True, shade=False, alpha=1.0)
                else:
                    ax.scatter(xx.ravel(), yy.ravel(), matrix.ravel(), c=matrix.ravel(), cmap=cmap, norm=norm)
                ax.view_init(elev=27, azim=-125)
                ax.set_box_aspect((1.8,1,.75))
                ax.set(xlabel="时刻 / h", ylabel="月份", xticks=[1/6,6+1/6,12+1/6,18+1/6,24+1/6],
                       xticklabels=["0:10","6:10","12:10","18:10","次日0:10"])
                fig.text(.022, .46, "净调整 / kWh", rotation=90, ha="center", va="center",
                         fontsize=7.2, color=navy)
                ax.tick_params(labelsize=6.3, pad=0)
                ax.zaxis.labelpad = -3
                ax.zaxis.set_major_locator(MaxNLocator(4))
                for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
                    axis.pane.fill = False
                    axis._axinfo['grid']['color'] = '#E5EBF0'
                x_edges = np.arange(25, dtype=float) + 1/6
                y_edges = np.arange(len(months)+1, dtype=float)
                im = heat.pcolormesh(x_edges, y_edges, matrix, cmap=cmap, norm=norm,
                                     shading="flat", edgecolors="white", linewidth=.28,
                                     antialiased=False, rasterized=False)
                heat.set(yticks=np.arange(len(months))+.5, yticklabels=[f"{m}月" for m in months],
                         xticks=[1/6,8+1/6,16+1/6,24+1/6], xticklabels=["0:10","8:10","16:10","次日0:10"])
                heat.tick_params(length=0, labelsize=6.5)
                heat.set_title("净调整量热力图", fontsize=8, pad=9)
                fig.colorbar(im, cax=cax, boundaries=bounds,
                             ticks=np.linspace(-limit, limit, 5), spacing="proportional")
                cax.set_title("kWh", fontsize=7, pad=8)
                cax.tick_params(labelsize=6, pad=2)
                fig.text(.08, .035,
                         "负值：减购；正值：增购",
                         fontsize=6, color="#53616C", va="bottom")
                finish(fig, "fig3_4_adjustment_landscape")
        captions = [
            "图1 光伏预测更新前后误差对比。圆点对比同一更新时刻、同一剩余预测窗口的MAE与RMSE；百分数表示相对更新前的误差降幅。",
            "图2 不同更新策略的经济性与购电结果。卡片列示各策略的实际回测指标；降幅以仅0:00更新策略为基准，同一行底色按相对改善幅度归一化。本文策略为0:00、6:00和12:00更新，并非按单项指标最优事后选择。",
            f"图3 预测更新的边际信息价值。VOI为加入该次更新前的策略费用减去加入后的策略费用，负值表示费用增加。左图展示{len(voi)}个有效回测日的分布，圆点为中位数、粗线为四分位区间；费用降低日占比为VOI大于零的日数比例。右图为各月逐日VOI的均值。",
            "图4 合同购电净调整量的月内小时均值。净调整量为最终合同购电量减去初始计划购电量，每小时聚合六个10分钟区间，再对同月回测日取均值。合同窗口为0:10至次日0:10；两侧图使用同一数据，绿色为减购、橙色为增购。",
        ]
        (figure_dir / "figure_captions.txt").write_text("\n\n".join(captions), encoding="utf-8")
        if len(outputs) < 12:
            warnings.warn("部分绘图数据缺失，已跳过相应图；完整四图需要 --policy all 的结果与逐日VOI。")
    for path in outputs:
        if path.suffix == '.png':
            print(f"图片已生成：{path.resolve()}")
    return outputs


def parse_args() -> argparse.Namespace:
    parent = BASE_DIR.parent
    parser = argparse.ArgumentParser(description="C题问题3：SAA-MPC滚动购电模型")
    parser.add_argument("--price", type=Path, default=None, help="附件1路径")
    parser.add_argument("--actual", type=Path, default=None, help="附件2路径")
    parser.add_argument("--pv-forecast", type=Path, default=None, help="附件3路径")
    parser.add_argument("--template", type=Path, default=parent / "附件5" / "result3.xlsx")
    parser.add_argument("--output", type=Path, default=BASE_DIR / "result3.xlsx")
    parser.add_argument("--fig-dir", type=Path, default=None,
                        help="图片目录；默认与结果Excel同目录下的figures")
    parser.add_argument("--plot", action="store_true", help="回测完成后生成四组论文图")
    parser.add_argument("--plot-only", action="store_true", help="只读取现有result3.xlsx绘图，不重新回测")
    parser.add_argument("--start", default="2025-02-01")
    parser.add_argument("--end", default="2025-12-31")
    parser.add_argument(
        "--policy",
        choices=["recommended", "all", *POLICIES.keys()],
        default="all",
        help="all=比较四种更新策略并输出推荐结果；recommended=仅0+6+12",
    )
    parser.add_argument("--k", type=int, default=7, help="k-medoids场景数，默认7")
    parser.add_argument("--residual-days", type=int, default=28, help="历史残差池天数，默认28")
    parser.add_argument("--lookahead-days", type=int, choices=[0, 1, 2], default=1,
                        help="固定滚动窗口附加天数；1对应48小时窗口")
    parser.add_argument("--terminal-value-scale", type=float, default=1.0,
                        help="窗口末端价值系数；lambda_E=系数×放电效率×电价中位数")
    parser.add_argument("--verbose", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.plot_only:
        generate_figures(args.output, args.fig_dir or args.output.parent / "figures")
        return
    parent = BASE_DIR.parent

    price_path = args.price or discover_input(parent, "附件1.xlsx", "附件1")
    actual_path = args.actual or discover_input(parent, "附件2.xlsx", "附件2")
    forecast_path = args.pv_forecast or discover_input(parent, "附件3.xlsx", "附件3")

    print("输入文件：")
    print(f"  附件1: {price_path}")
    print(f"  附件2: {actual_path}")
    print(f"  附件3: {forecast_path}")

    params = ModelParameters(
        lookahead_days=int(args.lookahead_days),
        terminal_value_scale=float(args.terminal_value_scale),
        k_scenarios=max(1, int(args.k)),
        residual_days=max(7, int(args.residual_days)),
    )
    if params.terminal_value_scale < 0:
        raise ValueError("terminal-value-scale不能为负。")
    data = load_problem_data(price_path, actual_path, forecast_path)
    load_pred, load_weights = build_load_forecasts(data, params)

    start_date = datetime.strptime(args.start, "%Y-%m-%d").date()
    end_date = datetime.strptime(args.end, "%Y-%m-%d").date()
    date_to_idx = {d: i for i, d in enumerate(data.dates)}
    if start_date not in date_to_idx or end_date not in date_to_idx:
        raise ValueError("起止日期必须存在于附件2中。")
    start_idx = date_to_idx[start_date]
    end_idx = date_to_idx[end_date]
    if start_idx > end_idx:
        raise ValueError("start不能晚于end。")
    if start_idx < 22:
        raise ValueError("问题3默认需要至少21天历史；建议从2025-02-01或更晚开始。")

    if args.policy == "all":
        policy_keys = list(POLICIES.keys())
    elif args.policy == "recommended":
        policy_keys = ["0+6+12"]
    else:
        policy_keys = [args.policy]

    scenario_cache: dict[tuple[int, int], ScenarioSet] = {}
    policy_results: dict[str, list[DayRun]] = {}
    previous_by_policy: dict[str, DayRun | None] = {}
    summary: dict[str, dict[str, float]] = {}

    common_previous, common_start_soc = build_common_warmup(
        data=data,
        load_forecast_kw=load_pred,
        load_weights=load_weights,
        params=params,
        start_idx=start_idx,
        scenario_cache=scenario_cache,
        verbose=args.verbose,
    )
    print(
        f"\n评价期共同初始SOC：{common_start_soc:.2f} kWh；"
        f"固定滚动窗口={(params.lookahead_days + 1) * 24}小时；"
        f"窗口末端价值={terminal_energy_value(data.price, params):.6f}元/kWh"
    )

    for key in policy_keys:
        print(f"\n开始回放策略：{POLICY_LABELS[key]}")
        prev, results = run_policy(
            data=data,
            load_forecast_kw=load_pred,
            load_weights=load_weights,
            params=params,
            start_idx=start_idx,
            end_idx=end_idx,
            policy_key=key,
            scenario_cache=scenario_cache,
            verbose=args.verbose,
            initial_previous=common_previous,
            initial_soc=common_start_soc,
        )
        previous_by_policy[key] = prev
        policy_results[key] = results
        summary[key] = summarize_policy(results)
        summary[key]["rolling_horizon_hours"] = float((params.lookahead_days + 1) * 24)
        summary[key]["terminal_value_yuan_per_kwh"] = terminal_energy_value(data.price, params)
        summary[key]["terminal_value_scale"] = float(params.terminal_value_scale)

    print_policy_summary(summary)

    accuracy = forecast_update_accuracy(data, start_idx, end_idx)
    print_accuracy(accuracy)

    output_key = "0+6+12" if "0+6+12" in policy_results else policy_keys[0]
    print_paper_tables(previous_by_policy[output_key], policy_results[output_key])
    template = args.template if args.template.exists() else None
    write_result3(
        template,
        args.output,
        previous_by_policy[output_key],
        policy_results[output_key],
        summary,
    )

    summary_rows = []
    for key in policy_keys:
        s = summary[key]
        summary_rows.append({
            "policy": POLICY_LABELS[key],
            **s,
        })
    write_diagnostic_sheets(args.output, summary_rows, accuracy, build_daily_voi(policy_results))
    figure_dir = args.fig_dir or args.output.parent / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n推荐策略结果已保存：{args.output.resolve()}")
    print("年度策略汇总、预测更新精度、逐日VOI已写入同一Excel的独立工作表。")
    print(f"图片目录：{figure_dir.resolve()}")
    if args.plot:
        generate_figures(args.output, figure_dir)
    else:
        print("使用 --plot 同时生成图片，或使用 --plot-only 从现有Excel直接绘图。")


if __name__ == "__main__":
    main()
