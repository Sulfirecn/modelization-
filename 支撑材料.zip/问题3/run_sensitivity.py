# -*- coding: utf-8 -*-
"""问题3敏感性：场景数K、残差历史窗口H、跨日前视天数L和终端价值系数V。"""
from pathlib import Path
import subprocess
import sys
import json
import os
import openpyxl

R = Path(__file__).resolve().parent
MODEL = R / "problem3.py"

# 主模型：K=7, H=28, L=1, V=1.0。
# V用于检验窗口末端储能估值；实际现金成本始终不扣除终端价值。
cases = [
    ("K5",       5, 28, 1, 1.0, "K"),
    ("K7_H28",   7, 28, 1, 1.0, "baseline"),
    ("K9",       9, 28, 1, 1.0, "K"),
    ("H14",      7, 14, 1, 1.0, "history"),
    ("H42",      7, 42, 1, 1.0, "history"),
    ("L0",       7, 28, 0, 1.0, "lookahead"),
    ("L2",       7, 28, 2, 1.0, "lookahead"),
    ("V0",       7, 28, 1, 0.0, "terminal_value"),
    ("V0_5",     7, 28, 1, 0.5, "terminal_value"),
    ("V1_5",     7, 28, 1, 1.5, "terminal_value"),
]

if "--grid" in sys.argv:
    cases = [
        (f"K{k}_H{h}", k, h, 1, 1.0, "grid")
        for k in [5, 7, 9]
        for h in [14, 28, 42]
    ]
    cases += [
        (f"L{l}", 7, 28, l, 1.0, "lookahead")
        for l in [0, 1, 2]
    ]
    cases += [
        (f"V{str(v).replace('.', '_')}", 7, 28, 1, v, "terminal_value")
        for v in [0.0, 0.5, 1.0, 1.5]
    ]

root = R / "sensitivity"
root.mkdir(exist_ok=True)

os.environ["PYTHONUTF8"] = "1"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

summary = []

if not MODEL.is_file():
    raise FileNotFoundError(f"找不到问题3模型脚本：{MODEL}")

for name, k, h, lookahead, terminal_scale, group in cases:
    out_dir = root / name
    out_dir.mkdir(exist_ok=True)

    cmd = [
        sys.executable,
        str(MODEL),
        "--policy", "recommended",
        "--k", str(k),
        "--residual-days", str(h),
        "--lookahead-days", str(lookahead),
        "--terminal-value-scale", str(terminal_scale),
        "--output", str(out_dir / "result3.xlsx"),
    ]

    print("Running", name, flush=True)
    with (out_dir / "run.log").open("w", encoding="utf-8") as f:
        subprocess.run(
            cmd,
            stdout=f,
            stderr=subprocess.STDOUT,
            check=True,
            cwd=R,
        )

    result_path = out_dir / "result3.xlsx"
    wb_case = openpyxl.load_workbook(result_path, read_only=True, data_only=True)
    ws_case = wb_case["年度策略汇总"]
    values = list(ws_case.values)
    headers = list(values[0])
    records = [dict(zip(headers, row)) for row in values[1:] if row[0] is not None]
    wb_case.close()
    selected = next(
        (row for row in records if row.get("policy") == "0:00+6:00+12:00"),
        records[0],
    )

    summary.append({
        "case": name,
        "group": group,
        "K": k,
        "history_days": h,
        "lookahead_days": lookahead,
        "terminal_value_scale": terminal_scale,
        "terminal_value_yuan_per_kWh": float(selected["terminal_value_yuan_per_kwh"]),
        "days": int(selected["days"]),
        "start_SOC_kWh": float(selected["start_soc_kwh"]),
        "end_SOC_kWh": float(selected["end_soc_kwh"]),
        "end_near_1200_days": int(selected["end_near_min_days"]),
        "end_near_10800_days": int(selected["end_near_max_days"]),
        "SOC_continuity_error_kWh": float(selected["soc_continuity_error_kwh"]),
        "total_cost_yuan": float(selected["total_cost_yuan"]),
        "emergency_kwh": float(selected["emergency_kwh"]),
        "validation": "PASS",
    })
    current = summary[-1]
    print(
        f"  cost={current['total_cost_yuan']:.2f} 元 | "
        f"emergency={current['emergency_kwh']:.2f} kWh | "
        f"SOC={current['start_SOC_kWh']:.2f}->{current['end_SOC_kWh']:.2f} kWh | "
        f"continuity={current['SOC_continuity_error_kWh']:.2e} kWh | "
        f"{current['validation']}",
        flush=True,
    )

    (root / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "敏感性汇总"

if summary:
    ws.append(list(summary[0].keys()))
    for row in summary:
        ws.append(list(row.values()))

wb.save(root / "敏感性汇总.xlsx")
print("\n敏感性分析完成：", root.resolve())
print("汇总文件：", (root / "敏感性汇总.xlsx").resolve())
