"""C题问题一：微网日内购电与储能协同优化（最终版）。

核心模型
1. 确定性线性规划：最小化全天购电费用；
2. 储能物理约束：供需平衡、SOC状态转移、容量/功率限制、首尾SOC相等；
3. 两阶段层次优化：先最小化购电费，再在最优费用附近最小化总充放电量；
4. 残差验证：检查供需平衡和SOC状态方程；
5. 无储能基准：用于模型效果对照（默认不在终端主结果中打印）。

默认输出：问题1/result1.xlsx
终端与图片中的普通数值保留2位小数，result1.xlsx保留4位小数。
"""

from __future__ import annotations

import argparse
import shutil
import unicodedata
from dataclasses import dataclass
from datetime import datetime, time, timedelta
from pathlib import Path
from typing import Optional

import numpy as np
import openpyxl
from openpyxl.styles import Alignment, Font
from scipy.optimize import linprog
from scipy.sparse import csr_matrix, lil_matrix


BASE_DIR = Path(__file__).resolve().parent
PERIODS = 144
DT_MINUTES = 10
DT_HOURS = 1.0 / 6.0
BLOCK_SIZE = 24       # 4小时 = 24个10分钟调度单元
BLOCK_COUNT = 6
DECIMALS = 2
EXCEL_DECIMALS = 4


@dataclass(frozen=True)
class ModelParameters:
    capacity_min: float = 1200.0
    capacity_max: float = 10800.0
    initial_energy: float = 6000.0
    max_power: float = 5000.0
    charge_efficiency: float = 0.90
    discharge_efficiency: float = 0.90

    @property
    def max_energy_per_period(self) -> float:
        """单个10分钟调度单元允许的最大充/放电量，单位kWh。"""
        return self.max_power * DT_HOURS


@dataclass(frozen=True)
class InputData:
    timestamps: list[object]
    interval_labels: list[str]
    price: np.ndarray
    load_energy: np.ndarray
    pv_energy: np.ndarray


@dataclass(frozen=True)
class Solution:
    grid: np.ndarray
    charge: np.ndarray
    discharge: np.ndarray
    pv_used: np.ndarray
    energy: np.ndarray
    total_grid: float
    total_cost: float
    baseline_cost: float
    primary_cost: float
    secondary_used: bool
    max_balance_error: float
    max_state_error: float
    primary_throughput: float
    final_throughput: float
    simultaneous_periods: int
    curtailed_energy: float


def timestamp_to_end_minute(value: object) -> int:
    """把附件1中的时间标签转换为从当天0:00开始累计的分钟数。"""
    if isinstance(value, datetime):
        return value.hour * 60 + value.minute

    if isinstance(value, time):
        return value.hour * 60 + value.minute

    if isinstance(value, timedelta):
        return int(round(value.total_seconds() / 60.0))

    # Excel时间有时可能以一天的小数形式读取。
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        minute = int(round(float(value) * 24 * 60))
        if minute == 0:
            return 0
        return minute

    text = str(value).strip().replace("：", ":").replace(" ", "")

    if text in {"0:00+1", "00:00+1", "24:00", "24:00:00"}:
        return 1440

    if "+1" in text:
        base = text.replace("+1", "")
        parts = base.split(":")
        if len(parts) < 2:
            raise ValueError(f"无法解析时间标签：{value!r}")
        return 1440 + int(parts[0]) * 60 + int(parts[1])

    parts = text.split(":")
    if len(parts) < 2:
        raise ValueError(f"无法解析时间标签：{value!r}")

    return int(parts[0]) * 60 + int(parts[1])


def format_minute(minute: int) -> str:
    """将分钟数格式化为0:00、10:10、0:00+1等形式。"""
    if minute == 1440:
        return "24:00"
    if minute > 1440:
        minute_next = minute - 1440
        return f"{minute_next // 60}:{minute_next % 60:02d}+1"
    return f"{minute // 60}:{minute % 60:02d}"


def build_physical_interval_labels(timestamps: list[object]) -> list[str]:
    """按A解释生成0:00-0:10到23:50-24:00共144个物理区间。"""
    end_minutes = [timestamp_to_end_minute(v) for v in timestamps]
    expected = list(range(DT_MINUTES, 24 * 60 + DT_MINUTES, DT_MINUTES))

    if len(end_minutes) != PERIODS:
        raise ValueError(f"附件1时间点应为{PERIODS}个，实际为{len(end_minutes)}个。")

    for idx, (actual, wanted) in enumerate(zip(end_minutes, expected), start=1):
        if actual != wanted:
            raise ValueError(
                "附件1时间轴不符合A解释下的连续10分钟结束时刻："
                f"第{idx}个时间点实际为{format_minute(actual)}，"
                f"期望为{format_minute(wanted)}。"
            )

    labels: list[str] = []
    for end_minute in end_minutes:
        start_minute = end_minute - DT_MINUTES
        labels.append(f"{format_minute(start_minute)}-{format_minute(end_minute)}")
    return labels


def read_input(path: Path) -> InputData:
    if not path.exists():
        raise FileNotFoundError(f"找不到附件1：{path}")

    workbook = openpyxl.load_workbook(path, data_only=True, read_only=True)
    sheet = workbook.active
    rows = list(sheet.iter_rows(min_row=2, values_only=True))
    workbook.close()

    if len(rows) != PERIODS:
        raise ValueError(f"附件1应有{PERIODS}个时段，实际读取到{len(rows)}个。")

    timestamps = [row[0] for row in rows]
    interval_labels = build_physical_interval_labels(timestamps)

    try:
        matrix = np.asarray([[row[1], row[2], row[3]] for row in rows], dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError("附件1的电价、负载或光伏列存在非数值内容。") from exc

    if not np.all(np.isfinite(matrix)):
        raise ValueError("附件1的电价、负载或光伏列存在空值、NaN或无穷值。")
    if np.any(matrix < 0):
        raise ValueError("附件1的电价、负载和光伏预测不应出现负数。")

    return InputData(
        timestamps=timestamps,
        interval_labels=interval_labels,
        price=matrix[:, 0],
        load_energy=matrix[:, 1] * DT_HOURS,
        pv_energy=matrix[:, 2] * DT_HOURS,
    )


# 两阶段层次线性规划
def solve_problem(data: InputData, params: ModelParameters) -> Solution:
    t_count = len(data.price)
    n_variables = 5 * t_count + 1

    # 决策变量在总向量x中的位置：G, C, D, PV_use, E
    grid = slice(0, t_count)
    charge = slice(t_count, 2 * t_count)
    discharge = slice(2 * t_count, 3 * t_count)
    pv_used = slice(3 * t_count, 4 * t_count)
    energy_start = 4 * t_count

    # 144个供需平衡 + 144个SOC状态转移
    a_eq = lil_matrix((2 * t_count, n_variables), dtype=float)
    b_eq = np.zeros(2 * t_count, dtype=float)

    for t in range(t_count):
        # G_t + PVuse_t + D_t = L_t + C_t
        a_eq[t, grid.start + t] = 1.0
        a_eq[t, charge.start + t] = -1.0
        a_eq[t, discharge.start + t] = 1.0
        a_eq[t, pv_used.start + t] = 1.0
        b_eq[t] = data.load_energy[t]

        # E_{t+1} = E_t + eta_c*C_t - D_t/eta_d
        row = t_count + t
        a_eq[row, energy_start + t] = -1.0
        a_eq[row, energy_start + t + 1] = 1.0
        a_eq[row, charge.start + t] = -params.charge_efficiency
        a_eq[row, discharge.start + t] = 1.0 / params.discharge_efficiency

    # 变量上下界
    bounds: list[tuple[Optional[float], Optional[float]]] = []
    bounds.extend([(0.0, None)] * t_count)  # G_t >= 0，只允许购电
    bounds.extend([(0.0, params.max_energy_per_period)] * t_count)  # C_t
    bounds.extend([(0.0, params.max_energy_per_period)] * t_count)  # D_t
    bounds.extend([(0.0, float(v)) for v in data.pv_energy])  # PV_use_t

    # E_0=6000；E_1...E_143在允许范围内；E_144=6000
    bounds.append((params.initial_energy, params.initial_energy))
    bounds.extend([(params.capacity_min, params.capacity_max)] * (t_count - 1))
    bounds.append((params.initial_energy, params.initial_energy))

    # 第一阶段：最低购电费
    cost_vector = np.zeros(n_variables, dtype=float)
    cost_vector[grid] = data.price

    primary = linprog(
        cost_vector,
        A_eq=a_eq.tocsr(),
        b_eq=b_eq,
        bounds=bounds,
        method="highs",
    )
    if not primary.success:
        raise RuntimeError(f"第一阶段购电费用最小化失败：{primary.message}")

    # 第二阶段：费用保持最优，再最小化总充放电量
    tolerance = max(1e-7, abs(primary.fun) * 1e-10)

    throughput_vector = np.zeros(n_variables, dtype=float)
    throughput_vector[charge] = 1.0
    throughput_vector[discharge] = 1.0

    a_ub = csr_matrix(cost_vector.reshape(1, -1))
    b_ub = np.asarray([primary.fun + tolerance], dtype=float)

    secondary = linprog(
        throughput_vector,
        A_ub=a_ub,
        b_ub=b_ub,
        A_eq=a_eq.tocsr(),
        b_eq=b_eq,
        bounds=bounds,
        method="highs",
    )

    result = secondary if secondary.success else primary
    x = np.where(np.abs(result.x) < 1e-8, 0.0, result.x)

    grid_values = x[grid]
    charge_values = x[charge]
    discharge_values = x[discharge]
    pv_used_values = x[pv_used]
    energy_values = x[energy_start : energy_start + t_count + 1]

    # 残差验证
    balance_residual = (
        grid_values
        + pv_used_values
        + discharge_values
        - data.load_energy
        - charge_values
    )
    state_residual = (
        energy_values[1:]
        - energy_values[:-1]
        - params.charge_efficiency * charge_values
        + discharge_values / params.discharge_efficiency
    )

    max_balance_error = float(np.max(np.abs(balance_residual)))
    max_state_error = float(np.max(np.abs(state_residual)))

    if max(max_balance_error, max_state_error) > 1e-5:
        raise RuntimeError(
            "求解结果未通过数值校验："
            f"最大供需平衡误差={max_balance_error:.3e}，"
            f"最大SOC状态方程误差={max_state_error:.3e}。"
        )

    # 无储能基准
    baseline_grid = np.maximum(data.load_energy - data.pv_energy, 0.0)

    return Solution(
        grid=grid_values,
        charge=charge_values,
        discharge=discharge_values,
        pv_used=pv_used_values,
        energy=energy_values,
        total_grid=float(grid_values.sum()),
        total_cost=float(data.price @ grid_values),
        baseline_cost=float(data.price @ baseline_grid),
        primary_cost=float(primary.fun),
        secondary_used=bool(secondary.success),
        max_balance_error=max_balance_error,
        max_state_error=max_state_error,
        primary_throughput=float(primary.x[charge].sum() + primary.x[discharge].sum()),
        final_throughput=float(charge_values.sum() + discharge_values.sum()),
        simultaneous_periods=int(np.count_nonzero((charge_values > 1e-6) & (discharge_values > 1e-6))),
        curtailed_energy=float((data.pv_energy - pv_used_values).sum()),
    )


def write_result(template_path: Path, output_path: Path, solution: Solution) -> None:
    """按官方result1.xlsx模板写入结果。
    """
    if not template_path.exists():
        raise FileNotFoundError(f"找不到官方result1模板：{template_path}")
    if template_path.resolve() == output_path.resolve():
        raise ValueError("输出文件不能覆盖官方原始模板。")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(template_path, output_path)
    workbook = openpyxl.load_workbook(output_path)

    if "计划购电量" not in workbook.sheetnames or "充放电量" not in workbook.sheetnames:
        workbook.close()
        raise ValueError("官方result1模板必须包含“计划购电量”和“充放电量”两个工作表。")

    purchase_sheet = workbook["计划购电量"]
    storage_sheet = workbook["充放电量"]

    if purchase_sheet.max_row - 1 != PERIODS:
        workbook.close()
        raise ValueError("result1模板的“计划购电量”工作表不是144个数据行。")

    # 计划购电量。
    for row, value in enumerate(solution.grid, start=2):
        cell = purchase_sheet.cell(row=row, column=2, value=round(float(value), EXCEL_DECIMALS))
        cell.number_format = "0.0000"

    # 4小时充放电量。
    charge_blocks = solution.charge.reshape(BLOCK_COUNT, BLOCK_SIZE).sum(axis=1)
    discharge_blocks = solution.discharge.reshape(BLOCK_COUNT, BLOCK_SIZE).sum(axis=1)

    for row, (charge_value, discharge_value) in enumerate(
        zip(charge_blocks, discharge_blocks), start=2
    ):
        for column, value in ((2, charge_value), (3, discharge_value)):
            cell = storage_sheet.cell(row=row, column=column, value=round(float(value), EXCEL_DECIMALS))
            cell.number_format = "0.0000"
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.font = Font(name="Arial", size=11, color="000000")

    # 0:00和24:00储电量
    for row, value in ((2, solution.energy[0]), (3, solution.energy[-1])):
        cell = storage_sheet.cell(row=row, column=5, value=round(float(value), EXCEL_DECIMALS))
        cell.number_format = "0.0000"
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.font = Font(name="Arial", size=11, color="000000")

    for column in ("B", "C", "E"):
        storage_sheet.column_dimensions[column].width = max(
            storage_sheet.column_dimensions[column].width or 0, 16
        )

    workbook.active = workbook.sheetnames.index("充放电量")
    workbook.save(output_path)
    workbook.close()


def _display_width(text: object) -> int:
    """计算终端中中英文混排字符串的显示宽度。"""
    s = str(text)
    width = 0
    for ch in s:
        width += 2 if unicodedata.east_asian_width(ch) in {"W", "F", "A"} else 1
    return width


def _pad(text: object, width: int, align: str = "left") -> str:
    s = str(text)
    pad_len = max(0, width - _display_width(s))
    if align == "right":
        return " " * pad_len + s
    if align == "center":
        left = pad_len // 2
        right = pad_len - left
        return " " * left + s + " " * right
    return s + " " * pad_len


def _print_table(rows: list[list[str]], widths: list[int], aligns: list[str]) -> None:
    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    print(border)
    for row in rows:
        cells = [f" {_pad(v, w, a)} " for v, w, a in zip(row, widths, aligns)]
        print("|" + "|".join(cells) + "|")
        print(border)


def print_final_tables(data: InputData, solution: Solution) -> None:
    requested = [
        "10:00-10:10",
        "12:00-12:10",
        "14:00-14:10",
        "16:00-16:10",
        "18:00-18:10",
        "20:00-20:10",
    ]

    lookup = dict(zip(data.interval_labels, solution.grid))
    missing = [label for label in requested if label not in lookup]
    if missing:
        raise RuntimeError(f"A解释时间轴中缺少题目指定区间：{missing}")

    v = {label: f"{lookup[label]:.{DECIMALS}f}" for label in requested}

    print("\n表1  微网在指定时间段的购电量及全天的购电量和购电费")
    table1_rows = [
        ["时间段", "购电量(kWh)", "时间段", "购电量(kWh)", "时间段", "购电量(kWh)"],
        ["10:00-10:10", v["10:00-10:10"], "12:00-12:10", v["12:00-12:10"], "14:00-14:10", v["14:00-14:10"]],
        ["16:00-16:10", v["16:00-16:10"], "18:00-18:10", v["18:00-18:10"], "20:00-20:10", v["20:00-20:10"]],
    ]
    _print_table(
        table1_rows,
        widths=[13, 16, 13, 16, 13, 16],
        aligns=["left", "right", "left", "right", "left", "right"],
    )

    _print_table(
        [["全天购电量(kWh)", f"{solution.total_grid:.{DECIMALS}f}",
          "全天购电费(元)", f"{solution.total_cost:.{DECIMALS}f}"]],
        widths=[22, 18, 22, 18],
        aligns=["center", "right", "center", "right"],
    )

    charge_blocks = solution.charge.reshape(BLOCK_COUNT, BLOCK_SIZE).sum(axis=1)
    discharge_blocks = solution.discharge.reshape(BLOCK_COUNT, BLOCK_SIZE).sum(axis=1)
    block_labels = [
        "0:00-4:00",
        "4:00-8:00",
        "8:00-12:00",
        "12:00-16:00",
        "16:00-20:00",
        "20:00-24:00",
    ]

    print("\n表2  储能设备在指定时间段的充放电量及0:00和24:00的储电量")
    table2_rows = [
        ["时间段", "充电量(kWh)", "放电量(kWh)", "时间段", "充电量(kWh)", "放电量(kWh)"],
        [block_labels[0], f"{charge_blocks[0]:.{DECIMALS}f}", f"{discharge_blocks[0]:.{DECIMALS}f}",
         block_labels[1], f"{charge_blocks[1]:.{DECIMALS}f}", f"{discharge_blocks[1]:.{DECIMALS}f}"],
        [block_labels[2], f"{charge_blocks[2]:.{DECIMALS}f}", f"{discharge_blocks[2]:.{DECIMALS}f}",
         block_labels[3], f"{charge_blocks[3]:.{DECIMALS}f}", f"{discharge_blocks[3]:.{DECIMALS}f}"],
        [block_labels[4], f"{charge_blocks[4]:.{DECIMALS}f}", f"{discharge_blocks[4]:.{DECIMALS}f}",
         block_labels[5], f"{charge_blocks[5]:.{DECIMALS}f}", f"{discharge_blocks[5]:.{DECIMALS}f}"],
    ]
    _print_table(
        table2_rows,
        widths=[13, 16, 16, 13, 16, 16],
        aligns=["left", "right", "right", "left", "right", "right"],
    )

    _print_table(
        [["0:00储电量(kWh)", f"{solution.energy[0]:.{DECIMALS}f}",
          "24:00储电量(kWh)", f"{solution.energy[-1]:.{DECIMALS}f}"]],
        widths=[22, 18, 22, 18],
        aligns=["center", "right", "center", "right"],
    )


def print_verbose_checks(solution: Solution) -> None:
    """只有显式添加--verbose时才打印，不影响默认正式输出。"""
    print("\n[校验信息]")
    print(f"第一阶段最低购电费：{solution.primary_cost:.{DECIMALS}f} 元")
    print(f"第二阶段层次优化：{'成功' if solution.secondary_used else '未成功，已回退第一阶段解'}")
    print(f"无储能基准购电费：{solution.baseline_cost:.{DECIMALS}f} 元")
    print(f"相对无储能节省：{solution.baseline_cost - solution.total_cost:.{DECIMALS}f} 元")
    print(f"最大供需平衡残差：{solution.max_balance_error:.2e}")
    print(f"最大SOC状态方程残差：{solution.max_state_error:.2e}")


def _visualize_results_legacy(data: InputData, solution: Solution, output_dir: Path,
                              params: ModelParameters) -> None:
    """生成170 mm宽、54–62 mm高的横向论文图；数据按A解释对齐。

    区间量使用阶梯线，储电量使用145个边界点。数值由原始精度结果计算。
    图题及审计数据另存说明文件，避免占据论文图片高度。
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from matplotlib.patches import FancyBboxPatch
    from matplotlib.ticker import MaxNLocator

    available = {font.name for font in font_manager.fontManager.ttflist}
    font = next((f for f in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC")
                 if f in available), None)
    if font is None:
        raise RuntimeError("绘图需要微软雅黑、黑体或Noto Sans CJK SC中文字体。")
    output_dir.mkdir(parents=True, exist_ok=True)
    c = dict(grid="#2F80ED", pv="#F2C14E", load="#16324F", charge="#18A999",
             discharge="#E76F51", soc="#7357C6", base="#9AA3AE")
    s = solution
    edges = np.arange(PERIODS + 1) * DT_HOURS
    mid = (edges[:-1] + edges[1:]) / 2
    baseline = np.maximum(data.load_energy - data.pv_energy, 0)
    saving = s.baseline_cost - s.total_cost
    rate = f"{100*saving/s.baseline_cost:.4f}%" if s.baseline_cost > 0 else "不适用"
    captions = []
    low, high = np.quantile(data.price, [0.25, 0.75])

    def callout(ax, x, y, text, location, color):
        """固定在轴内留白位置的细引线标注，避免跟随数据挤出边界。"""
        ax.plot(x, y, "o", color=color, ms=3, zorder=7, clip_on=False)
        ax.annotate(text, (x, y), xycoords="data", xytext=location,
                    textcoords="axes fraction", fontsize=6.5, color=color,
                    ha="left", va="top", linespacing=1.3,
                    arrowprops=dict(arrowstyle="-", color=color, lw=0.6,
                                    connectionstyle="arc3,rad=0"),
                    bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.5), zorder=8)

    def strategy_bands(ax):
        for i in range(PERIODS):
            color = (c["charge"] if s.charge[i]>1e-6 and data.price[i]<=low
                     else c["discharge"] if s.discharge[i]>1e-6 and data.price[i]>=high else None)
            if color:
                ax.axvspan(edges[i],edges[i+1],color=color,alpha=0.07,lw=0)

    def canvas(n, height=60, gap=0.40):
        fig, axes = plt.subplots(1, n, figsize=(170/25.4, height/25.4), squeeze=False)
        # 标题、图例各有独立的轴外空间，不覆盖数据与峰值标注。
        fig.subplots_adjust(left=0.10, right=0.975, top=0.76, bottom=0.19, wspace=gap)
        return fig, axes[0]

    def decorate(ax, title, ylabel, time=True):
        ax.set_title(title, loc="left", fontsize=8.5, fontweight="bold", y=1.22, pad=0)
        ax.set_facecolor("white")
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_color("#CBD6E0")
        ax.grid(axis="y", color="#E6EBF0", lw=0.45, linestyle=(0, (2, 3)))
        ax.set_axisbelow(True)
        ax.tick_params(length=2.5, width=0.6, color="#AEBECC", labelsize=7)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
        ax.set_ylabel(ylabel, fontsize=8, labelpad=3)
        if time:
            ax.set_xlim(0, 24)
            ax.set_xticks([0, 8, 16, 24])
            ax.set_xlabel("时间/h", fontsize=8, labelpad=3)

    def step(ax, v, color, label=None, ls="-"):
        ax.stairs(v, edges, baseline=None, color=color, label=label, lw=1.15, linestyle=ls)

    def legend(ax, n=1, backgrounds=(), fontsize=7):
        from matplotlib.patches import Patch
        handles, labels = ax.get_legend_handles_labels()
        for label, color, alpha in backgrounds:
            handles.append(Patch(facecolor=color, alpha=alpha, edgecolor="none"))
            labels.append(label)
        ax.legend(handles, labels, loc="lower left", bbox_to_anchor=(0, 1.035), ncol=n,
                  fontsize=fontsize, frameon=False, handlelength=1.3,
                  columnspacing=0.8, borderaxespad=0, labelspacing=0.3)

    def save(fig, name, caption):
        for ext in ("png", "svg", "pdf"):
            fig.savefig(output_dir / f"{name}.{ext}", dpi=600, facecolor="white")
        captions.append(f"{name}\n{caption}\n")
        plt.close(fig)

    style = {"font.family": "sans-serif", "font.sans-serif": [font, "DejaVu Sans"],
             "axes.unicode_minus": False, "font.size": 8, "text.color": c["load"],
             "axes.labelcolor": c["load"], "xtick.color": "#546879", "ytick.color": "#546879",
             "svg.fonttype": "none", "pdf.fonttype": 42, "axes.linewidth": 0.6}
    with plt.rc_context(style):
        fig, axes = canvas(3, 62, 0.63)
        load, pv = data.load_energy/DT_HOURS, data.pv_energy/DT_HOURS
        ax = axes[0]
        decorate(ax, "(a) 负载与光伏", "功率/kW")
        ax.stairs(pv, edges, fill=True, color=c["pv"], alpha=0.25)
        step(ax, load, c["load"], "负载", "--")
        step(ax, pv, c["pv"], "光伏")
        ax.set_ylim(0, max(load.max(), pv.max())*1.65)
        legend(ax, 2)
        i=int(np.argmax(pv))
        callout(ax,mid[i],pv[i],f"光伏峰值\n{pv[i]:.4f} kW",(0.08,0.96),c["load"])
        ax = axes[1]
        decorate(ax, "(b) 分时电价", "电价/(元/kWh)")
        step(ax, data.price, c["grid"])
        ax.set_ylim(0, data.price.max()*1.65)
        for i, price in enumerate(data.price):
            if price <= low or price >= high:
                ax.axvspan(edges[i], edges[i+1], color=c["grid"] if price<=low else c["discharge"],
                           alpha=0.065, lw=0)
        legend(ax,2,[("低价≤Q25",c["grid"],0.065),
                     ("高价≥Q75",c["discharge"],0.065)],fontsize=6)
        imin,imax=int(np.argmin(data.price)),int(np.argmax(data.price))
        callout(ax,mid[imax],data.price[imax],f"峰值 {data.price[imax]:.4f}",(0.18,0.97),c["discharge"])
        callout(ax,mid[imin],data.price[imin],f"谷值 {data.price[imin]:.4f}",(0.03,0.65),c["grid"])
        ax = axes[2]
        decorate(ax, "(c) 净负荷", "净负荷/kW")
        net = load-pv
        ax.stairs(np.maximum(net, 0), edges, fill=True, color=c["grid"], alpha=0.25)
        ax.stairs(np.minimum(net, 0), edges, fill=True, color=c["pv"], alpha=0.55)
        step(ax, net, c["load"])
        ax.axhline(0, color="#8194A5", lw=0.65)
        surplus=float(np.maximum(data.pv_energy-data.load_energy,0).sum())
        legend(ax,2,[("用电缺口",c["grid"],0.25),
                     ("光伏余量",c["pv"],0.55)],fontsize=6.5)
        save(fig, "fig1_daily_energy_profile",
             "日内能源环境。(a)负载与光伏；(b)分时电价；(c)净负荷。"
             "电价上下四分位区间以浅橙、浅蓝表示；Q25、Q75分别为当天电价的25%、75%分位数。"
             f"最低电价{data.price.min():.4f}元/kWh，最高{data.price.max():.4f}元/kWh。"
             f"日内光伏余量{surplus:.4f}kWh。")

        fig, (ax,) = canvas(1, 54)
        decorate(ax, "日内购电与光伏利用", "区间电量/kWh")
        ax.set_title("日内购电与光伏利用", loc="left", fontsize=8.5,
                     fontweight="bold", y=1.30, pad=0)
        strategy_bands(ax)
        ax.stairs(s.pv_used, edges, fill=True, color=c["pv"], alpha=0.35, label="利用光伏")
        step(ax, s.grid, c["grid"], "外网购电")
        step(ax, data.load_energy, c["load"], "负载需求", "--")
        ax.set_ylim(0, max(s.grid.max(),s.pv_used.max(),data.load_energy.max())*1.50)
        ax.set_xticks(np.arange(0, 25, 4))
        legend(ax,5,[("背景：低价充电",c["charge"],0.07),
                     ("背景：高价放电",c["discharge"],0.07)])
        i=int(np.argmax(s.grid))
        callout(ax,mid[i],s.grid[i],f"购电峰值 {s.grid[i]:.4f} kWh",(0.07,0.95),c["grid"])
        pv_i=int(np.argmax(s.pv_used))
        callout(ax,mid[pv_i],s.pv_used[pv_i],"午间光伏利用",(0.48,0.84),"#94700D")
        active=np.flatnonzero((s.discharge>1e-6)&(data.price>=high))
        if len(active):
            i=int(active[np.argmax(data.price[active])])
            callout(ax,mid[i],s.grid[i],"高价放电，减少购电",(0.73,0.78),c["discharge"])
        save(fig, "fig2_optimal_dispatch",
             "日内购电与光伏利用。每个区间10分钟；供电组合还包含储能放电，需求侧还包含储能充电。"
             f"全天购电{s.total_grid:.4f}kWh。浅青表示低价充电，浅橙表示高价放电。")

        fig, axes = canvas(2, 60, 0.38)
        ax = axes[0]
        decorate(ax, "(a) 充放电策略", "区间电量/kWh")
        strategy_bands(ax)
        ax.bar(mid,s.charge,width=DT_HOURS*0.82,color=c["charge"],label="充电")
        ax.bar(mid,-s.discharge,width=DT_HOURS*0.82,color=c["discharge"],label="放电")
        ax.axhline(0,color="#8194A5",lw=0.7)
        ax.set_ylim(-params.max_energy_per_period*1.85,params.max_energy_per_period*1.9)
        legend(ax,4,[("低价充电背景",c["charge"],0.07),
                     ("高价放电背景",c["discharge"],0.07)],fontsize=6)
        i,j=int(np.argmax(s.charge)),int(np.argmax(s.discharge))
        callout(ax,mid[i],s.charge[i],f"最大充电 {s.charge[i]:.4f}",(0.12,0.97),c["charge"])
        callout(ax,mid[j],-s.discharge[j],f"最大放电 {s.discharge[j]:.4f}",(0.36,0.15),c["discharge"])
        ax=axes[1]
        decorate(ax, "(b) 储电量与安全边界", "储电量/kWh")
        ax.plot(edges,s.energy,color=c["soc"],lw=1.4)
        ax.fill_between(edges,params.capacity_min,s.energy,color=c["soc"],alpha=0.10)
        legend(ax,1,[("填充：高于最低安全电量的部分",c["soc"],0.10)],fontsize=6.5)
        for bound in (params.capacity_min,params.capacity_max):
            ax.axhline(bound,color=c["soc"],ls="--",lw=0.7,alpha=0.7)
        ax.axhline(params.initial_energy,color=c["base"],ls=":",lw=0.8)
        ax.plot([0,24],[s.energy[0],s.energy[-1]],"o",color=c["soc"],ms=3,clip_on=False)
        ax.set_ylim(-1200,params.capacity_max*1.42)
        i,j=int(np.argmax(s.energy)),int(np.argmin(s.energy))
        callout(ax,edges[i],s.energy[i],f"上界 {params.capacity_max:.4f}",(0.03,0.95),c["soc"])
        callout(ax,edges[j],s.energy[j],f"下界 {params.capacity_min:.4f}",(0.52,0.30),c["soc"])
        save(fig,"fig2b_storage_dispatch",
             "储能调度。(a)充电为正、放电为负；(b)储电轨迹。"
             f"安全边界为{params.capacity_min:.4f}–{params.capacity_max:.4f}kWh，"
             f"日首尾均为{s.energy[0]:.4f}kWh。")

        fig,axes=canvas(2,62,0.4)
        ax=axes[0]
        decorate(ax,"(a) 累计购电费用","累计费用/元")
        b=np.r_[0,np.cumsum(data.price*baseline)]
        o=np.r_[0,np.cumsum(data.price*s.grid)]
        ax.plot(edges,b,color=c["base"],ls="--",lw=1.3,label="无储能")
        ax.plot(edges,o,color=c["grid"],lw=1.4,label="优化后")
        ax.fill_between(edges,b,o,where=b>=o,interpolate=True,color=c["charge"],alpha=0.12)
        legend(ax,3,[("累计费用节省区",c["charge"],0.12)],fontsize=6.5)
        ax.set_ylim(0,max(b.max(),o.max())*1.4)
        callout(ax,24,b[-1],f"无储能 {b[-1]:.4f}",(0.32,0.79),"#697B8C")
        callout(ax,24,o[-1],f"优化后 {o[-1]:.4f}",(0.33,0.40),c["grid"])
        ax=axes[1]
        decorate(ax,"(b) 四小时购电费用","购电费用/元",time=False)
        x=np.arange(6)
        ax.bar(x-0.19,(data.price*baseline).reshape(6,24).sum(axis=1),0.36,
               color="#CBD2DA",edgecolor="#8F9BA8",linewidth=0.45,label="无储能")
        ax.bar(x+0.19,(data.price*s.grid).reshape(6,24).sum(axis=1),0.36,color=c["grid"],label="优化后")
        ax.set_xticks(x,["0–4","4–8","8–12","12–16","16–20","20–24"])
        ax.set_xlabel("时段/h",fontsize=8)
        block_base=(data.price*baseline).reshape(6,24).sum(axis=1)
        block_opt=(data.price*s.grid).reshape(6,24).sum(axis=1)
        top=np.maximum(block_base,block_opt)
        ax.set_ylim(0,top.max()*1.35)
        for k,delta in enumerate((block_base-block_opt)/1000):
            ax.text(k,top[k]+top.max()*0.04,f"{delta:+.4f}",ha="center",va="bottom",
                    rotation=0,fontsize=6,color=c["charge"] if delta>=0 else c["discharge"])
        ax.text(0,1.06,"柱上：节省费用/千元",transform=ax.transAxes,va="bottom",fontsize=6.5)
        save(fig,"fig3_economic_benefit",
             f"经济性对比。无储能费用{s.baseline_cost:.4f}元；优化后{s.total_cost:.4f}元；"
             f"节省{saving:.4f}元，下降{rate}。")

        fig,axes=canvas(2,58,0.38)
        residuals=(s.grid+s.pv_used+s.discharge-data.load_energy-s.charge,
                   np.diff(s.energy)-params.charge_efficiency*s.charge+s.discharge/params.discharge_efficiency)
        # 两类残差采用共同量级和对称范围；每个点均为原始时段残差，不平滑。
        joint_max=max(float(np.max(np.abs(res))) for res in residuals)
        exp=int(np.floor(np.log10(joint_max))) if joint_max>0 else 0
        scale=10.0**exp
        extent=max(1.0,float(np.ceil(joint_max/scale)))
        for ax,res,title,col in zip(axes,residuals,("(a) 供需平衡残差","(b) 储能状态残差"),(c["grid"],c["soc"])):
            maximum=float(np.max(np.abs(res)))
            decorate(ax,title,rf"残差/($10^{{{exp}}}$ kWh)")
            values=res/scale
            ax.plot(mid,values,color=col,lw=0.85,zorder=3)
            ax.axhline(0,color="#697D90",lw=0.8,zorder=1)
            ax.set_ylim(-extent*1.15,extent*1.15)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=5,symmetric=True,integer=True))
            ax.set_xticks(np.arange(0,25,4))
            peak=int(np.argmax(np.abs(res)))
            ax.scatter(mid[peak],values[peak],s=17,facecolors="white",edgecolors=col,
                       linewidths=0.9,zorder=4)
            coefficient,exponent=f"{maximum:.4e}".split("e")
            ax.text(0,1.06,rf"最大绝对残差  ${coefficient}\times10^{{{int(exponent)}}}$ kWh",
                    transform=ax.transAxes,va="bottom",fontsize=6.7,color=col)
        passed=max(s.max_balance_error,s.max_state_error)<1e-5
        save(fig,"fig4_model_validation",
             f"数值校验。供需平衡最大残差{s.max_balance_error:.4e}kWh；"
             f"状态方程最大残差{s.max_state_error:.4e}kWh。校验阈值1.0000e-05 kWh。"
             "细折线连接各10分钟时段的原始残差（未平滑），空心圆突出最大绝对残差；两图使用相同纵轴尺度。"
             f"残差校验：{'通过' if passed else '未通过'}。")

    audit = [
        f"首尾储电量：{s.energy[0]:.4f} / {s.energy[-1]:.4f} kWh",
        f"储电量范围：{s.energy.min():.4f}–{s.energy.max():.4f} kWh",
        f"最大充放电量：{s.charge.max():.4f} / {s.discharge.max():.4f} kWh",
        f"同时充放电时段数：{s.simultaneous_periods}",
        f"弃光量：{s.curtailed_energy:.4f} kWh",
        f"第一阶段 / 最终吞吐量：{s.primary_throughput:.4f} / {s.final_throughput:.4f} kWh",
        f"第二阶段成功：{s.secondary_used}",
    ]
    (output_dir/"figure_captions.txt").write_text(
        "\n".join(captions)+"\n约束审计（供正文表格使用）\n"+"\n".join(audit),encoding="utf-8")
    print(f"\n五组横向论文图已保存至：{output_dir.resolve()}（PNG / SVG / PDF）")


def visualize_results(data: InputData, solution: Solution, output_dir: Path,
                      params: ModelParameters) -> None:
    """绘制低饱和、少装饰、适合论文正文的横向结果图。"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from matplotlib.patches import FancyBboxPatch
    from matplotlib.ticker import MaxNLocator

    available = {item.name for item in font_manager.fontManager.ttflist}
    font = next((name for name in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC")
                 if name in available), None)
    if font is None:
        raise RuntimeError("绘图需要微软雅黑、黑体或Noto Sans CJK SC中文字体。")
    output_dir.mkdir(parents=True, exist_ok=True)

    color = {
        "grid": "#4C78A8", "pv": "#D9A441", "load": "#334E5C",
        "charge": "#4E9483", "discharge": "#C56B4E", "soc": "#756A9B",
        "base": "#9AA3A8", "text": "#2F3E46", "muted": "#71808A",
        "rule": "#D9E0E4", "paper": "#FFFFFF", "panel": "#FFFFFF",
    }
    s = solution
    edges = np.arange(PERIODS + 1) * DT_HOURS
    mid = (edges[:-1] + edges[1:]) / 2
    baseline = np.maximum(data.load_energy - data.pv_energy, 0)
    saving = s.baseline_cost - s.total_cost
    saving_rate = 100 * saving / s.baseline_cost if s.baseline_cost > 0 else np.nan
    captions: list[str] = []
    low, high = np.quantile(data.price, [0.25, 0.75])

    style = {
        "font.family": "sans-serif", "font.sans-serif": [font, "DejaVu Sans"],
        "axes.unicode_minus": False, "font.size": 8, "text.color": color["text"],
        "axes.labelcolor": color["text"], "xtick.color": color["muted"],
        "ytick.color": color["muted"], "svg.fonttype": "none", "pdf.fonttype": 42,
        "axes.linewidth": 0.7, "legend.frameon": False,
        "figure.facecolor": color["paper"], "savefig.facecolor": color["paper"],
    }

    def style_axis(ax, ylabel="", xlabel="时间 / h", show_grid=True):
        ax.set_facecolor(color["panel"])
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_color(color["rule"])
        ax.spines[["left", "bottom"]].set_linewidth(0.7)
        if show_grid:
            ax.grid(axis="y", color=color["rule"], lw=0.45, alpha=0.72)
        ax.set_axisbelow(True)
        ax.tick_params(length=2.5, width=0.6, color=color["rule"], labelsize=7.5)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
        if ylabel:
            ax.set_ylabel(ylabel, fontsize=8, labelpad=4)
        if xlabel:
            ax.set_xlim(0, 24)
            ax.set_xticks(np.arange(0, 25, 4))
            ax.set_xlabel(xlabel, fontsize=8, labelpad=3)

    def title(ax, text):
        ax.text(0.5, 1.055, text, transform=ax.transAxes, ha="center", va="bottom",
                fontsize=9.5, fontweight="bold", color=color["text"])

    def step(ax, values, line_color, label=None, linestyle="-"):
        ax.stairs(values, edges, color=line_color, label=label, lw=1.45,
                  linestyle=linestyle)

    def rounded_bars(ax, x_values, heights, width, fill, label=None, zorder=2):
        """用圆角矩形绘制正负柱与分组柱。"""
        patches = []
        for x_value, height in zip(np.asarray(x_values), np.asarray(heights)):
            if abs(float(height)) < 1e-12:
                continue
            bottom = min(0.0, float(height))
            patch = FancyBboxPatch(
                (float(x_value) - width / 2, bottom), width, abs(float(height)),
                boxstyle=f"round,pad=0,rounding_size={width * 0.10}",
                mutation_aspect=max(abs(float(height)) / max(width, 1e-9), 1.0),
                facecolor=fill, edgecolor="none", linewidth=0, zorder=zorder,
                label=label if not patches else None,
            )
            ax.add_patch(patch)
            patches.append(patch)
        return patches

    def legend(ax, columns=1, location="upper left"):
        ax.legend(loc=location, ncol=columns, fontsize=7.2, frameon=False,
                  handlelength=1.7, columnspacing=1.1, borderaxespad=0.2)

    def shade_runs(ax, mask, fill, alpha):
        """把连续价格区间合并为背景带，避免144条细色块造成条纹感。"""
        start = None
        flags = np.r_[np.asarray(mask, dtype=bool), False]
        for index, active in enumerate(flags):
            if active and start is None:
                start = index
            elif not active and start is not None:
                ax.axvspan(edges[start], edges[index], color=fill, alpha=alpha, lw=0, zorder=0)
                start = None

    def save(fig, name, caption):
        fig.patch.set_facecolor(color["paper"])
        for extension in ("svg", "pdf", "png"):
            fig.savefig(output_dir / f"{name}.{extension}", dpi=600,
                        facecolor=color["paper"], bbox_inches="tight", pad_inches=0.04)
        captions.append(f"{name}\n{caption}\n")
        plt.close(fig)

    with plt.rc_context(style):
        # 图1：能源环境与最优响应。主图说明错配，副图说明购电如何响应价格。
        load = data.load_energy / DT_HOURS
        pv = data.pv_energy / DT_HOURS
        net = load - pv
        fig, (ax1, ax2) = plt.subplots(
            2, 1, figsize=(170 / 25.4, 84 / 25.4),
            gridspec_kw={"height_ratios": [2.35, 1.55], "hspace": 0.48},
        )
        fig.subplots_adjust(left=0.09, right=0.91, top=0.90, bottom=0.15)
        title(ax1, "日内能源环境")
        ax1.texts[-1].set_y(1.09)
        ax1.fill_between(mid, 0, pv, step="mid", color=color["pv"], alpha=0.24, lw=0)
        step(ax1, load, color["load"], "负载")
        step(ax1, pv, color["pv"], "光伏")
        step(ax1, net, color["muted"], "净负荷", "--")
        style_axis(ax1, "功率 / kW", xlabel="")
        ax1.set_xticklabels([])
        ax1.axhline(0, color=color["rule"], lw=0.7)
        ax1.set_ylim(min(0, net.min()) * 1.18, max(load.max(), pv.max()) * 1.14)
        legend(ax1, 3)
        peak_pv = int(np.argmax(pv))
        ax1.annotate(
            f"光伏峰值 {pv[peak_pv]:.{DECIMALS}f} kW", (mid[peak_pv], pv[peak_pv]),
            xytext=(8, 7), textcoords="offset points", fontsize=6.7, color="#87661F",
            arrowprops=dict(arrowstyle="-", lw=0.6, color="#87661F"),
        )
        ax2.text(0.5, 1.29, "分时电价与外网购电响应",
                 transform=ax2.transAxes, ha="center", va="bottom",
                 fontsize=9.5, fontweight="bold", color=color["text"])
        shade_runs(ax2, data.price <= low, color["grid"], 0.07)
        shade_runs(ax2, data.price >= high, color["discharge"], 0.07)
        ax2.fill_between(mid, 0, s.grid, step="mid", color=color["grid"], alpha=0.11, lw=0)
        step(ax2, s.grid, color["grid"], "外网购电")
        style_axis(ax2, "购电量 / kWh")
        ax2.set_ylim(0, s.grid.max() * 1.18)
        price_ax = ax2.twinx()
        price_ax.stairs(data.price, edges, color=color["discharge"], lw=1.15,
                        alpha=0.88, label="电价")
        price_ax.set_ylim(0, data.price.max() * 1.14)
        price_ax.set_ylabel("电价 / (元·kWh$^{-1}$)", fontsize=7.2, color=color["discharge"])
        price_ax.tick_params(axis="y", labelsize=6.6, colors=color["discharge"], length=2)
        price_ax.spines[["top", "left"]].set_visible(False)
        price_ax.spines["right"].set_color(color["rule"])
        handles1, labels1 = ax2.get_legend_handles_labels()
        handles2, labels2 = price_ax.get_legend_handles_labels()
        ax2.legend(handles1 + handles2, labels1 + labels2, loc="lower left", ncol=2,
                   bbox_to_anchor=(0, 1.04), borderaxespad=0,
                   fontsize=7.2, frameon=False, handlelength=1.7)
        late = np.flatnonzero((mid >= 17) & (mid < 22))
        late_peak = int(late[np.argmax(s.grid[late])])
        ax2.annotate(
            f"晚间购电峰值 {s.grid[late_peak]:.{DECIMALS}f} kWh",
            (mid[late_peak], s.grid[late_peak]), xytext=(-78, 12), textcoords="offset points",
            fontsize=6.5, color=color["grid"],
            arrowprops=dict(arrowstyle="-", lw=0.6, color=color["grid"]),
        )
        low_charge = np.flatnonzero((data.price <= low) & (s.charge > 1e-6))
        if len(low_charge):
            low_index = int(low_charge[np.argmax(s.charge[low_charge])])
            ax2.annotate(
                "低价购电并充电", (mid[low_index], s.grid[low_index]),
                xytext=(0.31, 0.97), textcoords="axes fraction", fontsize=6.4,
                ha="left", va="top",
                bbox=dict(fc=color["panel"], ec="none", alpha=1.0, pad=2.0),
                color=color["charge"],
            )
        surplus = float(np.maximum(data.pv_energy - data.load_energy, 0).sum())
        save(
            fig, "fig1_daily_energy_profile",
            f"日内能源环境与购电响应。最低电价{data.price.min():.{DECIMALS}f}元/kWh，"
            f"最高电价{data.price.max():.{DECIMALS}f}元/kWh，光伏余量{surplus:.{DECIMALS}f}kWh；"
            "浅蓝和浅橙背景分别表示低价与高价区间。",
        )

        # 图2：上方展示储电量，下方分别展示充电与放电折线。
        soc_blue = "#3F72AF"
        action_colors = {"charge": "#2A9D8F", "discharge": "#E07A5F"}
        fig = plt.figure(figsize=(170 / 25.4, 80 / 25.4))
        layout = fig.add_gridspec(3, 1, height_ratios=[3.6, 0.9, 0.9], hspace=0.20)
        ax2 = fig.add_subplot(layout[0, 0])
        charge_ax = fig.add_subplot(layout[1, 0], sharex=ax2)
        discharge_ax = fig.add_subplot(layout[2, 0], sharex=ax2)
        fig.subplots_adjust(left=0.115, right=0.93, top=0.81, bottom=0.16)
        fig.text(0.5, 0.94, "储能动作与储电量响应", ha="center",
                 fontsize=9.5, fontweight="bold")
        fig.text(0.115, 0.87,
                 f"最大充电 {s.charge.max():.2f} kWh    最大放电 {s.discharge.max():.2f} kWh",
                 fontsize=6.6, color=color["text"])
        ax2.axhspan(params.capacity_min, params.capacity_max,
                    color=soc_blue, alpha=0.06, lw=0)
        ax2.fill_between(edges, params.capacity_min, s.energy,
                         color=soc_blue, alpha=0.12, lw=0)
        ax2.plot(edges, s.energy, color=soc_blue, lw=1.7)
        for bound in (params.capacity_min, params.capacity_max):
            ax2.axhline(bound, color=color["base"], ls="--", lw=0.7)
        ax2.axhline(params.initial_energy, color=color["muted"], ls=":", lw=0.8)
        style_axis(ax2, "储电量 / kWh")
        ax2.set_xlabel("")
        ax2.tick_params(axis="x", labelbottom=False)
        ax2.set_ylim(0, params.capacity_max + 1700)
        ax2.text(0.015, 0.96,
                 f"安全范围 {params.capacity_min:.2f}–{params.capacity_max:.2f} kWh",
                 transform=ax2.transAxes, va="top", fontsize=6.4, color=color["muted"])
        ax2.scatter([0, 24], [s.energy[0], s.energy[-1]], s=15,
                    color=soc_blue, zorder=4, clip_on=False)
        # 状态说明放在底部独立一行，不在曲线上叠加长文字。
        fig.text(0.115, 0.025,
                 f"最低储电量 {s.energy.min():.2f} kWh    "
                 f"0:00 / 24:00 均为 {s.energy[0]:.2f} kWh",
                 fontsize=6.6, color=color["text"])
        limit = max(float(s.charge.max()), float(s.discharge.max()), 1.0)
        for row, ax, values, key, label in (
                (1, charge_ax, s.charge, "charge", "充电"),
                (2, discharge_ax, s.discharge, "discharge", "放电")):
            ax.plot(mid, values, color=action_colors[key], lw=1.25)
            style_axis(ax, f"{label}量 / kWh", xlabel="时间 / h" if row == 2 else " ")
            ax.set_ylim(0, limit * 1.12)
            ax.set_yticks([0, limit])
            if row == 1:
                ax.set_xlabel("")
                ax.tick_params(axis="x", labelbottom=False)
        fig.text(0.93, 0.87, "折线：每10分钟电量 / kWh",
                 ha="right", fontsize=6.2, color=color["muted"])
        save(
            fig, "fig2_optimal_dispatch",
            f"储能动作与电量轨迹。最大充电量{s.charge.max():.{DECIMALS}f}kWh，"
            f"最大放电量{s.discharge.max():.{DECIMALS}f}kWh；储电量保持在"
            f"{params.capacity_min:.{DECIMALS}f}–{params.capacity_max:.{DECIMALS}f}kWh，"
            f"日首尾均为{s.energy[0]:.{DECIMALS}f}kWh。",
        )

        # 图3：保留原有“累计费用＋六时段费用对比”的双图结构。
        fig, (ax1, ax2) = plt.subplots(
            1, 2, figsize=(170 / 25.4, 76 / 25.4),
            gridspec_kw={"width_ratios": [1.25, 1], "wspace": 0.34},
        )
        # 为标题、横轴标题和底部经济性摘要分别预留独立空间，避免文字相互遮挡。
        fig.subplots_adjust(left=0.09, right=0.98, top=0.84, bottom=0.27)
        title(ax1, "累计购电费用")
        base_cumulative = np.r_[0, np.cumsum(data.price * baseline)]
        opt_cumulative = np.r_[0, np.cumsum(data.price * s.grid)]
        ax1.plot(
            edges, base_cumulative, color=color["base"], ls="--", lw=1.25,
            label=f"无储能  {base_cumulative[-1]:,.{DECIMALS}f} 元",
        )
        ax1.plot(
            edges, opt_cumulative, color=color["grid"], lw=1.45,
            label=f"优化后  {opt_cumulative[-1]:,.{DECIMALS}f} 元",
        )
        ax1.fill_between(edges, opt_cumulative, base_cumulative,
                         where=base_cumulative >= opt_cumulative,
                         color=color["charge"], alpha=0.10, lw=0)
        style_axis(ax1, "累计费用 / 元")
        ax1.set_ylim(0, max(base_cumulative.max(), opt_cumulative.max()) * 1.12)
        legend(ax1, 2)
        # 精确费用并入图例，避免端点标注与曲线或相邻子图发生遮挡。

        title(ax2, "各四小时时段购电费用")
        block_base = (data.price * baseline).reshape(BLOCK_COUNT, BLOCK_SIZE).sum(axis=1)
        block_opt = (data.price * s.grid).reshape(BLOCK_COUNT, BLOCK_SIZE).sum(axis=1)
        delta = (block_base - block_opt) / 1000
        x = np.arange(BLOCK_COUNT)
        width = 0.34
        ax2.axvspan(3.52, 4.48, color=color["discharge"], alpha=0.055, lw=0, zorder=0)
        rounded_bars(ax2, x - width / 2, block_base, width, "#D5D9DC", "无储能")
        rounded_bars(ax2, x + width / 2, block_opt, width, color["grid"], "优化后")
        style_axis(ax2, "购电费用 / 元", xlabel="")
        ax2.set_xticks(x, ["0–4", "4–8", "8–12", "12–16", "16–20", "20–24"])
        ax2.set_xlabel("时段 / h", fontsize=8, labelpad=3)
        ax2.set_xlim(-0.55, BLOCK_COUNT - 0.45)
        ax2.set_ylim(0, max(block_base.max(), block_opt.max()) * 1.24)
        legend(ax2, 2)
        for xx, value, top in zip(x, delta, np.maximum(block_base, block_opt)):
            ax2.text(xx, top + max(block_base.max(), block_opt.max()) * 0.035,
                     f"{value:+.{DECIMALS}f}", ha="center", va="bottom", fontsize=5.8,
                     color=color["charge"] if value >= 0 else color["discharge"])
        # 高价提示固定在轴内上缘；柱顶数字只承担数值表达，二者不再堆叠。
        ax2.text(4, 0.975, "高价时段", transform=ax2.get_xaxis_transform(),
                 ha="center", va="top", fontsize=5.8, color=color["discharge"])
        fig.text(
            0.09, 0.055,
            f"全天费用：{s.baseline_cost:,.{DECIMALS}f} → {s.total_cost:,.{DECIMALS}f} 元    "
            f"节省 {saving:,.{DECIMALS}f} 元（{saving_rate:.{DECIMALS}f}%）",
            fontsize=6.6, color=color["text"],
        )
        fig.text(0.80, 0.055, "柱顶数值：分时段节省费用 / 千元",
                 ha="center", fontsize=6.6, color=color["text"])
        save(
            fig, "fig3_economic_benefit",
            f"无储能费用{s.baseline_cost:.{DECIMALS}f}元，优化后{s.total_cost:.{DECIMALS}f}元，"
            f"节省{saving:.{DECIMALS}f}元，下降{saving_rate:.{DECIMALS}f}%。",
        )

    audit = [
        f"首尾储电量：{s.energy[0]:.{DECIMALS}f} / {s.energy[-1]:.{DECIMALS}f} kWh",
        f"储电量范围：{s.energy.min():.{DECIMALS}f}–{s.energy.max():.{DECIMALS}f} kWh",
        f"最大充放电量：{s.charge.max():.{DECIMALS}f} / {s.discharge.max():.{DECIMALS}f} kWh",
        f"同时充放电时段数：{s.simultaneous_periods}",
        f"弃光量：{s.curtailed_energy:.{DECIMALS}f} kWh",
        f"第一阶段 / 最终吞吐量：{s.primary_throughput:.{DECIMALS}f} / "
        f"{s.final_throughput:.{DECIMALS}f} kWh",
        f"第二阶段成功：{s.secondary_used}",
        f"最大供需平衡残差：{s.max_balance_error:.2e} kWh",
        f"最大储能状态残差：{s.max_state_error:.2e} kWh",
    ]
    (output_dir / "figure_captions.txt").write_text(
        "\n".join(captions) + "\n约束审计（供正文表格使用）\n" + "\n".join(audit),
        encoding="utf-8",
    )
    print(f"\n三张横向论文主图已保存至：{output_dir.resolve()}（PNG / SVG / PDF）")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="C题问题一：微网购电与储能两阶段线性规划")
    parser.add_argument(
        "--input",
        type=Path,
        default=BASE_DIR.parent / "附件1.xlsx",
        help="附件1路径，默认：../附件1.xlsx",
    )
    parser.add_argument(
        "--template",
        type=Path,
        default=BASE_DIR.parent / "附件5" / "result1.xlsx",
        help="官方result1模板，默认：../附件5/result1.xlsx",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=BASE_DIR / "result1.xlsx",
        help="输出结果，默认：./result1.xlsx",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="额外打印两阶段优化、无储能基准和残差校验信息",
    )
    parser.add_argument("--plot", action="store_true", help="生成三张横向论文主图（PNG/SVG/PDF）")
    parser.add_argument("--figure-dir", type=Path, default=BASE_DIR / "figures", help="图片输出目录")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    params = ModelParameters()

    data = read_input(args.input)
    solution = solve_problem(data, params)
    write_result(args.template, args.output, solution)

    print_final_tables(data, solution)

    if args.verbose:
        print_verbose_checks(solution)
    if args.plot:
        visualize_results(data, solution, args.figure_dir, params)


if __name__ == "__main__":
    main()
