from __future__ import annotations

"""C题问题二：滚动预测 + 残差场景 + 两阶段随机购电优化。

核心思路
1. 使用附件2中的历史真实负载/光伏数据，在每天 0:00 仅利用此前已经发生的数据，
   分别用 LightGBM 预测当天 144 个 10 分钟时段的负载和光伏功率。
2. 用过去的“样本外预测残差整日轨迹”构造不确定性场景，保留日内误差相关性。
3. 每天 0:00 在 48 小时滚动窗口内优化“当天+次日预览”，但只执行并输出当天
   144 个时段的计划购电量；第二天获得新信息后重新预测和优化。
4. 在主目标最优值附近，再最小化场景平均储能吞吐量，减少无意义充放电循环。
5. 当天实际数据发生后，锁定全天计划购电量 G_t，再用实际负载/光伏求解储能调度和
   紧急购电，完成严格的事后回测；不允许用当天实际数据重新修改计划购电量。

重要建模约定
- 时间采用 A 解释：附件中的 0:10 表示第一个 10 分钟调度单元的结束时刻，
  即模型 t=0 对应 0:00-0:10；0:00+1 对应 23:50-24:00。
- 负载/光伏从 kW 乘 1/6 h 转为每 10 分钟电量 kWh。
- 充电效率和放电效率均取 0.90。
- 6000 kWh 仅作为 2025-01-01 0:00 的题设初值；之后按 E_{d+1,0}=E_{d,24}
  跨日连续传递，不再把每一天的首尾储电量强制恢复为 6000 kWh。
- 48 小时窗口末端设置剩余储能价值，默认取“放电效率×日内电价中位数”，
  用于削弱有限时域末端放空；可用 --terminal-value-scale 做灵敏度分析。
- 问题2的“计划购电量”是第一阶段决策；储能在实际运行中允许根据实际净负荷进行调度。
  这样不会把未知的实际负载/光伏提前泄漏到 0:00 的购电计划中。

默认输出：问题2/result2.xlsx
"""

import argparse
import math
import shutil
import sys
import warnings
import unicodedata

sys.dont_write_bytecode = True
from dataclasses import dataclass
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Iterable

import numpy as np
import openpyxl

warnings.filterwarnings(
    "ignore",
    message="X does not have valid feature names, but LGBMRegressor was fitted with feature names",
)
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from scipy.optimize import linprog
from scipy.sparse import csr_matrix, lil_matrix
from sklearn.metrics import mean_absolute_error, mean_squared_error

_LOCAL_PLOT_DEPS = Path(__file__).resolve().parent.parent / ".python_deps" / "problem2"
if _LOCAL_PLOT_DEPS.is_dir():
    sys.path.insert(0, str(_LOCAL_PLOT_DEPS))

try:
    from lightgbm import LGBMRegressor
except ImportError:
    LGBMRegressor = None

try:
    from tabulate import tabulate
except ImportError:
    tabulate = None


BASE_DIR = Path(__file__).resolve().parent
PERIODS = 144
DT_HOURS = 1.0 / 6.0
BLOCK_SIZE = 24
BLOCK_LABELS = [
    "0:00-4:00",
    "4:00-8:00",
    "8:00-12:00",
    "12:00-16:00",
    "16:00-20:00",
    "20:00-24:00",
]
PAPER_DATES = ["2025-03-20", "2025-06-21", "2025-09-23", "2025-12-21"]
EPS_ZERO = 1e-8
EMERGENCY_THRESHOLD = 1e-6


@dataclass(frozen=True)
class ModelParameters:
    capacity_min: float = 1200.0  # 附录1安全储电量下限
    capacity_max: float = 10800.0  # 附录1安全储电量上限
    initial_energy: float = 6000.0  # 仅2025-01-01 0:00的初始电量
    max_power: float = 5000.0  # 附录1最大充放电功率
    charge_efficiency: float = 0.90  # 附录1充电效率
    discharge_efficiency: float = 0.90  # 附录1放电效率
    emergency_multiplier: float = 5.0  # 紧急购电价为实时电价5倍
    terminal_value_scale: float = 1.0  # 乘在eta_d×电价中位数上的无量纲系数

    @property
    def max_energy_per_period(self) -> float:
        return self.max_power * DT_HOURS


@dataclass(frozen=True)
class ForecastConfig:
    min_history_days: int = 7
    residual_warmup_start_day: int = 14  # Jan 15: first OOF residual day
    scenario_days: int = 30
    retrain_every: int = 1
    n_estimators: int = 180
    learning_rate: float = 0.05
    num_leaves: int = 31
    min_child_samples: int = 20
    random_state: int = 2026


@dataclass(frozen=True)
class YearData:
    dates: list[date]
    time_labels: list[object]
    price: np.ndarray        # shape (144,), 元/kWh
    load_kw: np.ndarray      # shape (365, 144)
    pv_kw: np.ndarray        # shape (365, 144)


@dataclass
class ForecastRecord:
    day_index: int
    date_value: date
    load_pred_kw: np.ndarray
    pv_pred_kw: np.ndarray
    load_error_kw: np.ndarray | None = None
    pv_error_kw: np.ndarray | None = None


@dataclass(frozen=True)
class DayPlan:
    grid: np.ndarray
    primary_expected_cost: float
    expected_emergency_cost: float
    expected_throughput: float
    scenario_count: int
    used_secondary: bool
    preview_grid: np.ndarray | None = None
    expected_terminal_energy: float = math.nan
    terminal_value_per_kwh: float = 0.0


@dataclass(frozen=True)
class ActualDispatch:
    charge: np.ndarray
    discharge: np.ndarray
    emergency: np.ndarray
    waste: np.ndarray
    energy: np.ndarray
    emergency_cost: float
    total_cost: float
    used_secondary: bool
    max_balance_error: float
    max_state_error: float


@dataclass(frozen=True)
class DayResult:
    date_value: date
    load_pred_kw: np.ndarray
    pv_pred_kw: np.ndarray
    plan: DayPlan
    dispatch: ActualDispatch
    # 仅保存决策前可用的残差场景；绘图和策略对比不得用当天残差反推区间。
    scenario_net_kw: np.ndarray | None = None
    scenario_source_dates: tuple[str, ...] = ()
    next_load_pred_kw: np.ndarray | None = None
    next_pv_pred_kw: np.ndarray | None = None

    @property
    def planned_purchase_cost(self) -> float:
        return self.dispatch.total_cost - self.dispatch.emergency_cost



def format_clock_from_minutes(minutes: int, use_next_day_label: bool = True) -> str:
    if minutes == 1440:
        return "0:00+1" if use_next_day_label else "24:00"
    minutes %= 1440
    h, m = divmod(minutes, 60)
    return f"{h}:{m:02d}"


def physical_interval_label(slot: int, use_next_day_label: bool = True) -> str:
    """A解释：slot=0 -> 0:00-0:10, slot=143 -> 23:50-0:00+1。"""
    start = slot * 10
    end = (slot + 1) * 10
    return (
        f"{format_clock_from_minutes(start, use_next_day_label)}-"
        f"{format_clock_from_minutes(end, use_next_day_label)}"
    )


def physical_interval_labels() -> list[str]:
    return [physical_interval_label(t) for t in range(PERIODS)]


def parse_date_like(value: object) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    raise ValueError(f"无法识别日期：{value!r}")


def read_daily_price(path: Path) -> tuple[list[object], np.ndarray]:
    if not path.exists():
        raise FileNotFoundError(f"找不到附件1：{path}")

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    wb.close()

    if len(rows) != PERIODS:
        raise ValueError(f"附件1应有 {PERIODS} 个时段，实际 {len(rows)} 个。")

    labels = [row[0] for row in rows]
    price = np.asarray([row[1] for row in rows], dtype=float)
    if not np.all(np.isfinite(price)) or np.any(price < 0):
        raise ValueError("附件1电价存在空值、非数值或负数。")
    return labels, price


def read_actual_year(path: Path) -> tuple[list[date], list[object], np.ndarray, np.ndarray]:
    if not path.exists():
        raise FileNotFoundError(f"找不到附件2：{path}")

    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    required = ["小区负载", "光伏发电实际功率"]
    for name in required:
        if name not in wb.sheetnames:
            wb.close()
            raise ValueError(f"附件2缺少工作表：{name}")

    ws_load = wb["小区负载"]
    ws_pv = wb["光伏发电实际功率"]

    load_all = list(ws_load.iter_rows(values_only=True))
    pv_all = list(ws_pv.iter_rows(values_only=True))
    wb.close()

    if not load_all or not pv_all:
        raise ValueError("附件2工作表为空。")
    if len(load_all[0]) != PERIODS + 1 or len(pv_all[0]) != PERIODS + 1:
        raise ValueError("附件2每张表应为1列日期 + 144列10分钟数据。")

    time_labels_load = list(load_all[0][1:])
    time_labels_pv = list(pv_all[0][1:])
    if [str(x) for x in time_labels_load] != [str(x) for x in time_labels_pv]:
        raise ValueError("附件2负载与光伏工作表的时间列不一致。")

    dates_load = [parse_date_like(row[0]) for row in load_all[1:]]
    dates_pv = [parse_date_like(row[0]) for row in pv_all[1:]]
    load_rows = [list(row[1:]) for row in load_all[1:]]
    pv_rows = [list(row[1:]) for row in pv_all[1:]]

    if dates_load != dates_pv:
        raise ValueError("附件2负载与光伏工作表日期不一致。")

    load_kw = np.asarray(load_rows, dtype=float)
    pv_kw = np.asarray(pv_rows, dtype=float)

    if load_kw.shape[1] != PERIODS or pv_kw.shape[1] != PERIODS:
        raise ValueError("附件2数据列数不是144。")
    if not (np.all(np.isfinite(load_kw)) and np.all(np.isfinite(pv_kw))):
        raise ValueError("附件2存在空值或非数值。")
    if np.any(load_kw < 0) or np.any(pv_kw < 0):
        raise ValueError("附件2负载或光伏存在负数。")

    return dates_load, time_labels_load, load_kw, pv_kw


def load_year_data(price_path: Path, actual_path: Path) -> YearData:
    price_labels, price = read_daily_price(price_path)
    dates, actual_labels, load_kw, pv_kw = read_actual_year(actual_path)

    if len(price_labels) != len(actual_labels):
        raise ValueError("附件1与附件2的日内时段数量不一致。")

    if len(dates) < 365:
        warnings.warn(f"附件2只有 {len(dates)} 天，代码仍会按实际天数运行。")

    return YearData(
        dates=dates,
        time_labels=actual_labels,
        price=price,
        load_kw=load_kw,
        pv_kw=pv_kw,
    )


def build_feature_tensor(series_kw: np.ndarray, dates: list[date]) -> np.ndarray:
    """为每一天、每个10分钟时段构造仅依赖历史数据的特征。

    输出 shape = (days, 144, features)。前7天因没有 lag7，保留 NaN，训练时跳过。
    """
    n_days, n_periods = series_kw.shape
    if n_periods != PERIODS:
        raise ValueError("series_kw第二维必须是144。")

    n_features = 13
    X = np.full((n_days, PERIODS, n_features), np.nan, dtype=float)

    slot = np.arange(PERIODS, dtype=float)
    # A解释下用10分钟区间中点作为时刻连续特征：0:05, 0:15, ..., 23:55
    midpoint_hour = (slot * 10.0 + 5.0) / 60.0
    tod_angle = 2.0 * np.pi * midpoint_hour / 24.0

    for d in range(7, n_days):
        dt = dates[d]
        doy = dt.timetuple().tm_yday
        doy_angle = 2.0 * np.pi * doy / 365.0
        dow = dt.weekday()

        hist3 = series_kw[d - 3 : d]
        hist7 = series_kw[d - 7 : d]

        X[d, :, 0] = slot
        X[d, :, 1] = np.sin(tod_angle)
        X[d, :, 2] = np.cos(tod_angle)
        X[d, :, 3] = float(dow)
        X[d, :, 4] = 1.0 if dow >= 5 else 0.0
        X[d, :, 5] = math.sin(doy_angle)
        X[d, :, 6] = math.cos(doy_angle)
        X[d, :, 7] = series_kw[d - 1]               # lag 1 day
        X[d, :, 8] = series_kw[d - 7]               # lag 7 days
        X[d, :, 9] = np.mean(hist3, axis=0)          # rolling mean 3d
        X[d, :, 10] = np.mean(hist7, axis=0)         # rolling mean 7d
        X[d, :, 11] = np.std(hist7, axis=0)          # rolling std 7d
        X[d, :, 12] = float(dt.month)

    return X


class RollingForecaster:
    def __init__(
        self,
        load_kw: np.ndarray,
        pv_kw: np.ndarray,
        dates: list[date],
        cfg: ForecastConfig,
    ) -> None:
        self.load_kw = load_kw
        self.pv_kw = pv_kw
        self.dates = dates
        self.cfg = cfg
        self.load_X = build_feature_tensor(load_kw, dates)
        self.pv_X = build_feature_tensor(pv_kw, dates)
        self.load_model: LGBMRegressor | None = None
        self.pv_model: LGBMRegressor | None = None
        self.last_train_day: int | None = None

    def _new_model(self) -> LGBMRegressor:
        if LGBMRegressor is None:
            raise ImportError("未安装 lightgbm。请在当前Python环境中执行 python -m pip install lightgbm。")
        return LGBMRegressor(
            objective="regression_l1",
            n_estimators=self.cfg.n_estimators,
            learning_rate=self.cfg.learning_rate,
            num_leaves=self.cfg.num_leaves,
            min_child_samples=self.cfg.min_child_samples,
            subsample=0.90,
            colsample_bytree=0.90,
            reg_lambda=0.10,
            random_state=self.cfg.random_state,
            n_jobs=-1,
            verbosity=-1,
        )

    def _fit(self, target_day: int) -> None:
        start_day = 7
        if target_day - start_day < self.cfg.min_history_days:
            raise ValueError(
                f"预测 {self.dates[target_day]} 时历史训练天数不足；"
                f"需要至少 {self.cfg.min_history_days} 天。"
            )

        train_days = np.arange(start_day, target_day)
        X_load = self.load_X[train_days].reshape(-1, self.load_X.shape[-1])
        y_load = self.load_kw[train_days].reshape(-1)
        X_pv = self.pv_X[train_days].reshape(-1, self.pv_X.shape[-1])
        y_pv = self.pv_kw[train_days].reshape(-1)

        self.load_model = self._new_model()
        self.pv_model = self._new_model()
        self.load_model.fit(X_load, y_load)
        self.pv_model.fit(X_pv, y_pv)
        self.last_train_day = target_day

    def predict(self, target_day: int) -> tuple[np.ndarray, np.ndarray]:
        if target_day < 14:
            raise ValueError("滚动LightGBM预测默认从1月15日以后使用。")

        need_retrain = (
            self.load_model is None
            or self.pv_model is None
            or self.last_train_day is None
            or target_day - self.last_train_day >= self.cfg.retrain_every
        )
        if need_retrain:
            self._fit(target_day)

        assert self.load_model is not None and self.pv_model is not None
        pred_load = self.load_model.predict(self.load_X[target_day], validate_features=False)
        pred_pv = self.pv_model.predict(self.pv_X[target_day], validate_features=False)
        pred_load = np.clip(np.asarray(pred_load, dtype=float), 0.0, None)
        pred_pv = np.clip(np.asarray(pred_pv, dtype=float), 0.0, None)
        return pred_load, pred_pv

    @staticmethod
    def _recursive_next_features(
        series_kw: np.ndarray,
        dates: list[date],
        target_day: int,
        current_prediction: np.ndarray,
    ) -> np.ndarray:
        """构造次日递归特征，所有输入均在当天0:00可得。

        次日 lag1 用当天预测替代；3日和7日滚动量由已发生历史与当天预测组成，
        因而不会把当天真实值提前泄漏给次日预览。
        """
        if target_day < 7:
            raise ValueError("递归次日预测至少需要7天历史数据。")
        next_date = dates[target_day] + timedelta(days=1)
        slot = np.arange(PERIODS, dtype=float)
        midpoint_hour = (slot * 10.0 + 5.0) / 60.0
        tod_angle = 2.0 * np.pi * midpoint_hour / 24.0
        doy_angle = 2.0 * np.pi * next_date.timetuple().tm_yday / 365.0
        dow = next_date.weekday()

        hist3 = np.vstack((series_kw[target_day - 2 : target_day], current_prediction))
        hist7 = np.vstack((series_kw[target_day - 6 : target_day], current_prediction))
        X = np.empty((PERIODS, 13), dtype=float)
        X[:, 0] = slot
        X[:, 1] = np.sin(tod_angle)
        X[:, 2] = np.cos(tod_angle)
        X[:, 3] = float(dow)
        X[:, 4] = 1.0 if dow >= 5 else 0.0
        X[:, 5] = math.sin(doy_angle)
        X[:, 6] = math.cos(doy_angle)
        X[:, 7] = current_prediction
        X[:, 8] = series_kw[target_day - 6]
        X[:, 9] = np.mean(hist3, axis=0)
        X[:, 10] = np.mean(hist7, axis=0)
        X[:, 11] = np.std(hist7, axis=0)
        X[:, 12] = float(next_date.month)
        return X

    def predict_two_day(self, target_day: int) -> tuple[np.ndarray, np.ndarray]:
        """返回 shape=(2,144) 的当天与次日递归预测，训练截止日均为 target_day-1。"""
        load_today, pv_today = self.predict(target_day)
        assert self.load_model is not None and self.pv_model is not None
        load_X_next = self._recursive_next_features(
            self.load_kw, self.dates, target_day, load_today)
        pv_X_next = self._recursive_next_features(
            self.pv_kw, self.dates, target_day, pv_today)
        load_next = np.clip(
            np.asarray(self.load_model.predict(load_X_next, validate_features=False), dtype=float),
            0.0,
            None,
        )
        pv_next = np.clip(
            np.asarray(self.pv_model.predict(pv_X_next, validate_features=False), dtype=float),
            0.0,
            None,
        )
        return np.vstack((load_today, load_next)), np.vstack((pv_today, pv_next))


# 残差场景生成
def generate_scenarios(
    load_pred_kw: np.ndarray,
    pv_pred_kw: np.ndarray,
    residual_history: list[ForecastRecord],
    scenario_days: int,
) -> tuple[np.ndarray, np.ndarray]:
    valid = [
        r for r in residual_history
        if r.load_error_kw is not None and r.pv_error_kw is not None
    ]
    if not valid:
        raise RuntimeError("没有可用的历史样本外预测残差，无法构造场景。")

    selected = valid[-scenario_days:]
    S = len(selected)
    load_s = np.empty((S, PERIODS), dtype=float)
    pv_s = np.empty((S, PERIODS), dtype=float)

    for s, rec in enumerate(selected):
        assert rec.load_error_kw is not None and rec.pv_error_kw is not None
        load_s[s] = np.clip(load_pred_kw + rec.load_error_kw, 0.0, None)
        pv_s[s] = np.clip(pv_pred_kw + rec.pv_error_kw, 0.0, None)

    return load_s, pv_s


def generate_two_day_scenarios(
    load_pred_kw: np.ndarray,
    pv_pred_kw: np.ndarray,
    residual_history: list[ForecastRecord],
    scenario_days: int,
) -> tuple[np.ndarray, np.ndarray, tuple[str, ...]]:
    """以相邻历史残差对构造48小时场景，保留日内及跨日误差相关性。"""
    if load_pred_kw.shape != (2, PERIODS) or pv_pred_kw.shape != (2, PERIODS):
        raise ValueError("两日预测矩阵必须为(2,144)。")
    valid = [
        r for r in residual_history
        if r.load_error_kw is not None and r.pv_error_kw is not None
    ]
    pairs = [
        (a, b) for a, b in zip(valid[:-1], valid[1:])
        if (b.date_value - a.date_value).days == 1
    ]
    if pairs:
        selected = pairs[-scenario_days:]
    elif valid:
        # 预热最初一天尚无相邻残差对，用同一已知残差复制到两天；随后自动切换为配对场景。
        selected = [(valid[-1], valid[-1])]
    else:
        # 首个预热日没有残差，只使用点预测；不使用任何未来真实信息。
        return (
            load_pred_kw.reshape(1, 2 * PERIODS).copy(),
            pv_pred_kw.reshape(1, 2 * PERIODS).copy(),
            (),
        )

    load_s = np.empty((len(selected), 2 * PERIODS), dtype=float)
    pv_s = np.empty_like(load_s)
    source_dates: list[str] = []
    for s, (first, second) in enumerate(selected):
        assert first.load_error_kw is not None and first.pv_error_kw is not None
        assert second.load_error_kw is not None and second.pv_error_kw is not None
        load_s[s] = np.concatenate((
            np.clip(load_pred_kw[0] + first.load_error_kw, 0.0, None),
            np.clip(load_pred_kw[1] + second.load_error_kw, 0.0, None),
        ))
        pv_s[s] = np.concatenate((
            np.clip(pv_pred_kw[0] + first.pv_error_kw, 0.0, None),
            np.clip(pv_pred_kw[1] + second.pv_error_kw, 0.0, None),
        ))
        source_dates.append(f"{first.date_value.isoformat()}+{second.date_value.isoformat()}")
    return load_s, pv_s, tuple(source_dates)


def terminal_energy_value(price: np.ndarray, params: ModelParameters) -> float:
    """窗口末端每1 kWh库存的价值：eta_d×典型可替代购电价。"""
    daily_price = np.asarray(price, dtype=float).reshape(-1)[:PERIODS]
    return float(
        params.terminal_value_scale
        * params.discharge_efficiency
        * np.median(daily_price)
    )


# 两阶段随机线性规划
def solve_stochastic_plan(
    price: np.ndarray,
    scenario_load_kw: np.ndarray,
    scenario_pv_kw: np.ndarray,
    params: ModelParameters,
    initial_energy: float,
    daily_cycle: bool,
    terminal_value_per_kwh: float | None = None,
) -> DayPlan:
    """滚动窗口随机LP；返回并执行前24小时计划，后续时段仅作预览。"""
    S, T = scenario_load_kw.shape
    if T < PERIODS or T % PERIODS != 0 or scenario_pv_kw.shape != (S, T):
        raise ValueError("场景矩阵维度错误。")
    price = np.asarray(price, dtype=float).reshape(-1)
    if price.size == PERIODS and T > PERIODS:
        price = np.tile(price, T // PERIODS)
    if price.size != T:
        raise ValueError("电价向量长度必须与滚动窗口时段数一致。")
    if terminal_value_per_kwh is None:
        terminal_value_per_kwh = 0.0 if daily_cycle else terminal_energy_value(price, params)

    scenario_net = (scenario_load_kw - scenario_pv_kw) * DT_HOURS
    prob = np.full(S, 1.0 / S)

    # x = [G] + for each scenario [C, D, H, W, E]
    G_START = 0
    SCENARIO_SIZE = 5 * T + 1
    n_vars = T + S * SCENARIO_SIZE

    def offsets(s: int) -> tuple[int, int, int, int, int]:
        base = T + s * SCENARIO_SIZE
        c = base
        d = c + T
        h = d + T
        w = h + T
        e = w + T
        return c, d, h, w, e

    a_eq = lil_matrix((S * 2 * T, n_vars), dtype=float)
    b_eq = np.zeros(S * 2 * T, dtype=float)

    for s in range(S):
        c0, d0, h0, w0, e0 = offsets(s)
        for t in range(T):
            # G + D + H - C - W = NetLoad
            r_bal = s * 2 * T + t
            a_eq[r_bal, G_START + t] = 1.0
            a_eq[r_bal, c0 + t] = -1.0
            a_eq[r_bal, d0 + t] = 1.0
            a_eq[r_bal, h0 + t] = 1.0
            a_eq[r_bal, w0 + t] = -1.0
            b_eq[r_bal] = scenario_net[s, t]

            # E_{t+1} - E_t - eta_c*C + D/eta_d = 0
            r_state = s * 2 * T + T + t
            a_eq[r_state, e0 + t] = -1.0
            a_eq[r_state, e0 + t + 1] = 1.0
            a_eq[r_state, c0 + t] = -params.charge_efficiency
            a_eq[r_state, d0 + t] = 1.0 / params.discharge_efficiency

    bounds: list[tuple[float | None, float | None]] = []
    bounds.extend([(0.0, None)] * T)  # planned grid purchase G

    for s in range(S):
        # C, D
        bounds.extend([(0.0, params.max_energy_per_period)] * T)
        bounds.extend([(0.0, params.max_energy_per_period)] * T)
        # H emergency, W excess/curtailment
        bounds.extend([(0.0, None)] * T)
        bounds.extend([(0.0, None)] * T)
        # E0 ... ET
        bounds.append((initial_energy, initial_energy))
        bounds.extend([(params.capacity_min, params.capacity_max)] * (T - 1))
        if daily_cycle:
            bounds.append((initial_energy, initial_energy))
        else:
            bounds.append((params.capacity_min, params.capacity_max))

    cost = np.zeros(n_vars, dtype=float)
    cost[G_START : G_START + T] = price
    for s in range(S):
        _, _, h0, _, e0 = offsets(s)
        cost[h0 : h0 + T] = prob[s] * params.emergency_multiplier * price
        if not daily_cycle:
            # [理论推导] -lambda_E E_T 表示滚动窗口之外的剩余储能经济价值。
            cost[e0 + T] = -prob[s] * terminal_value_per_kwh

    primary = linprog(
        cost,
        A_eq=a_eq.tocsr(),
        b_eq=b_eq,
        bounds=bounds,
        method="highs",
    )
    if not primary.success:
        raise RuntimeError(f"随机购电主优化失败：{primary.message}")

    # 层次第二目标：在最优总成本附近，最小化场景平均总充放电量。
    throughput = np.zeros(n_vars, dtype=float)
    for s in range(S):
        c0, d0, _, _, _ = offsets(s)
        throughput[c0 : c0 + T] = prob[s]
        throughput[d0 : d0 + T] = prob[s]

    tolerance = max(1e-6, abs(primary.fun) * 1e-9)
    a_ub = csr_matrix(cost.reshape(1, -1))
    secondary = linprog(
        throughput,
        A_ub=a_ub,
        b_ub=np.asarray([primary.fun + tolerance]),
        A_eq=a_eq.tocsr(),
        b_eq=b_eq,
        bounds=bounds,
        method="highs",
    )

    result = secondary if secondary.success else primary
    x = np.where(np.abs(result.x) < EPS_ZERO, 0.0, result.x)
    full_grid = x[:T].copy()
    grid = full_grid[:PERIODS].copy()

    expected_emergency_cost = 0.0
    expected_throughput = 0.0
    expected_terminal_energy = 0.0
    for s in range(S):
        c0, d0, h0, _, e0 = offsets(s)
        H = x[h0 : h0 + T]
        C = x[c0 : c0 + T]
        D = x[d0 : d0 + T]
        expected_emergency_cost += prob[s] * float(
            params.emergency_multiplier * price @ H
        )
        expected_throughput += prob[s] * float(np.sum(C + D))
        expected_terminal_energy += prob[s] * float(x[e0 + T])

    return DayPlan(
        grid=grid,
        primary_expected_cost=float(primary.fun),
        expected_emergency_cost=expected_emergency_cost,
        expected_throughput=expected_throughput,
        scenario_count=S,
        used_secondary=secondary.success,
        preview_grid=full_grid[PERIODS:].copy() if T > PERIODS else None,
        expected_terminal_energy=expected_terminal_energy,
        terminal_value_per_kwh=float(terminal_value_per_kwh),
    )


# 实际日内回测：计划购电锁定，储能按真实净负荷补救
def solve_actual_dispatch(
    price: np.ndarray,
    grid_plan: np.ndarray,
    actual_load_kw: np.ndarray,
    actual_pv_kw: np.ndarray,
    params: ModelParameters,
    initial_energy: float,
    daily_cycle: bool,
    *,
    preview_grid: np.ndarray | None = None,
    preview_load_kw: np.ndarray | None = None,
    preview_pv_kw: np.ndarray | None = None,
    terminal_value_per_kwh: float | None = None,
) -> ActualDispatch:
    """固定当日合同后做滚动调度；可用次日预测预览，但只返回前24小时动作。"""
    price = np.asarray(price, dtype=float).reshape(-1)
    grid_plan = np.asarray(grid_plan, dtype=float).reshape(-1)
    actual_load_kw = np.asarray(actual_load_kw, dtype=float).reshape(-1)
    actual_pv_kw = np.asarray(actual_pv_kw, dtype=float).reshape(-1)
    if any(x.size != PERIODS for x in (price, grid_plan, actual_load_kw, actual_pv_kw)):
        raise ValueError("实际日内调度的当日电价、合同、负荷和光伏均须含144个时段。")

    has_preview = preview_grid is not None
    if has_preview != (preview_load_kw is not None) or has_preview != (preview_pv_kw is not None):
        raise ValueError("次日预览的购电、负荷和光伏必须同时提供。")
    if has_preview:
        assert preview_grid is not None and preview_load_kw is not None and preview_pv_kw is not None
        preview_grid = np.asarray(preview_grid, dtype=float).reshape(-1)
        preview_load_kw = np.asarray(preview_load_kw, dtype=float).reshape(-1)
        preview_pv_kw = np.asarray(preview_pv_kw, dtype=float).reshape(-1)
        if any(x.size != PERIODS for x in (preview_grid, preview_load_kw, preview_pv_kw)):
            raise ValueError("次日预览向量均须含144个时段。")
        grid_full = np.concatenate((grid_plan, preview_grid))
        load_full = np.concatenate((actual_load_kw, preview_load_kw))
        pv_full = np.concatenate((actual_pv_kw, preview_pv_kw))
        price_full = np.tile(price, 2)
    else:
        grid_full = grid_plan
        load_full = actual_load_kw
        pv_full = actual_pv_kw
        price_full = price

    T = grid_full.size
    net = (load_full - pv_full) * DT_HOURS
    if terminal_value_per_kwh is None:
        terminal_value_per_kwh = 0.0 if daily_cycle else terminal_energy_value(price, params)

    # x = [C, D, H, W, E]
    c0 = 0
    d0 = T
    h0 = 2 * T
    w0 = 3 * T
    e0 = 4 * T
    n_vars = 5 * T + 1

    a_eq = lil_matrix((2 * T, n_vars), dtype=float)
    b_eq = np.zeros(2 * T, dtype=float)

    for t in range(T):
        # D + H - C - W = net - fixed G
        a_eq[t, c0 + t] = -1.0
        a_eq[t, d0 + t] = 1.0
        a_eq[t, h0 + t] = 1.0
        a_eq[t, w0 + t] = -1.0
        b_eq[t] = net[t] - grid_full[t]

        r = T + t
        a_eq[r, e0 + t] = -1.0
        a_eq[r, e0 + t + 1] = 1.0
        a_eq[r, c0 + t] = -params.charge_efficiency
        a_eq[r, d0 + t] = 1.0 / params.discharge_efficiency

    bounds: list[tuple[float | None, float | None]] = []
    bounds.extend([(0.0, params.max_energy_per_period)] * T)
    bounds.extend([(0.0, params.max_energy_per_period)] * T)
    bounds.extend([(0.0, None)] * T)  # emergency
    bounds.extend([(0.0, None)] * T)  # waste
    bounds.append((initial_energy, initial_energy))
    bounds.extend([(params.capacity_min, params.capacity_max)] * (T - 1))
    if daily_cycle:
        bounds.append((initial_energy, initial_energy))
    else:
        bounds.append((params.capacity_min, params.capacity_max))

    # 第一目标：实际紧急购电费用最小。
    emergency_obj = np.zeros(n_vars, dtype=float)
    emergency_obj[h0 : h0 + T] = params.emergency_multiplier * price_full
    if not daily_cycle:
        emergency_obj[e0 + T] = -terminal_value_per_kwh
    primary = linprog(
        emergency_obj,
        A_eq=a_eq.tocsr(),
        b_eq=b_eq,
        bounds=bounds,
        method="highs",
    )
    if not primary.success:
        raise RuntimeError(f"实际日内调度失败：{primary.message}")

    # 第二目标：在紧急费用最优附近减少储能吞吐量；同时轻微减少弃电，避免无意义退化解。
    secondary_obj = np.zeros(n_vars, dtype=float)
    secondary_obj[c0 : c0 + T] = 1.0
    secondary_obj[d0 : d0 + T] = 1.0
    secondary_obj[w0 : w0 + T] = 1e-6

    tolerance = max(1e-6, abs(primary.fun) * 1e-9)
    secondary = linprog(
        secondary_obj,
        A_ub=csr_matrix(emergency_obj.reshape(1, -1)),
        b_ub=np.asarray([primary.fun + tolerance]),
        A_eq=a_eq.tocsr(),
        b_eq=b_eq,
        bounds=bounds,
        method="highs",
    )

    result = secondary if secondary.success else primary
    x = np.where(np.abs(result.x) < EPS_ZERO, 0.0, result.x)

    C_full = x[c0 : c0 + T]
    D_full = x[d0 : d0 + T]
    H_full = x[h0 : h0 + T]
    W_full = x[w0 : w0 + T]
    E_full = x[e0 : e0 + T + 1]
    C = C_full[:PERIODS]
    D = D_full[:PERIODS]
    H = H_full[:PERIODS]
    W = W_full[:PERIODS]
    E = E_full[: PERIODS + 1]

    balance_residual = grid_plan + D + H - C - W - net[:PERIODS]
    state_residual = (
        E[1:] - E[:-1]
        - params.charge_efficiency * C
        + D / params.discharge_efficiency
    )
    max_balance_error = float(np.max(np.abs(balance_residual)))
    max_state_error = float(np.max(np.abs(state_residual)))
    if max(max_balance_error, max_state_error) > 1e-5:
        raise RuntimeError("实际调度未通过供需平衡或储能状态残差检查。")

    emergency_cost = float(params.emergency_multiplier * price @ H)
    planned_cost = float(price @ grid_plan)

    return ActualDispatch(
        charge=C,
        discharge=D,
        emergency=H,
        waste=W,
        energy=E,
        emergency_cost=emergency_cost,
        total_cost=planned_cost + emergency_cost,
        used_secondary=secondary.success,
        max_balance_error=max_balance_error,
        max_state_error=max_state_error,
    )


# 紧急购电连续时段合并
def merge_emergency_intervals(emergency: np.ndarray) -> list[tuple[str, float]]:
    intervals: list[tuple[str, float]] = []
    t = 0
    while t < PERIODS:
        if emergency[t] <= EMERGENCY_THRESHOLD:
            t += 1
            continue

        start = t
        total = 0.0
        while t < PERIODS and emergency[t] > EMERGENCY_THRESHOLD:
            total += float(emergency[t])
            t += 1
        end_exclusive = t

        start_min = start * 10
        end_min = end_exclusive * 10
        label = (
            f"{format_clock_from_minutes(start_min, use_next_day_label=False)}-"
            f"{format_clock_from_minutes(end_min, use_next_day_label=False)}"
        )
        intervals.append((label, total))

    return intervals


def _style_numeric_cell(cell, value: float) -> None:
    cell.value = float(value)
    cell.number_format = "0.0000"
    cell.alignment = Alignment(horizontal="center", vertical="center")


def create_fallback_result2(output_path: Path, results: list[DayResult]) -> None:
    wb = Workbook()
    ws_plan = wb.active
    ws_plan.title = "计划购电量"
    ws_storage = wb.create_sheet("充放电量")
    ws_em = wb.create_sheet("紧急购电量")

    # 计划购电量：日期 + 144个物理区间
    ws_plan.cell(1, 1, "日期")
    labels = physical_interval_labels()
    for c, label in enumerate(labels, start=2):
        ws_plan.cell(1, c, label)
    for r, result in enumerate(results, start=2):
        ws_plan.cell(r, 1, result.date_value.strftime("%Y/%m/%d"))
        for c, value in enumerate(result.plan.grid, start=2):
            _style_numeric_cell(ws_plan.cell(r, c), value)

    # 充放电量：每个4h块充/放电 + 首尾SOC
    headers = ["日期"]
    for label in BLOCK_LABELS:
        headers.extend([f"{label}充电量(kWh)", f"{label}放电量(kWh)"])
    headers.extend(["0:00储电量(kWh)", "24:00储电量(kWh)"])
    for c, h in enumerate(headers, start=1):
        ws_storage.cell(1, c, h)

    for r, result in enumerate(results, start=2):
        ws_storage.cell(r, 1, result.date_value.strftime("%Y/%m/%d"))
        charge_blocks = result.dispatch.charge.reshape(6, BLOCK_SIZE).sum(axis=1)
        discharge_blocks = result.dispatch.discharge.reshape(6, BLOCK_SIZE).sum(axis=1)
        c = 2
        for cb, db in zip(charge_blocks, discharge_blocks):
            _style_numeric_cell(ws_storage.cell(r, c), cb)
            _style_numeric_cell(ws_storage.cell(r, c + 1), db)
            c += 2
        _style_numeric_cell(ws_storage.cell(r, c), result.dispatch.energy[0])
        _style_numeric_cell(ws_storage.cell(r, c + 1), result.dispatch.energy[-1])

    # 紧急购电量：按表4长表格式
    ws_em.append(["日期", "紧急购电时间段", "紧急购电量(kWh)"])
    for result in results:
        merged = merge_emergency_intervals(result.dispatch.emergency)
        if not merged:
            # 没有紧急购电时仍保留日期，方便核对全年覆盖情况。
            ws_em.append([result.date_value.strftime("%Y/%m/%d"), "无", 0.0])
            _style_numeric_cell(ws_em.cell(ws_em.max_row, 3), 0.0)
        else:
            first = True
            for label, amount in merged:
                ws_em.append([
                    result.date_value.strftime("%Y/%m/%d") if first else "",
                    label,
                    amount,
                ])
                _style_numeric_cell(ws_em.cell(ws_em.max_row, 3), amount)
                first = False

    for ws in (ws_plan, ws_storage, ws_em):
        ws.freeze_panes = "B2" if ws is not ws_em else "A2"
        ws.sheet_view.showGridLines = False
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.column_dimensions["A"].width = 14

    ws_em.column_dimensions["B"].width = 22
    ws_em.column_dimensions["C"].width = 20
    for col in range(2, ws_plan.max_column + 1):
        ws_plan.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 14
    for col in range(2, ws_storage.max_column + 1):
        ws_storage.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 20

    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)
    wb.close()


def try_fill_official_template(
    template_path: Path,
    output_path: Path,
    results: list[DayResult],
) -> bool:
    if not template_path.exists():
        return False

    shutil.copy2(template_path, output_path)
    wb = openpyxl.load_workbook(output_path)
    required = ["计划购电量", "充放电量", "紧急购电量"]
    if any(name not in wb.sheetnames for name in required):
        wb.close()
        output_path.unlink(missing_ok=True)
        return False

    ws_plan = wb["计划购电量"]
    ws_storage = wb["充放电量"]
    ws_em = wb["紧急购电量"]

    if ws_plan.max_column < PERIODS + 1 or ws_storage.max_column < 15:
        wb.close()
        output_path.unlink(missing_ok=True)
        return False

    start_row = 2
    for i, result in enumerate(results):
        r = start_row + i
        ws_plan.cell(r, 1, result.date_value)
        ws_plan.cell(r, 1).number_format = "yyyy/m/d"
        for c, value in enumerate(result.plan.grid, start=2):
            _style_numeric_cell(ws_plan.cell(r, c), value)

        ws_storage.cell(r, 1, result.date_value)
        ws_storage.cell(r, 1).number_format = "yyyy/m/d"
        charge_blocks = result.dispatch.charge.reshape(6, BLOCK_SIZE).sum(axis=1)
        discharge_blocks = result.dispatch.discharge.reshape(6, BLOCK_SIZE).sum(axis=1)
        c = 2
        for cb, db in zip(charge_blocks, discharge_blocks):
            _style_numeric_cell(ws_storage.cell(r, c), cb)
            _style_numeric_cell(ws_storage.cell(r, c + 1), db)
            c += 2
        _style_numeric_cell(ws_storage.cell(r, c), result.dispatch.energy[0])
        _style_numeric_cell(ws_storage.cell(r, c + 1), result.dispatch.energy[-1])

    if ws_em.max_row > 1:
        ws_em.delete_rows(2, ws_em.max_row - 1)
    for result in results:
        merged = merge_emergency_intervals(result.dispatch.emergency)
        if not merged:
            ws_em.append([result.date_value, "无", 0.0])
            ws_em.cell(ws_em.max_row, 1).number_format = "yyyy/m/d"
            _style_numeric_cell(ws_em.cell(ws_em.max_row, 3), 0.0)
        else:
            first = True
            for label, amount in merged:
                ws_em.append([result.date_value if first else None, label, amount])
                if first:
                    ws_em.cell(ws_em.max_row, 1).number_format = "yyyy/m/d"
                _style_numeric_cell(ws_em.cell(ws_em.max_row, 3), amount)
                first = False

    wb.save(output_path)
    wb.close()
    return True


def write_result2(
    template_path: Path | None,
    output_path: Path,
    results: list[DayResult],
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if template_path is not None and template_path.exists():
        if try_fill_official_template(template_path, output_path, results):
            return
        warnings.warn(
            "检测到 result2.xlsx 模板，但当前代码无法安全识别其布局；"
            "将生成结构化备用结果文件。若要100%匹配官方模板，请把模板发给我后再精确适配。"
        )

    create_fallback_result2(output_path, results)


def validate_cross_day_results(results: list[DayResult], params: ModelParameters) -> None:
    """写文件前验证SOC安全边界、日期连续性和跨日状态衔接。"""
    if not results:
        raise ValueError("没有可写入的日结果。")
    for i, result in enumerate(results):
        energy = np.asarray(result.dispatch.energy, dtype=float)
        if energy.size != PERIODS + 1 or not np.all(np.isfinite(energy)):
            raise RuntimeError(f"{result.date_value} 的SOC轨迹维度或数值异常。")
        if energy.min() < params.capacity_min - 1e-5 or energy.max() > params.capacity_max + 1e-5:
            raise RuntimeError(f"{result.date_value} 的SOC越过安全边界。")
        if i == 0:
            continue
        previous = results[i - 1]
        if (result.date_value - previous.date_value).days != 1:
            raise RuntimeError("输出日期不连续，无法验证跨日SOC传递。")
        if abs(previous.dispatch.energy[-1] - energy[0]) > 1e-5:
            raise RuntimeError(
                f"{previous.date_value} 24:00与{result.date_value} 0:00的SOC不连续。")


def requested_interval_indices() -> list[tuple[str, int]]:
    labels = [
        "10:00-10:10",
        "12:00-12:10",
        "14:00-14:10",
        "16:00-16:10",
        "18:00-18:10",
        "20:00-20:10",
    ]
    all_labels = physical_interval_labels()
    lookup = {label: i for i, label in enumerate(all_labels)}
    return [(label, lookup[label]) for label in labels]


def _print_paper_grid(headers: list[str], rows: list[list[str]]) -> None:
    """按中文显示宽度对齐，保留预先格式化的两位小数。"""
    def width(value: str) -> int:
        return sum(0 if unicodedata.combining(c) else
                   2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in value)

    widths = [max(width(row[i]) for row in [headers, *rows]) + 2
              for i in range(len(headers))]
    border = "+" + "+".join("-" * w for w in widths) + "+"
    def line(row: list[str]) -> str:
        cells = []
        for value, size in zip(row, widths):
            pad = size - width(value)
            cells.append(" " * (pad // 2) + value + " " * (pad - pad // 2))
        return "|" + "|".join(cells) + "|"
    print(border)
    print(line(headers))
    print(border)
    for row in rows:
        print(line(row))
        print(border)


def print_plan_paper_table(day: str, result: DayResult | None,
                           price: np.ndarray) -> None:
    print(f"\n表1  {day.replace('-', '/')} 指定时段及全天计划购电结果")
    req = requested_interval_indices()
    rows = []
    for i in range(0, 6, 3):
        row = []
        for label, idx in req[i:i + 3]:
            row.extend([label, f"{result.plan.grid[idx]:.2f}" if result else "未计算"])
        rows.append(row)
    total = f"{float(np.sum(result.plan.grid)):.2f}" if result else "未计算"
    cost = f"{float(price @ result.plan.grid):.2f}" if result else "未计算"
    rows.append(["全天计划购电量(kWh)", total, "", "", "全天计划购电费(元)", cost])
    _print_paper_grid(["时间段", "计划购电量/kWh"] * 3, rows)


def print_storage_paper_table(day: str, result: DayResult | None) -> None:
    print(f"\n表2  {day.replace('-', '/')} 储能设备充放电结果")
    if result:
        charge = result.dispatch.charge.reshape(6, BLOCK_SIZE).sum(axis=1)
        discharge = result.dispatch.discharge.reshape(6, BLOCK_SIZE).sum(axis=1)
    rows = []
    for i in range(0, 6, 2):
        row = []
        for j in (i, i + 1):
            row.extend([BLOCK_LABELS[j],
                        f"{charge[j]:.2f}" if result else "未计算",
                        f"{discharge[j]:.2f}" if result else "未计算"])
        rows.append(row)
    rows.append(["0:00储电量(kWh)",
                 f"{result.dispatch.energy[0]:.2f}" if result else "未计算", "",
                 "24:00储电量(kWh)",
                 f"{result.dispatch.energy[-1]:.2f}" if result else "未计算", ""])
    _print_paper_grid(["时间段", "充电量/kWh", "放电量/kWh"] * 2, rows)


def print_day_paper_tables(result: DayResult, price: np.ndarray) -> None:
    """保留单日打印接口。"""
    day = result.date_value.isoformat()
    print_plan_paper_table(day, result, price)
    print_storage_paper_table(day, result)



def _get_matplotlib():
    """按需加载 Matplotlib，并设置适合数学建模论文的统一风格。"""
    try:
        import matplotlib.pyplot as plt
        from matplotlib import font_manager
    except ImportError as exc:
        raise ImportError(
            "未安装 matplotlib。需要绘图时请先执行：pip install matplotlib"
        ) from exc

    available = {f.name for f in font_manager.fontManager.ttflist}
    candidates = [
        "Microsoft YaHei",
        "SimHei",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "Arial Unicode MS",
        "DejaVu Sans",
    ]
    chosen = next((name for name in candidates if name in available), "DejaVu Sans")

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [chosen, "DejaVu Sans"],
        "axes.unicode_minus": False,
        "font.size": 8,
        "axes.labelsize": 8,
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "legend.fontsize": 6.5,
        "axes.linewidth": 0.75,
        "lines.linewidth": 1.15,
        "figure.dpi": 120,
        "savefig.dpi": 450,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
        "ps.fonttype": 42,
        "mathtext.fontset": "stix",
    })
    return plt


C_ACTUAL = "#16324F"
C_FORECAST = "#5D91BB"
C_PLAN = "#2F80ED"
C_EMERGENCY = "#C96558"
C_CHARGE = "#18A999"
C_DISCHARGE = "#E79A56"
C_SOC = "#7357C6"
C_WASTE = "#8A8A8A"
C_GRID = "#C8CDD3"
C_ZERO = "#AEB4BA"


def _save_figure(fig, output_dir: Path, stem: str, dpi: int) -> list[Path]:
    """固定170 mm横向画幅，输出PNG及可编辑SVG/PDF。"""
    output_dir.mkdir(parents=True, exist_ok=True)
    png = output_dir / f"{stem}.png"
    pdf = output_dir / f"{stem}.pdf"
    svg = output_dir / f"{stem}.svg"
    fig.savefig(png, dpi=dpi, facecolor="white")
    fig.savefig(pdf, facecolor="white")
    fig.savefig(svg, facecolor="white")
    return [png, pdf, svg]


def _landscape_canvas(plt, panels=1, height=62):
    fig, axes = plt.subplots(1, panels, figsize=(170/25.4, height/25.4), squeeze=False)
    fig.subplots_adjust(left=0.105, right=0.975, bottom=0.20, top=0.72, wspace=0.38)
    return fig, axes[0]


def _panel_heading(ax, title):
    ax.set_title(title, loc="center", fontsize=8.5, fontweight="bold", color=C_ACTUAL,
                 y=1.34, pad=0)


def _outside_legend(ax, ncol=2):
    ax.legend(loc="lower left", bbox_to_anchor=(0,1.04), ncol=ncol,
              frameon=False, borderaxespad=0, handlelength=1.5, columnspacing=0.9)


def _paper_axes(ax, ygrid: bool = True) -> None:
    """统一轴线、网格与刻度样式，避免默认 Matplotlib 风格。"""
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#C5D1DC")
    ax.spines["bottom"].set_color("#C5D1DC")
    ax.tick_params(direction="out", length=2.5, width=0.6, colors="#546879")
    ax.set_axisbelow(True)
    if ygrid:
        ax.grid(axis="y", color=C_GRID, linewidth=0.45, alpha=0.55, linestyle=(0,(2,3)))


def _hourly_sum(x: np.ndarray) -> np.ndarray:
    """将144个10分钟电量聚合为24个小时电量；仅用于论文展示。"""
    arr = np.asarray(x, dtype=float)
    if arr.size != PERIODS:
        raise ValueError("小时聚合要求输入144个10分钟数据。")
    return arr.reshape(24, 6).sum(axis=1)


def _hourly_mean(x: np.ndarray) -> np.ndarray:
    """将144个10分钟功率聚合为24个小时平均功率；仅用于论文展示。"""
    arr = np.asarray(x, dtype=float)
    if arr.size != PERIODS:
        raise ValueError("小时聚合要求输入144个10分钟数据。")
    return arr.reshape(24, 6).mean(axis=1)


def _month_key(d: date) -> tuple[int, int]:
    return d.year, d.month


def _aggregate_monthly_for_plots(
    data: YearData,
    results: list[DayResult],
) -> dict[str, object]:
    """聚合月度经济性和风险指标，避免在终稿图中展示过多原始点。"""
    buckets: dict[tuple[int, int], dict[str, float]] = {}

    for result in results:
        key = _month_key(result.date_value)
        b = buckets.setdefault(key, {
            "planned_cost": 0.0,
            "emergency_cost": 0.0,
            "planned_grid": 0.0,
            "emergency_grid": 0.0,
            "waste": 0.0,
        })
        b["planned_cost"] += float(data.price @ result.plan.grid)
        b["emergency_cost"] += float(result.dispatch.emergency_cost)
        b["planned_grid"] += float(np.sum(result.plan.grid))
        b["emergency_grid"] += float(np.sum(result.dispatch.emergency))
        b["waste"] += float(np.sum(result.dispatch.waste))

    keys = sorted(buckets)
    labels = [f"{m}月" if y == 2025 else f"{y}-{m:02d}" for y, m in keys]

    def arr(name: str) -> np.ndarray:
        return np.asarray([buckets[k][name] for k in keys], dtype=float)

    planned_grid = arr("planned_grid")
    emergency_grid = arr("emergency_grid")
    waste = arr("waste")
    actual_supply = planned_grid + emergency_grid

    emergency_share = np.divide(
        emergency_grid,
        actual_supply,
        out=np.zeros_like(emergency_grid),
        where=actual_supply > 0,
    ) * 100.0
    waste_share = np.divide(
        waste,
        planned_grid,
        out=np.zeros_like(waste),
        where=planned_grid > 0,
    ) * 100.0

    return {
        "keys": keys,
        "labels": labels,
        "planned_cost": arr("planned_cost"),
        "emergency_cost": arr("emergency_cost"),
        "planned_grid": planned_grid,
        "emergency_grid": emergency_grid,
        "emergency_share": emergency_share,
        "waste_share": waste_share,
        "waste": waste,
    }


def _select_seasonal_results(results: list[DayResult]) -> list[DayResult]:
    if not results:
        raise ValueError("没有结果可用于绘图。")

    result_map = {r.date_value.isoformat(): r for r in results}
    selected = [result_map[d] for d in PAPER_DATES if d in result_map]
    if selected:
        return selected

    n = min(4, len(results))
    if n == 1:
        return [results[0]]
    idx = np.linspace(0, len(results) - 1, n).round().astype(int)
    # 去重，以防短样本线性取整产生重复索引。
    unique = []
    seen = set()
    for i in idx:
        if int(i) not in seen:
            unique.append(results[int(i)])
            seen.add(int(i))
    return unique


def plot_monthly_risk_economics(
    data: YearData, results: list[DayResult], output_dir: Path, dpi: int,
) -> list[Path]:
    """单图双轴：左轴费用堆叠柱、右轴电量占比折线；两轴均从零开始。

    紧急占比=紧急电量/总购电量；富余占比沿用富余电量/计划购电量。
    双轴仅用于同月展示不同单位，不根据线柱交点推断相关性。
    """
    plt = _get_matplotlib()
    from matplotlib.ticker import MaxNLocator
    import matplotlib.patheffects as pe
    monthly = _aggregate_monthly_for_plots(data, results)
    labels = list(monthly["labels"])
    x = np.arange(len(labels), dtype=float)
    planned = np.asarray(monthly["planned_cost"])/10000
    emergency = np.asarray(monthly["emergency_cost"])/10000
    risk = np.asarray(monthly["emergency_share"])
    waste = np.asarray(monthly["waste_share"])

    fig, ax = plt.subplots(figsize=(170/25.4, 75/25.4))
    fig.subplots_adjust(left=0.105, right=0.89, bottom=0.18, top=0.68)
    right = ax.twinx()
    bars = ax.bar(x, planned, width=0.58, color="#96BCE6",
                  edgecolor="white", linewidth=0.5, label="计划购电费（左轴）")
    caps = ax.bar(x, emergency, bottom=planned, width=0.58, color="#E8A58F",
                  edgecolor="white", linewidth=0.4, label="紧急购电费（左轴）")
    line1, = right.plot(x, risk, color="#B64E42", marker="o", ms=3.6,
                        lw=1.35, label="紧急购电占比（右轴）")
    line2, = right.plot(x, waste, color="#7357C6", ls="--", marker="D",
                        ms=3.3, lw=1.35, label="富余电量占比（右轴）")
    for line in (line1, line2):
        line.set_path_effects([pe.Stroke(linewidth=2.5, foreground="white"), pe.Normal()])
    _paper_axes(ax)
    right.grid(False)
    right.spines["top"].set_visible(False)
    right.spines["left"].set_visible(False)
    right.spines["bottom"].set_visible(False)
    right.spines["right"].set_visible(True)
    right.spines["right"].set_color("#C5D1DC")
    right.tick_params(axis="y", colors="#655680", labelsize=7.5, length=2.5)
    ax.tick_params(axis="both", labelsize=7.5)
    ax.set(xlim=(-0.65, max(len(labels)-0.35, 0.65)),
           ylim=(0, max(float(np.max(planned+emergency))*1.18, 1)))
    right.set_ylim(0, max(float(max(risk.max(), waste.max()))*1.18, 1))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
    right.yaxis.set_major_locator(MaxNLocator(nbins=4))
    ax.set_xticks(x, labels)
    ax.set_xlabel("月份", fontsize=8, labelpad=6)
    ax.set_ylabel("购电费用 / 万元", fontsize=8, labelpad=7, color="#355C9A")
    right.set_ylabel("电量占比 / %", fontsize=8, labelpad=7, color="#655680")
    fig.text(0.5, 0.945, "月度购电费用及电量占比", ha="center",
             fontsize=10, weight="bold", color=C_ACTUAL)
    fig.legend([bars, caps, line1, line2],
               [item.get_label() for item in (bars, caps, line1, line2)],
               loc="upper center", bbox_to_anchor=(0.5, 0.875), ncol=2,
               frameon=False, fontsize=7, handlelength=2.2,
               columnspacing=2.6, labelspacing=0.65)
    paths = _save_figure(fig, output_dir, "fig2_2_monthly_risk_economics", dpi)
    plt.close(fig)
    return paths


def compare_purchase_strategies(data: YearData, results: list[DayResult],
                               params: ModelParameters, cfg: ForecastConfig,
                               daily_cycle: bool) -> list[dict]:
    """固定同一预测与回测日期；各策略独立传递SOC，实际调度使用相同事后LP。"""
    variants = [("no_storage", "无储能·点预测"), ("point", "24h点预测LP"),
                ("margin10", "24h净负荷裕度10%"), ("margin20", "24h净负荷裕度20%")]
    variants += [(f"scenario{n}", f"{n}场景随机规划") for n in (7,15,30) if n != cfg.scenario_days]
    variants.append(("main", f"本文模型·48h·{cfg.scenario_days}场景"))
    date_to_idx = {d: i for i,d in enumerate(data.dates)}
    rows = []
    for code, label in variants:
        totals = dict(planned_cost_yuan=0.0, emergency_cost_yuan=0.0,
                      total_cost_yuan=0.0, planned_grid_kwh=0.0,
                      emergency_grid_kwh=0.0, waste_kwh=0.0)
        energy = float(results[0].dispatch.energy[0])
        counts = []
        for j, result in enumerate(results):
            idx = date_to_idx[result.date_value]
            predicted_net = result.load_pred_kw-result.pv_pred_kw
            if code == "main":
                grid, actual = result.plan.grid, result.dispatch
                counts.append(result.plan.scenario_count)
            elif code == "no_storage":
                grid = np.maximum(predicted_net, 0)*DT_HOURS
                net = (data.load_kw[idx]-data.pv_kw[idx])*DT_HOURS
                emergency = np.maximum(net-grid, 0)
                waste = np.maximum(grid-net, 0)
                emergency_cost = float(params.emergency_multiplier*data.price@emergency)
                actual = ActualDispatch(np.zeros(PERIODS), np.zeros(PERIODS), emergency, waste,
                    np.full(PERIODS+1,energy), emergency_cost,
                    float(data.price@grid)+emergency_cost, False, 0.0, 0.0)
                counts.append(1)
            else:
                if code.startswith("scenario"):
                    n = int(code.removeprefix("scenario"))
                    if result.scenario_net_kw is None:
                        raise ValueError("缺少历史场景，无法进行随机策略对比。请使用完整主流程生成结果。")
                    scenarios = result.scenario_net_kw[-n:]
                else:
                    margin = {"point":0.0,"margin10":0.10,"margin20":0.20}[code]
                    scenarios = (predicted_net+margin*np.maximum(predicted_net,0))[None,:]
                plan = solve_stochastic_plan(data.price, np.maximum(scenarios,0),
                    np.maximum(-scenarios,0), params, energy, daily_cycle)
                grid = plan.grid
                counts.append(plan.scenario_count)
                actual = solve_actual_dispatch(data.price, grid, data.load_kw[idx], data.pv_kw[idx],
                                               params, energy, daily_cycle)
            totals["planned_cost_yuan"] += float(data.price@grid)
            totals["emergency_cost_yuan"] += actual.emergency_cost
            totals["total_cost_yuan"] += actual.total_cost
            totals["planned_grid_kwh"] += float(np.sum(grid))
            totals["emergency_grid_kwh"] += float(np.sum(actual.emergency))
            totals["waste_kwh"] += float(np.sum(actual.waste))
            if not daily_cycle:
                energy = float(actual.energy[-1])
            if j == 0 or (j+1)%30 == 0 or j == len(results)-1:
                print(f"[策略对比] {label}: {j+1}/{len(results)} 天", flush=True)
        supply = totals["planned_grid_kwh"]+totals["emergency_grid_kwh"]
        rows.append(dict(strategy=code, label=label, days=len(results),
            start=results[0].date_value.isoformat(), end=results[-1].date_value.isoformat(),
            scenario_count_min=min(counts), scenario_count_max=max(counts),
            emergency_share_pct=100*totals["emergency_grid_kwh"]/supply if supply>0 else 0.0,
            **totals))
    return rows


def emergency_risk_matrix(results: list[DayResult]) -> tuple[list[tuple[int,int]],np.ndarray,np.ndarray,list[dict]]:
    """小时内任一10分钟H>阈值即记为事件；分母为该月实际回测天数。"""
    buckets = {}
    for result in results:
        h = np.asarray(result.dispatch.emergency).reshape(24,6)
        buckets.setdefault(_month_key(result.date_value),[]).append(
            (np.any(h>EMERGENCY_THRESHOLD,axis=1), h.sum(axis=1)))
    keys = sorted(buckets)
    frequency, intensity, rows = [], [], []
    for key in keys:
        events = np.asarray([r[0] for r in buckets[key]])
        amounts = np.asarray([r[1] for r in buckets[key]])
        n = len(events)
        f = events.mean(axis=0)
        risk = np.where(events,amounts,0).mean(axis=0)
        frequency.append(f*100)
        intensity.append(risk)
        for hour in range(24):
            conditional = risk[hour]/f[hour] if f[hour]>0 else 0.0
            rows.append(dict(month=f"{key[0]}-{key[1]:02d}",hour=hour,observed_days=n,
                event_days=int(events[:,hour].sum()), frequency_pct=float(100*f[hour]),
                conditional_kwh=float(conditional), risk_intensity_kwh=float(risk[hour])))
    return keys, np.asarray(frequency), np.asarray(intensity), rows


def plot_forecast_uncertainty(data: YearData, results: list[DayResult],
                              output_dir: Path, dpi: int) -> list[Path]:
    """代表日预测一致性散点与经验区间覆盖率；每点一个10分钟时段。

    覆盖率为实际净负荷落在决策前场景P10–P90内的比例，不是校准置信度。
    选定日期的144个原始点全部展示，不平滑、不抽样、不添加随机抖动。
    """
    plt = _get_matplotlib()
    from matplotlib.lines import Line2D
    from matplotlib.ticker import MaxNLocator
    selected = _select_seasonal_results(results)
    palette = ["#319A92", "#DFAC4B", "#AA779F", "#527FAE"]
    markers = ["o", "s", "^", "D"]
    seasons = {3:"春季", 6:"夏季", 9:"秋季", 12:"冬季"}
    prepared = []
    for result in selected:
        if result.scenario_net_kw is None:
            raise ValueError("缺少决策前场景，不能计算经验区间覆盖率。")
        source_days = [
            date.fromisoformat(part)
            for source in result.scenario_source_dates
            for part in source.split("+")
        ]
        if any(source_day >= result.date_value for source_day in source_days):
            raise ValueError("不确定区间场景包含未来数据。")
        idx = data.dates.index(result.date_value)
        actual = data.load_kw[idx]-data.pv_kw[idx]
        predicted = result.load_pred_kw-result.pv_pred_kw
        lower, upper = np.quantile(result.scenario_net_kw[-result.plan.scenario_count:],
                                   [0.1,0.9], axis=0)
        mae = float(np.mean(np.abs(actual-predicted)))
        coverage = float(np.mean((actual>=lower)&(actual<=upper))*100)
        label = f"{seasons.get(result.date_value.month, '代表日')} {result.date_value:%m-%d}"
        prepared.append((actual, predicted, mae, coverage, label))
    fig = plt.figure(figsize=(170/25.4, 82/25.4))
    ax = fig.add_axes([0.105, 0.25, 0.40, 0.57])
    audit = fig.add_axes([0.635, 0.25, 0.335, 0.56])
    extent = np.concatenate([v for a,p,_,_,_ in prepared for v in (a,p)])
    lo, hi = float(extent.min()), float(extent.max())
    pad = max(hi-lo,1)*0.08
    bounds = (lo-pad, hi+pad)
    ax.plot(bounds, bounds, color="#8493A2", lw=0.9, ls=(0,(4,3)), zorder=1)
    handles = []
    for i,(actual,predicted,mae,coverage,label) in enumerate(prepared):
        color, marker = palette[i%4], markers[i%4]
        ax.scatter(actual, predicted, s=10, color=color, marker=marker,
                   alpha=0.58, edgecolors="white", linewidths=0.25, zorder=3)
        handles.append(Line2D([],[],color=color,marker=marker,ls="none",
                              markersize=4,label=label))
        y = i*1.25
        audit.text(0, y-0.31, label, fontsize=7.2, color=color, weight="bold")
        audit.text(122, y-0.31, f"MAE {mae:.2f} kW", ha="right",
                   fontsize=6.3,color="#536778")
        # 满轨道90显示单位对应100%，右侧单独留出百分数文字区。
        audit.barh(y,90,height=0.16,color="#EAF0F4",edgecolor="none")
        audit.barh(y,coverage*0.9,height=0.16,color=color,edgecolor="none")
        audit.scatter([coverage*0.9],[y],s=18,color=color,edgecolor="white",lw=0.6,zorder=3)
        audit.text(122,y,f"{coverage:.2f}%",ha="right",va="center",
                   fontsize=7,color=C_ACTUAL)
    ax.set(xlim=bounds, ylim=bounds, xlabel="实际净负荷 / kW", ylabel="预测净负荷 / kW")
    ax.set_aspect("equal", adjustable="box")
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
    _paper_axes(ax)
    ax.tick_params(labelsize=7)
    ax.xaxis.label.set_size(8)
    ax.yaxis.label.set_size(8)
    ax.text(0.05,0.95,"预测 = 实际",transform=ax.transAxes,
            va="top",fontsize=6.5,color="#536778")
    audit.set(xlim=(0,125),ylim=(max(len(prepared)-1,0)*1.25+0.65,-0.85))
    audit.set_axis_off()
    fig.text(0.305,0.92,"净负荷预测与实际值对比",ha="center",fontsize=9,weight="bold",color=C_ACTUAL)
    fig.text(0.8025,0.92,"代表日预测误差与区间覆盖率",ha="center",fontsize=8,weight="bold",color=C_ACTUAL)
    fig.text(0.8025,0.855,"P10–P90 区间覆盖率",ha="center",
             fontsize=6.5,color="#536778")
    fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(0.535,0.025),
               ncol=len(handles),frameon=False,fontsize=6.8,
               handletextpad=0.45,columnspacing=1.5)
    paths = _save_figure(fig,output_dir,"fig2_1_forecast_uncertainty",dpi)
    plt.close(fig)
    return paths


def plot_emergency_risk_heatmap(results: list[DayResult], output_dir: Path,
                               dpi: int, metric: str = "frequency") -> list[Path]:
    plt = _get_matplotlib()
    from matplotlib.colors import LinearSegmentedColormap
    keys,freq,intensity,rows = emergency_risk_matrix(results)
    values = freq if metric=="frequency" else intensity
    title = "紧急购电发生频率 / %" if metric=="frequency" else "紧急购电风险强度 / kWh"
    fig,ax = plt.subplots(figsize=(170/25.4,76/25.4))
    fig.subplots_adjust(left=0.13,right=0.89,bottom=0.18,top=0.83)
    cmap = LinearSegmentedColormap.from_list("energy_risk",["#FFFCF2","#FBE4AA","#F2AA61","#D8664E","#8C2536"])
    # 色标保留真实百分数并从0起，按观测范围向上取整，不把低频风险夸成100%。
    color_max = max(10.0, float(np.ceil(values.max()/10)*10)) if metric=="frequency" else max(float(values.max()),1)
    mesh = ax.pcolormesh(np.arange(25),np.arange(len(keys)+1),values,cmap=cmap,
        vmin=0,vmax=color_max,edgecolors="white",linewidth=0.45)
    ax.invert_yaxis()
    counts = {r["month"]:r["observed_days"] for r in rows}
    ax.set_yticks(np.arange(len(keys))+0.5,[f"{m}月 ({counts[f'{y}-{m:02d}']}天)" for y,m in keys])
    ax.set_xticks(np.arange(0,25,2),[f"{h:02d}:00" for h in range(0,25,2)])
    ax.set_xlabel("小时区间起点（每格1小时）")
    ax.tick_params(length=0,labelsize=6.5,pad=5)
    for spine in ax.spines.values():
        spine.set_visible(False)
    cax=fig.add_axes([0.91,0.18,0.017,0.65])
    bar=fig.colorbar(mesh,cax=cax)
    bar.outline.set_visible(False)
    bar.ax.tick_params(labelsize=6.5,length=2)
    ax.set_title(title,loc="center",fontsize=9,color=C_ACTUAL,pad=18)
    paths=_save_figure(fig,output_dir,"fig2_2_emergency_risk_heatmap",dpi)
    plt.close(fig)
    return paths


def plot_strategy_tradeoff(comparisons: list[dict], output_dir: Path, dpi: int) -> list[Path]:
    """同序三指标横向比较；各轴从0起，保留真实数值，不把主模型标成全指标最优。"""
    plt = _get_matplotlib()
    from matplotlib.ticker import MaxNLocator
    if len(comparisons) < 2 or sum(r["strategy"] == "main" for r in comparisons) != 1:
        raise ValueError("策略对比图需要至少两种真实回测策略且恰有一个主模型。")
    if len({(r["start"], r["end"], r["days"]) for r in comparisons}) != 1:
        raise ValueError("策略回测日期不一致，禁止直接比较。")
    # 三列使用相同策略顺序；不按各指标分别排序，便于跨列逐行比较。
    rows = [r for r in comparisons if r["strategy"] != "main"] + [
        next(r for r in comparisons if r["strategy"] == "main")]
    labels = [r["label"].replace("·", " / ").replace("正净负荷裕度10%", "10%安全裕度")
              .replace("正净负荷裕度20%", "20%安全裕度").replace("点预测LP", "点预测优化")
              for r in rows]
    values = [
        np.array([r["total_cost_yuan"]/10000 for r in rows]),
        np.array([r["emergency_share_pct"] for r in rows]),
        np.array([r["waste_kwh"]/10000 for r in rows])]
    titles = ["总购电费用", "紧急购电量占比", "富余电量"]
    units = ["万元", "%", "万kWh"]
    fig, axes = plt.subplots(1, 3, sharey=True, figsize=(170/25.4, 79/25.4))
    fig.subplots_adjust(left=0.25, right=0.98, bottom=0.18, top=0.77, wspace=0.22)
    y = np.arange(len(rows))
    for col, (ax, vals, title, unit) in enumerate(zip(axes, values, titles, units)):
        maximum = max(float(vals.max()), 1e-6)
        ax.set_xlim(0, maximum*1.62)
        ax.set_ylim(len(rows)-0.4, -0.6)
        ax.set_yticks(y)
        if col == 0:
            ax.set_yticklabels(labels, fontsize=7)
        ax.tick_params(axis="y", length=0, pad=8, labelleft=(col==0))
        ax.tick_params(axis="x", labelsize=6.5, length=2.5)
        ax.xaxis.set_major_locator(MaxNLocator(nbins=3, min_n_ticks=2))
        ax.set_xlabel(unit, fontsize=7.5, labelpad=5)
        ax.set_title(title, loc="center", fontsize=8.5, color=C_ACTUAL, weight="bold", pad=12)
        _paper_axes(ax, ygrid=False)
        ax.grid(axis="x", color="#E5EAF0", ls=(0,(2,3)), lw=0.5)
        ax.set_axisbelow(True)
        for i, (row, val) in enumerate(zip(rows, vals)):
            is_main = row["strategy"] == "main"
            color = "#176B78" if is_main else "#A3B9CC"
            if is_main:
                ax.axhspan(i-0.43, i+0.43, color="#176B78", alpha=0.065, lw=0, zorder=0)
            ax.barh(i, val, height=0.46, color=color,
                    edgecolor=color, lw=0.5, hatch="//" if is_main else None, zorder=2)
            ax.text(val+maximum*0.045, i, f"{val:.2f}", va="center", ha="left",
                    fontsize=6.5, color="#176B78" if is_main else C_ACTUAL,
                    weight="bold" if is_main else "normal")
    for tick, row in zip(axes[0].get_yticklabels(), rows):
        if row["strategy"] == "main":
            tick.set_color("#176B78")
            tick.set_fontweight("bold")
    fig.text(0.5, 0.94, "不同购电策略的费用与电量比较", ha="center", color=C_ACTUAL,
             fontsize=10, weight="bold")
    paths = _save_figure(fig, output_dir, "fig2_3_strategy_tradeoff", dpi)
    plt.close(fig)
    return paths


def visualize_results(
    data: YearData,
    results: list[DayResult],
    output_dir: Path,
    dpi: int = 450,
    comparisons: list[dict] | None = None,
    risk_metric: str = "frequency",
) -> list[Path]:
    """输出四组论文图及配套图注。"""
    if not results:
        raise ValueError("没有结果可视化。")

    dpi = max(300, int(dpi))
    output_dir.mkdir(parents=True, exist_ok=True)
    if not comparisons:
        raise ValueError("缺少策略回测数据，请使用 --plot 完整计算后绘图。")
    written: list[Path] = []
    written.extend(plot_forecast_uncertainty(data, results, output_dir, dpi))
    written.extend(plot_emergency_risk_heatmap(results, output_dir, dpi, risk_metric))
    written.extend(plot_strategy_tradeoff(comparisons,output_dir,dpi))
    written.extend(plot_monthly_risk_economics(data,results,output_dir,dpi))
    captions = [
        "图1 净负荷预测与实际值对比及代表日预测误差。每个点对应一个10分钟时段，虚线表示预测值等于实际值。MAE为平均绝对误差；覆盖率为实际值落在决策前历史残差场景的P10–P90区间内的时段比例，不等同于预测准确率。",
        ("图2 紧急购电发生频率。每格为该月该小时发生紧急购电的回测天数除以该月实际回测天数；小时内任一10分钟发生紧急购电即计一次。"
         if risk_metric == "frequency" else
         "图2 紧急购电风险强度。每格表示该月对应小时的日均紧急购电量，分母为实际回测天数。"),
        "图3 月度购电费用及电量占比。堆叠柱为计划购电费与紧急购电费，使用左轴；折线为紧急购电量占总购电量的比例及富余电量占计划购电量的比例，使用右轴。",
        "图4 不同购电策略的费用与电量比较。本文模型采用跨日SOC连续传递、48小时滚动预览及窗口末端储能价值；对照策略采用相同回测日期和预测输入。紧急购电量占比为紧急购电量除以总购电量，深青色斜线条形标识本文模型。",
    ]
    (output_dir / "figure_captions.txt").write_text("\n\n".join(captions), encoding="utf-8")
    print("\n论文可视化已生成：")
    for path in written:
        print(f"  {path.resolve()}")
    return written


def warm_up_state_and_residuals(
    forecaster: RollingForecaster,
    data: YearData,
    cfg: ForecastConfig,
    residual_history: list[ForecastRecord],
    params: ModelParameters,
    target_day_idx: int,
    daily_cycle: bool,
) -> float:
    """
    1月1日至可训练日前缺少足够历史，储能保持题设初值；从1月15日起用同一滚动策略
    实际运行。预热结果不写入result2，但其日末SOC传给下一天。
    """
    energy = params.initial_energy
    start = max(cfg.residual_warmup_start_day, 14)
    for d in range(start, target_day_idx):
        pred_load_2d, pred_pv_2d = forecaster.predict_two_day(d)
        if daily_cycle:
            scenario_load, scenario_pv = generate_scenarios(
                pred_load_2d[0], pred_pv_2d[0], residual_history, cfg.scenario_days)
            plan = solve_stochastic_plan(
                data.price, scenario_load, scenario_pv, params, energy, True)
            dispatch = solve_actual_dispatch(
                data.price, plan.grid, data.load_kw[d], data.pv_kw[d], params, energy, True)
        else:
            scenario_load, scenario_pv, _ = generate_two_day_scenarios(
                pred_load_2d, pred_pv_2d, residual_history, cfg.scenario_days)
            value = terminal_energy_value(data.price, params)
            plan = solve_stochastic_plan(
                np.tile(data.price, 2), scenario_load, scenario_pv, params, energy, False, value)
            assert plan.preview_grid is not None
            dispatch = solve_actual_dispatch(
                data.price, plan.grid, data.load_kw[d], data.pv_kw[d], params, energy, False,
                preview_grid=plan.preview_grid,
                preview_load_kw=pred_load_2d[1],
                preview_pv_kw=pred_pv_2d[1],
                terminal_value_per_kwh=value,
            )
        residual_history.append(
            ForecastRecord(
                day_index=d,
                date_value=data.dates[d],
                load_pred_kw=pred_load_2d[0],
                pv_pred_kw=pred_pv_2d[0],
                load_error_kw=data.load_kw[d] - pred_load_2d[0],
                pv_error_kw=data.pv_kw[d] - pred_pv_2d[0],
            )
        )
        if not daily_cycle:
            energy = float(dispatch.energy[-1])
    return energy


def run_problem2(
    data: YearData,
    params: ModelParameters,
    cfg: ForecastConfig,
    start_date: date,
    end_date: date,
    daily_cycle: bool,
    verbose: bool,
) -> tuple[list[DayResult], dict[str, float]]:
    forecaster = RollingForecaster(data.load_kw, data.pv_kw, data.dates, cfg)
    residual_history: list[ForecastRecord] = []

    date_to_idx = {d: i for i, d in enumerate(data.dates)}
    if start_date not in date_to_idx or end_date not in date_to_idx:
        raise ValueError("起止日期必须存在于附件2中。")
    start_idx = date_to_idx[start_date]
    end_idx = date_to_idx[end_date]
    if start_idx > end_idx:
        raise ValueError("start_date不能晚于end_date。")
    if start_idx < max(cfg.residual_warmup_start_day, 14):
        raise ValueError("正式回测起点不得早于1月15日；更早日期缺少LightGBM训练历史。")

    results: list[DayResult] = []
    load_pred_all: list[np.ndarray] = []
    pv_pred_all: list[np.ndarray] = []
    load_true_all: list[np.ndarray] = []
    pv_true_all: list[np.ndarray] = []

    initial_energy = warm_up_state_and_residuals(
        forecaster, data, cfg, residual_history, params, start_idx, daily_cycle)
    output_initial_energy = initial_energy
    value = terminal_energy_value(data.price, params)

    total_days = end_idx - start_idx + 1
    for k, d in enumerate(range(start_idx, end_idx + 1), start=1):
        day = data.dates[d]
        pred_load_2d, pred_pv_2d = forecaster.predict_two_day(d)
        pred_load, pred_pv = pred_load_2d[0], pred_pv_2d[0]

        if any(rec.date_value >= day for rec in residual_history):
            raise ValueError("残差历史包含目标日或未来日期；回测起始日期应不早于2月1日。")

        if daily_cycle:
            scenario_load, scenario_pv = generate_scenarios(
                pred_load, pred_pv, residual_history, cfg.scenario_days)
            scenario_sources = tuple(
                r.date_value.isoformat() for r in residual_history[-cfg.scenario_days:])
            horizon_price = data.price
        else:
            scenario_load, scenario_pv, scenario_sources = generate_two_day_scenarios(
                pred_load_2d, pred_pv_2d, residual_history, cfg.scenario_days)
            horizon_price = np.tile(data.price, 2)

        plan = solve_stochastic_plan(
            horizon_price,
            scenario_load,
            scenario_pv,
            params,
            initial_energy=initial_energy,
            daily_cycle=daily_cycle,
            terminal_value_per_kwh=0.0 if daily_cycle else value,
        )

        if daily_cycle:
            dispatch = solve_actual_dispatch(
                data.price, plan.grid, data.load_kw[d], data.pv_kw[d], params,
                initial_energy=initial_energy, daily_cycle=True)
        else:
            assert plan.preview_grid is not None
            dispatch = solve_actual_dispatch(
                data.price, plan.grid, data.load_kw[d], data.pv_kw[d], params,
                initial_energy=initial_energy, daily_cycle=False,
                preview_grid=plan.preview_grid,
                preview_load_kw=pred_load_2d[1],
                preview_pv_kw=pred_pv_2d[1],
                terminal_value_per_kwh=value,
            )

        result = DayResult(
            date_value=day,
            load_pred_kw=pred_load,
            pv_pred_kw=pred_pv,
            plan=plan,
            dispatch=dispatch,
            scenario_net_kw=scenario_load[:, :PERIODS]-scenario_pv[:, :PERIODS],
            scenario_source_dates=scenario_sources,
            next_load_pred_kw=pred_load_2d[1],
            next_pv_pred_kw=pred_pv_2d[1],
        )
        results.append(result)

        # 当天结束后，真实数据才进入后续预测残差池，避免未来信息泄露。
        residual_history.append(
            ForecastRecord(
                day_index=d,
                date_value=day,
                load_pred_kw=pred_load,
                pv_pred_kw=pred_pv,
                load_error_kw=data.load_kw[d] - pred_load,
                pv_error_kw=data.pv_kw[d] - pred_pv,
            )
        )

        load_pred_all.append(pred_load)
        pv_pred_all.append(pred_pv)
        load_true_all.append(data.load_kw[d])
        pv_true_all.append(data.pv_kw[d])

        if not daily_cycle:
            initial_energy = float(dispatch.energy[-1])

        if verbose or k == 1 or k == total_days or k % 10 == 0:
            planned_cost = float(data.price @ plan.grid)
            print(
                f"[{k:3d}/{total_days}] {day} | "
                f"scenarios={plan.scenario_count:2d} | "
                f"plan={planned_cost:12.2f} | "
                f"emergency={dispatch.emergency_cost:12.2f} | "
                f"total={dispatch.total_cost:12.2f}"
            )

    y_load = np.concatenate(load_true_all)
    p_load = np.concatenate(load_pred_all)
    y_pv = np.concatenate(pv_true_all)
    p_pv = np.concatenate(pv_pred_all)

    metrics = {
        "load_mae_kw": float(mean_absolute_error(y_load, p_load)),
        "load_rmse_kw": float(math.sqrt(mean_squared_error(y_load, p_load))),
        "pv_mae_kw": float(mean_absolute_error(y_pv, p_pv)),
        "pv_rmse_kw": float(math.sqrt(mean_squared_error(y_pv, p_pv))),
        "planned_cost_yuan": float(sum(data.price @ r.plan.grid for r in results)),
        "emergency_cost_yuan": float(sum(r.dispatch.emergency_cost for r in results)),
        "total_cost_yuan": float(sum(r.dispatch.total_cost for r in results)),
        "planned_grid_kwh": float(sum(np.sum(r.plan.grid) for r in results)),
        "emergency_grid_kwh": float(sum(np.sum(r.dispatch.emergency) for r in results)),
        "waste_kwh": float(sum(np.sum(r.dispatch.waste) for r in results)),
        "initial_soc_kwh": float(output_initial_energy),
        "final_soc_kwh": float(results[-1].dispatch.energy[-1]),
        "min_soc_kwh": float(min(np.min(r.dispatch.energy) for r in results)),
        "max_soc_kwh": float(max(np.max(r.dispatch.energy) for r in results)),
        "soc_continuity_error_kwh": float(max(
            [abs(results[i].dispatch.energy[-1] - results[i + 1].dispatch.energy[0])
             for i in range(len(results) - 1)] or [0.0])),
        "terminal_value_yuan_per_kwh": float(0.0 if daily_cycle else value),
        "rolling_horizon_hours": float(24 if daily_cycle else 48),
    }
    return results, metrics


def print_metrics(metrics: dict[str, float]) -> None:
    print("\n================ 全期汇总 ================")
    print(f"负载预测 MAE : {metrics['load_mae_kw']:.2f} kW")
    print(f"负载预测 RMSE: {metrics['load_rmse_kw']:.2f} kW")
    print(f"光伏预测 MAE : {metrics['pv_mae_kw']:.2f} kW")
    print(f"光伏预测 RMSE: {metrics['pv_rmse_kw']:.2f} kW")
    print(f"计划购电量    : {metrics['planned_grid_kwh']:.2f} kWh")
    print(f"紧急购电量    : {metrics['emergency_grid_kwh']:.2f} kWh")
    print(f"计划购电费    : {metrics['planned_cost_yuan']:.2f} 元")
    print(f"紧急购电费    : {metrics['emergency_cost_yuan']:.2f} 元")
    print(f"总购电费      : {metrics['total_cost_yuan']:.2f} 元")
    print(f"富余/弃电量   : {metrics['waste_kwh']:.2f} kWh")
    print("\n================ 跨日SOC与终端价值 ================")
    print(f"滚动优化窗口  : {metrics['rolling_horizon_hours']:.0f} h")
    print(f"终端储能价值  : {metrics['terminal_value_yuan_per_kwh']:.6f} 元/kWh")
    print(f"输出期初SOC   : {metrics['initial_soc_kwh']:.4f} kWh")
    print(f"输出期末SOC   : {metrics['final_soc_kwh']:.4f} kWh")
    print(f"全期SOC范围   : {metrics['min_soc_kwh']:.4f}–{metrics['max_soc_kwh']:.4f} kWh")
    print(f"跨日连续残差  : {metrics['soc_continuity_error_kwh']:.3e} kWh")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="C题问题2：滚动LightGBM + 残差场景 + 两阶段随机LP"
    )
    parser.add_argument(
        "--price",
        type=Path,
        default=BASE_DIR.parent / "附件1.xlsx",
        help="附件1路径",
    )
    parser.add_argument(
        "--actual",
        type=Path,
        default=BASE_DIR.parent / "附件2.xlsx",
        help="附件2路径",
    )
    parser.add_argument(
        "--template",
        type=Path,
        default=BASE_DIR.parent / "附件5" / "result2.xlsx",
        help="官方result2.xlsx模板路径；不存在时自动生成结构化备用文件",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=BASE_DIR / "result2.xlsx",
    )
    parser.add_argument("--start", default="2025-02-01")
    parser.add_argument("--end", default="2025-12-31")
    parser.add_argument(
        "--scenario-days",
        type=int,
        default=30,
        help="使用最近多少个样本外残差日构造场景，默认30",
    )
    parser.add_argument(
        "--retrain-every",
        type=int,
        default=1,
        help="LightGBM每隔多少天重训一次；最终论文建议1，调试可设7",
    )
    parser.add_argument(
        "--n-estimators",
        type=int,
        default=180,
        help="LightGBM树数量",
    )
    cycle_group = parser.add_mutually_exclusive_group()
    cycle_group.add_argument(
        "--daily-cycle",
        action="store_true",
        help="退回旧版每日SOC闭环假设（仅用于消融对比，不建议作为主结果）",
    )
    cycle_group.add_argument(
        "--no-daily-cycle",
        dest="daily_cycle",
        action="store_false",
        help=argparse.SUPPRESS,
    )
    parser.set_defaults(daily_cycle=False)
    parser.add_argument(
        "--terminal-value-scale",
        type=float,
        default=1.0,
        help="终端价值缩放系数；lambda_E=该系数×放电效率×日内电价中位数，默认1.0",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="打印每天详细进度",
    )
    parser.add_argument(
        "--plot",
        action="store_true",
        help="重新回测对比策略，输出三张主图和月度风险经济图（PNG/PDF/SVG），不保存缓存",
    )
    parser.add_argument("--risk-metric", choices=["frequency","intensity"], default="frequency")
    parser.add_argument(
        "--fig-dir",
        type=Path,
        default=BASE_DIR / "figures_problem2",
        help="四组图片输出目录，默认 问题2/figures_problem2",
    )
    parser.add_argument(
        "--dpi",
        type=int,
        default=600,
        help="PNG导出分辨率，默认600 dpi",
    )
    return parser.parse_args()


def print_emergency_paper_table(results: list[DayResult]) -> None:
    """表3：四日期并排、每日期两列；连续紧急购电时段合并，行数自动扩展。"""
    result_map = {r.date_value.isoformat(): r for r in results}
    groups = []
    for day in PAPER_DATES:
        result = result_map.get(day)
        if result is None:
            groups.append([("未计算", "—")])
        else:
            intervals = merge_emergency_intervals(result.dispatch.emergency)
            groups.append([(label, f"{amount:.2f}") for label, amount in intervals]
                          or [("无", "0.00")])

    # 按终端显示宽度处理中文，且不依赖可选的tabulate包或其数字自动转换。
    def width(text: str) -> int:
        return sum(0 if unicodedata.combining(c) else
                   2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in text)

    def center(text: str, size: int) -> str:
        spare = max(0, size-width(text))
        return " "*(spare//2) + text + " "*(spare-spare//2)

    time_width = max(13, max(width(label) for group in groups for label, _ in group))
    amount_width = max(13, max(width(amount) for group in groups for _, amount in group))
    widths = [time_width, amount_width]*len(PAPER_DATES)
    border = "+" + "+".join("-"*w for w in widths) + "+"
    group_width = time_width+amount_width+1
    group_border = "+" + "+".join("-"*group_width for _ in PAPER_DATES) + "+"
    titles = [f"{d.year}.{d.month}.{d.day}" for d in map(date.fromisoformat, PAPER_DATES)]
    print("\n表3  微网在指定日期的紧急购电量（单位：kWh）")
    print(group_border)
    print("|" + "|".join(center(t, group_width) for t in titles) + "|")
    print(border)
    print("|" + "|".join(center(t, w) for t, w in zip(["时间段", "购电量"]*len(groups), widths)) + "|")
    print(border)
    for i in range(max(3, max(map(len, groups)))):
        row = [cell for group in groups for cell in (group[i] if i < len(group) else ("—", "—"))]
        print("|" + "|".join(center(t, w) for t, w in zip(row, widths)) + "|")
        print(border)
    print("注：相邻紧急购电时段合并并累加电量；无事件记0.00，未计算不视为零。")
    print("    极小正电量保留两位小数后也可能显示0.00；时段认定沿用模型原阈值。")


def main() -> None:
    args = parse_args()
    if args.terminal_value_scale < 0:
        raise ValueError("terminal-value-scale不能为负。")
    params = ModelParameters(terminal_value_scale=args.terminal_value_scale)
    cfg = ForecastConfig(
        scenario_days=max(1, args.scenario_days),
        retrain_every=max(1, args.retrain_every),
        n_estimators=max(20, args.n_estimators),
    )

    start_date = datetime.strptime(args.start, "%Y-%m-%d").date()
    end_date = datetime.strptime(args.end, "%Y-%m-%d").date()

    data = load_year_data(args.price, args.actual)
    results, metrics = run_problem2(
        data=data,
        params=params,
        cfg=cfg,
        start_date=start_date,
        end_date=end_date,
        daily_cycle=args.daily_cycle,
        verbose=args.verbose,
    )

    template = args.template if args.template.exists() else None
    validate_cross_day_results(results, params)
    write_result2(template, args.output, results)

    result_map = {r.date_value.isoformat(): r for r in results}
    for d in PAPER_DATES:
        print_plan_paper_table(d, result_map.get(d), data.price)
    for d in PAPER_DATES:
        print_storage_paper_table(d, result_map.get(d))

    print_emergency_paper_table(results)
    print_metrics(metrics)

    if args.plot:
        comparisons = compare_purchase_strategies(data,results,params,cfg,args.daily_cycle)
        visualize_results(
            data=data,
            results=results,
            output_dir=args.fig_dir,
            dpi=args.dpi,
            comparisons=comparisons,
            risk_metric=args.risk_metric,
        )

    print(f"\n完整结果已保存至：{args.output.resolve()}")


if __name__ == "__main__":
    main()
