from __future__ import annotations

"""2026 C题问题4：动态电价下的微网购电策略。

本文件同时完成：
1) 问题4-2：对应问题2。在每天0:00制定全天计划购电量，使用
   “净负荷-电价联合残差场景 + 两阶段随机线性规划”，实际不足按实时电价5倍紧急购电。
2) 问题4-3：对应问题3。在0:00制定初始计划，并在6:00/12:00/18:00可滚动更新，
   使用“联合场景 SAA-MPC”，上调按1.5倍实时电价、下调取消部分按0.5倍实时电价退回。
3) 读取附件1~4；输出 result4-2.xlsx、result4-3.xlsx 和 figures/。


运行：
    python problem4.py
快速测试：
    python problem4.py --start 2025-02-01 --end 2025-02-03
不生成图：
    python problem4.py --no-plot

建模口径：
- 附件4实时电价只在真实结算时使用；制定计划时使用严格walk-forward价格预测，避免未来泄漏。
- 负荷采用7/14/21日同刻凸组合预测；光伏采用附件3在0/6/12/18时发布的24小时预报并线性插值。
- 电价基准预测采用1/7/14日同刻凸组合；6/12/18时利用当天已观测价格误差作滚动偏差校正。
- 净负荷残差与电价残差联合标准化后用k-medoids缩减为K个联合场景。
- 主模型默认K=7、残差池28天；6000kWh仅作为全期初始SOC。
- 每个决策时刻采用固定48小时滚动窗口，并在窗口末端计入剩余储能价值，
  不再强制每天回到6000kWh。
"""

import argparse
import math
import re
import shutil
import sys
import warnings
from dataclasses import dataclass, field
from datetime import date, datetime, time
from pathlib import Path

sys.dont_write_bytecode = True

import numpy as np
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from scipy.optimize import linprog
from scipy.sparse import csr_matrix, lil_matrix

BASE_DIR = Path(__file__).resolve().parent
PERIODS = 144
DT_HOURS = 1.0 / 6.0
BLOCK_SIZE = 24
RELEASES = (0, 6, 12, 18)
POLICIES = {
    "only_0": (),
    "0+6": (6,),
    "0+6+12": (6, 12),
    "0+6+12+18": (6, 12, 18),
}
POLICY_LABELS = {
    "only_0": "仅0:00",
    "0+6": "0:00+6:00",
    "0+6+12": "0:00+6:00+12:00",
    "0+6+12+18": "0:00+6:00+12:00+18:00",
}
BLOCK_LABELS = [
    "0:00-4:00", "4:00-8:00", "8:00-12:00",
    "12:00-16:00", "16:00-20:00", "20:00-24:00",
]
EPS = 1e-8
EMERGENCY_THRESHOLD = 1e-6


@dataclass(frozen=True)
class ModelParameters:
    capacity_min: float = 1200.0
    capacity_max: float = 10800.0
    initial_soc: float = 6000.0
    lookahead_days: int = 1
    terminal_value_scale: float = 1.0
    max_power_kw: float = 5000.0
    charge_efficiency: float = 0.90
    discharge_efficiency: float = 0.90
    emergency_multiplier: float = 5.0
    increase_multiplier: float = 1.5
    cancellation_refund_multiplier: float = 0.5
    residual_days: int = 28
    k_scenarios: int = 7
    load_weight_window: int = 28
    price_weight_window: int = 28
    price_bias_slots: int = 12  # 日内更新时使用最近2小时价格误差进行偏差校正

    @property
    def max_energy_per_slot(self) -> float:
        return self.max_power_kw * DT_HOURS


def terminal_energy_value(price: np.ndarray, params: ModelParameters) -> float:
    """滚动窗口末端每剩余1 kWh电量的近似经济价值（元/kWh）。"""
    values = np.asarray(price, dtype=float).reshape(-1)
    values = values[np.isfinite(values)]
    if values.size == 0:
        raise ValueError("计算终端储能价值时没有有限电价值。")
    return float(
        params.terminal_value_scale
        * params.discharge_efficiency
        * np.median(values)
    )


@dataclass(frozen=True)
class ProblemData:
    dates: list[date]
    time_labels: list[object]
    load_kw: np.ndarray            # (D,144)
    pv_kw: np.ndarray              # (D,144)
    actual_price: np.ndarray       # (D,144)
    pv_hourly: dict[date, dict[int, np.ndarray]]


@dataclass(frozen=True)
class JointScenarioSet:
    net_residual_kw: np.ndarray    # (K,144)
    price_residual: np.ndarray     # (K,144)
    probabilities: np.ndarray      # (K,)
    history_size: int
    medoid_history_days: tuple[int, ...]


@dataclass(frozen=True)
class Q42Plan:
    grid: np.ndarray
    preview_grid: np.ndarray
    expected_cost: float
    expected_emergency_cost: float
    expected_throughput: float
    scenario_count: int
    used_secondary: bool


@dataclass(frozen=True)
class ActualDispatch:
    charge: np.ndarray
    discharge: np.ndarray
    emergency: np.ndarray
    waste: np.ndarray
    energy: np.ndarray
    planned_cost: float
    emergency_cost: float
    total_cost: float
    max_balance_error: float
    max_state_error: float


@dataclass(frozen=True)
class Q42Result:
    date_value: date
    load_pred_kw: np.ndarray
    pv_pred_kw: np.ndarray
    price_pred: np.ndarray
    plan: Q42Plan
    dispatch: ActualDispatch


@dataclass(frozen=True)
class StagePlan:
    grid: np.ndarray
    charge: np.ndarray
    discharge: np.ndarray
    expected_objective: float
    expected_emergency_cost: float
    scenario_count: int


@dataclass
class Q43DayRun:
    date_value: date
    policy_key: str
    initial_grid: np.ndarray
    final_grid: np.ndarray
    executed_charge: np.ndarray
    executed_discharge: np.ndarray
    emergency: np.ndarray
    waste: np.ndarray
    soc: np.ndarray
    adjustment_plus: np.ndarray
    adjustment_minus: np.ndarray
    initial_plan_cost: float
    adjustment_net_cost: float
    emergency_cost: float
    total_cost: float
    emergency_kwh: float
    waste_kwh: float
    grid_versions: dict[int, np.ndarray] = field(default_factory=dict)


def discover_input(parent: Path, exact_name: str, prefix: str) -> Path:
    exact = parent / exact_name
    if exact.exists():
        return exact
    candidates = sorted(p for p in parent.glob(f"{prefix}*.xlsx") if not p.name.startswith("~$"))
    if not candidates:
        raise FileNotFoundError(f"在 {parent} 中找不到 {exact_name} 或 {prefix}*.xlsx")
    return candidates[0]


def parse_date_like(value: object) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y.%m.%d", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", text)
    if m:
        return date(*(int(x) for x in m.groups()))
    raise ValueError(f"无法识别日期：{value!r}")


def parse_release_hour(value: object) -> int:
    if isinstance(value, datetime):
        return value.hour
    if isinstance(value, time):
        return value.hour
    m = re.match(r"(\d{1,2}):", str(value).strip())
    if not m:
        raise ValueError(f"无法识别预报时刻：{value!r}")
    return int(m.group(1))


def format_clock(minutes: int, next_day: bool = True) -> str:
    if minutes == 1440:
        return "0:00+1" if next_day else "24:00"
    if minutes > 1440:
        h, m = divmod(minutes - 1440, 60)
        return f"{h}:{m:02d}+1"
    h, m = divmod(minutes, 60)
    return f"{h}:{m:02d}"


def natural_labels() -> list[str]:
    # A解释：附件的0:10是0:00-0:10区间末点
    return [f"{format_clock(t*10, False)}-{format_clock((t+1)*10, False)}" for t in range(PERIODS)]


def contract_labels() -> list[str]:
    # 与问题3输出口径一致：0:10-0:20 ... 次日0:00-0:10
    labels = []
    for t in range(PERIODS):
        start = 10 + t * 10
        end = start + 10
        labels.append(f"{format_clock(start)}-{format_clock(end)}")
    return labels


def read_actual_year(path: Path) -> tuple[list[date], list[object], np.ndarray, np.ndarray]:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    required = ["小区负载", "光伏发电实际功率"]
    if any(s not in wb.sheetnames for s in required):
        wb.close()
        raise ValueError(f"附件2必须包含工作表：{required}")
    lr = list(wb[required[0]].iter_rows(values_only=True))
    pr = list(wb[required[1]].iter_rows(values_only=True))
    wb.close()
    if len(lr) != len(pr) or len(lr[0]) != PERIODS + 1:
        raise ValueError("附件2维度异常，应为365天×144个10分钟时段。")
    dates = [parse_date_like(r[0]) for r in lr[1:]]
    dates2 = [parse_date_like(r[0]) for r in pr[1:]]
    if dates != dates2:
        raise ValueError("附件2负荷和光伏日期不一致。")
    labels = list(lr[0][1:])
    load = np.asarray([r[1:] for r in lr[1:]], dtype=float)
    pv = np.asarray([r[1:] for r in pr[1:]], dtype=float)
    if not np.all(np.isfinite(load)) or not np.all(np.isfinite(pv)):
        raise ValueError("附件2存在空值/非数值。")
    return dates, labels, load, pv


def read_dynamic_price(path: Path) -> tuple[list[date], list[object], np.ndarray]:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if len(rows) < 2 or len(rows[0]) != PERIODS + 1:
        raise ValueError("附件4应为1列日期+144列实时电价。")
    dates = [parse_date_like(r[0]) for r in rows[1:]]
    labels = list(rows[0][1:])
    price = np.asarray([r[1:] for r in rows[1:]], dtype=float)
    if price.shape[1] != PERIODS or not np.all(np.isfinite(price)):
        raise ValueError("附件4电价矩阵维度错误或含空值。")
    if np.any(price < 0):
        warnings.warn("附件4含负电价；模型允许负价，但紧急购电乘数的经济含义需在论文中说明。")
    return dates, labels, price


def read_pv_hourly_forecasts(path: Path) -> dict[date, dict[int, np.ndarray]]:
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    wb.close()
    result: dict[date, dict[int, np.ndarray]] = {}
    current: date | None = None
    for row in rows:
        if row[0] not in (None, ""):
            current = parse_date_like(row[0])
        if current is None:
            continue
        release = parse_release_hour(row[1])
        values = np.asarray(row[2:26], dtype=float)
        if values.size != 24 or not np.all(np.isfinite(values)):
            raise ValueError(f"附件3 {current} {release}:00 不是24小时完整预测。")
        result.setdefault(current, {})[release] = np.clip(values, 0.0, None)
    return result


def load_problem_data(actual_path: Path, pv_forecast_path: Path, price_path: Path) -> ProblemData:
    dates, labels, load, pv = read_actual_year(actual_path)
    pdates, plabels, price = read_dynamic_price(price_path)
    if dates != pdates:
        raise ValueError("附件2与附件4的日期不一致。")
    if len(labels) != len(plabels):
        raise ValueError("附件2与附件4时间列数不一致。")
    pv_hourly = read_pv_hourly_forecasts(pv_forecast_path)
    return ProblemData(dates, labels, load, pv, price, pv_hourly)


# Walk-forward 预测
def fit_simplex_weights(X: np.ndarray, y: np.ndarray) -> np.ndarray:
    """min ||Xw-y||^2, w>=0, sum(w)=1；3维时枚举内部解、边、顶点。"""
    if X.size == 0:
        return np.full(3, 1/3)
    candidates: list[np.ndarray] = []
    H = X.T @ X
    b = X.T @ y
    KKT = np.block([[H, np.ones((3,1))], [np.ones((1,3)), np.zeros((1,1))]])
    rhs = np.r_[b, 1.0]
    try:
        sol = np.linalg.lstsq(KKT, rhs, rcond=None)[0][:3]
        if np.all(sol >= -1e-10):
            sol = np.clip(sol, 0, None)
            candidates.append(sol / sol.sum())
    except np.linalg.LinAlgError:
        pass
    for k in range(3):
        ij = [i for i in range(3) if i != k]
        a, bb = ij
        z = X[:, a] - X[:, bb]
        target = y - X[:, bb]
        denom = float(z @ z)
        t = float(z @ target / denom) if denom > 1e-14 else 0.5
        t = float(np.clip(t, 0, 1))
        w = np.zeros(3)
        w[a], w[bb] = t, 1-t
        candidates.append(w)
    candidates.extend(np.eye(3))
    return min(candidates, key=lambda w: float(np.sum((X@w-y)**2)))


def build_load_forecasts(data: ProblemData, params: ModelParameters) -> np.ndarray:
    pred = np.full_like(data.load_kw, np.nan, dtype=float)
    for d in range(len(data.dates)):
        if d < 21:
            continue
        train_start = max(21, d - params.load_weight_window)
        Xs, ys = [], []
        for j in range(train_start, d):
            Xs.append(np.column_stack([data.load_kw[j-7], data.load_kw[j-14], data.load_kw[j-21]]))
            ys.append(data.load_kw[j])
        w = fit_simplex_weights(np.vstack(Xs), np.concatenate(ys)) if Xs else np.full(3,1/3)
        pred[d] = w[0]*data.load_kw[d-7] + w[1]*data.load_kw[d-14] + w[2]*data.load_kw[d-21]
        pred[d] = np.clip(pred[d], 0.0, None)
    return pred


def build_price_base_forecasts(data: ProblemData, params: ModelParameters) -> np.ndarray:
    """每天0:00仅用历史电价，1/7/14日同刻凸组合预测未来144格。"""
    pred = np.full_like(data.actual_price, np.nan, dtype=float)
    P = data.actual_price
    for d in range(len(data.dates)):
        if d < 14:
            continue
        train_start = max(14, d - params.price_weight_window)
        Xs, ys = [], []
        for j in range(train_start, d):
            Xs.append(np.column_stack([P[j-1], P[j-7], P[j-14]]))
            ys.append(P[j])
        w = fit_simplex_weights(np.vstack(Xs), np.concatenate(ys)) if Xs else np.full(3,1/3)
        pred[d] = w[0]*P[d-1] + w[1]*P[d-7] + w[2]*P[d-14]
    return pred


def price_forecast_at_release(
    data: ProblemData,
    price_base: np.ndarray,
    day_idx: int,
    release_hour: int,
    params: ModelParameters,
) -> np.ndarray:
    """0:00使用历史基准预测；6/12/18用当天已观测价格对未来作偏差校正。"""
    base = np.asarray(price_base[day_idx], dtype=float).copy()
    if not np.all(np.isfinite(base)):
        raise ValueError(f"{data.dates[day_idx]} 历史不足，无法预测实时电价。")
    if release_hour <= 0:
        return base
    start = release_hour * 6
    left = max(0, start - params.price_bias_slots)
    err = data.actual_price[day_idx, left:start] - base[left:start]
    if err.size:
        weights = np.linspace(0.35, 1.0, err.size)
        bias = float(np.average(err, weights=weights))
        base[start:] += bias
    # 过去价格已经观测到，保留真实值仅用于诊断；优化只取start之后。
    base[:start] = data.actual_price[day_idx, :start]
    return base


def observed_pv_at_release(data: ProblemData, day_idx: int, release_hour: int) -> float:
    if release_hour == 0:
        return float(max(0.0, data.pv_kw[day_idx-1, -1])) if day_idx > 0 else 0.0
    return float(max(0.0, data.pv_kw[day_idx, release_hour*6-1]))


def interpolate_pv_forecast(data: ProblemData, day_idx: int, release_hour: int) -> np.ndarray:
    d = data.dates[day_idx]
    rels = data.pv_hourly.get(d, {})
    if release_hour not in rels:
        raise ValueError(f"附件3缺少 {d} {release_hour}:00 预报。")
    hourly = rels[release_hour]
    release_min = release_hour * 60
    anchor = observed_pv_at_release(data, day_idx, release_hour)
    x = np.asarray([release_min] + [release_min+60*k for k in range(1,25)], dtype=float)
    y = np.concatenate([[anchor], hourly.astype(float)])
    q = np.arange(1, PERIODS+1, dtype=float) * 10.0
    out = np.interp(q, x, y)
    out[q < release_min] = np.nan
    return np.clip(out, 0.0, None)


def base_net_forecast(data: ProblemData, load_pred: np.ndarray, day_idx: int, release_hour: int) -> np.ndarray:
    return load_pred[day_idx] - interpolate_pv_forecast(data, day_idx, release_hour)


def build_tail_forecasts(
    data: ProblemData,
    day_idx: int,
    lookahead_days: int,
    fallback_net_kw: np.ndarray,
    fallback_price: np.ndarray,
    start_slot: int = 0,
) -> tuple[np.ndarray, np.ndarray]:
    """仅用决策时刻之前的历史数据构造固定长度跨日前视。

    lookahead_days=1时，0:00求解“当天+次日”；6/12/18时额外补足已经
    滚过的时段，使每次优化都覆盖从当前时刻起完整48小时。前视部分只帮助
    确定当天决策，不写入当天结算结果。
    """
    days = max(0, int(lookahead_days))
    if days == 0:
        return np.empty(0, dtype=float), np.empty(0, dtype=float)
    if not 0 <= int(start_slot) < PERIODS:
        raise ValueError("start_slot必须位于[0,143]。")
    fallback_net = np.asarray(fallback_net_kw, dtype=float).reshape(-1)
    fallback_p = np.asarray(fallback_price, dtype=float).reshape(-1)
    if fallback_net.shape != (PERIODS,) or not np.all(np.isfinite(fallback_net)):
        raise ValueError("跨日前视fallback净负荷必须是144个有限值。")
    if fallback_p.shape != (PERIODS,) or not np.all(np.isfinite(fallback_p)):
        raise ValueError("跨日前视fallback电价必须是144个有限值。")

    tail_slots = days * PERIODS + int(start_slot)
    required_future_days = days + (1 if start_slot else 0)
    net_parts: list[np.ndarray] = []
    price_parts: list[np.ndarray] = []
    for step in range(1, required_future_days + 1):
        target_idx = day_idx + step
        net_hist = [
            target_idx - lag for lag in (7, 14, 21)
            if 0 <= target_idx - lag <= day_idx
        ]
        price_hist = [
            target_idx - lag for lag in (1, 7, 14)
            if 0 <= target_idx - lag <= day_idx
        ]
        if net_hist:
            net_hat = (
                np.mean(data.load_kw[net_hist], axis=0)
                - np.mean(data.pv_kw[net_hist], axis=0)
            )
        else:
            net_hat = fallback_net.copy()
        price_hat = (
            np.mean(data.actual_price[price_hist], axis=0)
            if price_hist else fallback_p.copy()
        )
        net_parts.append(np.asarray(net_hat, dtype=float))
        price_parts.append(np.asarray(price_hat, dtype=float))
    return (
        np.concatenate(net_parts)[:tail_slots],
        np.maximum(np.concatenate(price_parts)[:tail_slots], 1e-4),
    )


# k-medoids + 净负荷/价格联合场景
def pairwise_euclidean(X: np.ndarray) -> np.ndarray:
    sq = np.sum(X*X, axis=1, keepdims=True)
    return np.sqrt(np.maximum(sq + sq.T - 2*X@X.T, 0.0))


def k_medoids(X: np.ndarray, k: int, max_iter: int = 50) -> tuple[np.ndarray, np.ndarray]:
    n = X.shape[0]
    if n == 0:
        raise ValueError("k-medoids输入为空。")
    k = max(1, min(k, n))
    D = pairwise_euclidean(X)
    medoids = [int(np.argmin(D.sum(axis=1)))]
    while len(medoids) < k:
        nearest = np.min(D[:, medoids], axis=1)
        nearest[medoids] = -1.0
        medoids.append(int(np.argmax(nearest)))
    medoids = np.asarray(medoids, dtype=int)
    labels = np.argmin(D[:, medoids], axis=1)
    for _ in range(max_iter):
        new = medoids.copy()
        for c in range(k):
            members = np.where(labels == c)[0]
            if members.size:
                sub = D[np.ix_(members, members)]
                new[c] = members[int(np.argmin(sub.sum(axis=1)))]
        new = np.asarray(sorted(set(new.tolist())), dtype=int)
        while new.size < k:
            nearest = np.min(D[:, new], axis=1)
            nearest[new] = -1.0
            new = np.append(new, int(np.argmax(nearest)))
        new_labels = np.argmin(D[:, new], axis=1)
        if np.array_equal(np.sort(medoids), np.sort(new)) and np.array_equal(labels, new_labels):
            medoids, labels = new, new_labels
            break
        medoids, labels = new, new_labels
    return medoids, labels


def build_joint_scenarios(
    data: ProblemData,
    load_pred: np.ndarray,
    price_base: np.ndarray,
    target_day: int,
    release_hour: int,
    params: ModelParameters,
) -> JointScenarioSet:
    start_hist = max(21, target_day - params.residual_days)
    active = release_hour * 6
    hist_days: list[int] = []
    net_res: list[np.ndarray] = []
    price_res: list[np.ndarray] = []
    for h in range(start_hist, target_day):
        if not np.all(np.isfinite(load_pred[h])) or not np.all(np.isfinite(price_base[h])):
            continue
        try:
            nforecast = base_net_forecast(data, load_pred, h, release_hour)
            pforecast = price_forecast_at_release(data, price_base, h, release_hour, params)
        except ValueError:
            continue
        nr = (data.load_kw[h] - data.pv_kw[h]) - nforecast
        pr = data.actual_price[h] - pforecast
        nr[:active] = 0.0
        pr[:active] = 0.0
        if not np.all(np.isfinite(nr[active:])) or not np.all(np.isfinite(pr[active:])):
            continue
        hist_days.append(h)
        net_res.append(nr)
        price_res.append(pr)
    if not net_res:
        return JointScenarioSet(
            np.zeros((1,PERIODS)), np.zeros((1,PERIODS)), np.ones(1), 0, ()
        )
    NR = np.vstack(net_res)
    PR = np.vstack(price_res)
    nseg, pseg = NR[:, active:], PR[:, active:]
    ns = float(np.std(nseg)); ps = float(np.std(pseg))
    X = np.hstack([
        nseg/(ns if ns > 1e-9 else 1.0),
        pseg/(ps if ps > 1e-9 else 1.0),
    ])
    med_rows, labels = k_medoids(X, params.k_scenarios)
    probs = np.asarray([(labels == c).mean() for c in range(len(med_rows))], dtype=float)
    return JointScenarioSet(
        net_residual_kw=NR[med_rows],
        price_residual=PR[med_rows],
        probabilities=probs,
        history_size=len(hist_days),
        medoid_history_days=tuple(hist_days[i] for i in med_rows),
    )


# Q4-2 两阶段随机LP：仅G在0:00锁定，储能为场景/实际运行层
def solve_q42_plan(
    net_pred_kw: np.ndarray,
    price_pred: np.ndarray,
    scenarios: JointScenarioSet,
    params: ModelParameters,
    start_soc: float,
    tail_net_kw: np.ndarray | None = None,
    tail_price: np.ndarray | None = None,
) -> Q42Plan:
    K = len(scenarios.probabilities)
    tail_net = np.asarray(tail_net_kw if tail_net_kw is not None else [], dtype=float).reshape(-1)
    tail_p = np.asarray(tail_price if tail_price is not None else [], dtype=float).reshape(-1)
    if tail_net.size != tail_p.size or not np.all(np.isfinite(tail_net)) or not np.all(np.isfinite(tail_p)):
        raise ValueError("Q4-2跨日前视净负荷和电价必须等长且均为有限值。")
    T = PERIODS + int(tail_net.size)
    current_net = net_pred_kw[None,:] + scenarios.net_residual_kw
    current_price = np.maximum(price_pred[None,:] + scenarios.price_residual, 1e-4)
    if tail_net.size:
        net_s = np.hstack([current_net, np.repeat(tail_net[None,:], K, axis=0)]) * DT_HOURS
        price_s = np.hstack([current_price, np.repeat(tail_p[None,:], K, axis=0)])
    else:
        net_s = current_net * DT_HOURS
        price_s = current_price
    prob = scenarios.probabilities
    expected_price = prob @ price_s

    G0 = 0
    S_SIZE = 5*T + 1  # C,D,H,W,E(145)
    n_vars = T + K*S_SIZE

    def off(k: int):
        b = T + k*S_SIZE
        c=b; d=c+T; h=d+T; w=h+T; e=w+T
        return c,d,h,w,e

    Aeq = lil_matrix((K*2*T, n_vars), dtype=float)
    beq = np.zeros(K*2*T)
    for k in range(K):
        c0,d0,h0,w0,e0 = off(k)
        for t in range(T):
            r = k*2*T+t
            Aeq[r,G0+t]=1; Aeq[r,c0+t]=-1; Aeq[r,d0+t]=1; Aeq[r,h0+t]=1; Aeq[r,w0+t]=-1
            beq[r]=net_s[k,t]
            rr = k*2*T+T+t
            Aeq[rr,e0+t]=-1; Aeq[rr,e0+t+1]=1
            Aeq[rr,c0+t]=-params.charge_efficiency
            Aeq[rr,d0+t]=1/params.discharge_efficiency

    bounds: list[tuple[float|None,float|None]] = [(0,None)]*T
    for _ in range(K):
        bounds += [(0,params.max_energy_per_slot)]*T
        bounds += [(0,params.max_energy_per_slot)]*T
        bounds += [(0,None)]*T
        bounds += [(0,None)]*T
        bounds += [(start_soc,start_soc)]
        bounds += [(params.capacity_min,params.capacity_max)]*T

    obj = np.zeros(n_vars)
    obj[:T] = expected_price
    for k in range(K):
        _,_,h0,_,e0 = off(k)
        obj[h0:h0+T] = prob[k]*params.emergency_multiplier*price_s[k]
        obj[e0+T] -= prob[k]*terminal_energy_value(price_s[k], params)

    primary = linprog(obj, A_eq=Aeq.tocsr(), b_eq=beq, bounds=bounds, method="highs")
    if not primary.success:
        raise RuntimeError(f"Q4-2随机规划失败：{primary.message}")

    throughput = np.zeros(n_vars)
    for k in range(K):
        c0,d0,_,_,_ = off(k)
        throughput[c0:c0+T] = prob[k]
        throughput[d0:d0+T] = prob[k]
    tol = max(1e-6, abs(primary.fun)*1e-9)
    secondary = linprog(
        throughput,
        A_ub=csr_matrix(obj.reshape(1,-1)), b_ub=np.asarray([primary.fun+tol]),
        A_eq=Aeq.tocsr(), b_eq=beq, bounds=bounds, method="highs"
    )
    res = secondary if secondary.success else primary
    x = np.where(np.abs(res.x)<EPS,0.0,res.x)
    G = x[:PERIODS].copy()
    preview = x[PERIODS:T].copy()
    exp_em, exp_thr = 0.0,0.0
    for k in range(K):
        c0,d0,h0,_,_ = off(k)
        exp_em += prob[k]*float(params.emergency_multiplier*price_s[k]@x[h0:h0+T])
        exp_thr += prob[k]*float(np.sum(x[c0:c0+T]+x[d0:d0+T]))
    return Q42Plan(
        grid=G, preview_grid=preview, expected_cost=float(primary.fun),
        expected_emergency_cost=exp_em, expected_throughput=exp_thr,
        scenario_count=K, used_secondary=secondary.success,
    )


def solve_actual_dispatch(
    grid: np.ndarray,
    actual_net_kw: np.ndarray,
    actual_price: np.ndarray,
    params: ModelParameters,
    start_soc: float | None = None,
    tail_net_kw: np.ndarray | None = None,
    tail_price: np.ndarray | None = None,
    preview_grid: np.ndarray | None = None,
) -> ActualDispatch:
    start_soc = params.initial_soc if start_soc is None else float(start_soc)
    tail_net = np.asarray(tail_net_kw if tail_net_kw is not None else [], dtype=float).reshape(-1)
    tail_p = np.asarray(tail_price if tail_price is not None else [], dtype=float).reshape(-1)
    preview = np.asarray(preview_grid if preview_grid is not None else [], dtype=float).reshape(-1)
    if not (tail_net.size == tail_p.size == preview.size):
        raise ValueError("Q4-2实际调度的跨日前视数组必须等长。")
    T=PERIODS+int(tail_net.size)
    full_grid=np.concatenate([np.asarray(grid,dtype=float),preview])
    full_price=np.concatenate([np.asarray(actual_price,dtype=float),tail_p])
    net=np.concatenate([np.asarray(actual_net_kw,dtype=float),tail_net])*DT_HOURS
    c0=0; d0=T; h0=2*T; w0=3*T; e0=4*T; nvars=5*T+1
    Aeq=lil_matrix((2*T,nvars),dtype=float); beq=np.zeros(2*T)
    for t in range(T):
        Aeq[t,c0+t]=-1; Aeq[t,d0+t]=1; Aeq[t,h0+t]=1; Aeq[t,w0+t]=-1
        beq[t]=net[t]-full_grid[t]
        r=T+t
        Aeq[r,e0+t]=-1; Aeq[r,e0+t+1]=1
        Aeq[r,c0+t]=-params.charge_efficiency; Aeq[r,d0+t]=1/params.discharge_efficiency
    bounds=[]
    bounds += [(0,params.max_energy_per_slot)]*T
    bounds += [(0,params.max_energy_per_slot)]*T
    bounds += [(0,None)]*T + [(0,None)]*T
    bounds += [(start_soc,start_soc)]
    bounds += [(params.capacity_min,params.capacity_max)]*T
    obj=np.zeros(nvars); obj[h0:h0+T]=params.emergency_multiplier*full_price
    obj[e0+T]-=terminal_energy_value(full_price,params)
    pri=linprog(obj,A_eq=Aeq.tocsr(),b_eq=beq,bounds=bounds,method="highs")
    if not pri.success:
        raise RuntimeError(f"Q4-2实际调度失败：{pri.message}")
    sec_obj=np.zeros(nvars); sec_obj[c0:c0+T]=1; sec_obj[d0:d0+T]=1; sec_obj[w0:w0+T]=1e-6
    tol=max(1e-6,abs(pri.fun)*1e-9)
    sec=linprog(sec_obj,A_ub=csr_matrix(obj.reshape(1,-1)),b_ub=np.asarray([pri.fun+tol]),
                A_eq=Aeq.tocsr(),b_eq=beq,bounds=bounds,method="highs")
    res=sec if sec.success else pri
    x=np.where(np.abs(res.x)<EPS,0.0,res.x)
    C=x[c0:c0+T]; D=x[d0:d0+T]; H=x[h0:h0+T]; W=x[w0:w0+T]; E=x[e0:e0+T+1]
    bal=full_grid+D+H-C-W-net
    state=E[1:]-E[:-1]-params.charge_efficiency*C+D/params.discharge_efficiency
    planned=float(actual_price@np.asarray(grid,dtype=float))
    emergency=float(params.emergency_multiplier*actual_price@H[:PERIODS])
    return ActualDispatch(C[:PERIODS],D[:PERIODS],H[:PERIODS],W[:PERIODS],E[:PERIODS+1],planned,emergency,planned+emergency,
                          float(np.max(np.abs(bal))),float(np.max(np.abs(state))))


def run_q42(
    data: ProblemData,
    load_pred: np.ndarray,
    price_base: np.ndarray,
    params: ModelParameters,
    start_idx: int,
    end_idx: int,
    scenario_cache: dict[tuple[int,int],JointScenarioSet],
    verbose: bool=False,
) -> list[Q42Result]:
    out=[]
    total=end_idx-start_idx+1
    energy=float(params.initial_soc)
    previous_end: float | None = None

    def solve_day(d: int, start_soc: float) -> Q42Result:
        net0=base_net_forecast(data,load_pred,d,0)
        pv0=interpolate_pv_forecast(data,d,0)
        p0=price_forecast_at_release(data,price_base,d,0,params)
        tail_net,tail_p=build_tail_forecasts(
            data,d,params.lookahead_days,net0,p0,start_slot=0
        )
        key=(d,0)
        if key not in scenario_cache:
            scenario_cache[key]=build_joint_scenarios(data,load_pred,price_base,d,0,params)
        plan=solve_q42_plan(
            net0,p0,scenario_cache[key],params,start_soc,tail_net,tail_p
        )
        dispatch=solve_actual_dispatch(
            plan.grid,data.load_kw[d]-data.pv_kw[d],data.actual_price[d],params,
            start_soc,tail_net,tail_p,plan.preview_grid,
        )
        return Q42Result(data.dates[d],load_pred[d].copy(),pv0,p0,plan,dispatch)

    # 预测成熟前沿用题给6000kWh；成熟后从1月22日起连续预热到评价期。
    for d in range(21,start_idx):
        warm=solve_day(d,energy)
        energy=float(warm.dispatch.energy[-1])
        previous_end=energy
        if verbose and (d%10==0 or d==start_idx-1):
            print(f"[Q4-2预热] {warm.date_value} SOC={warm.dispatch.energy[0]:.2f}->{energy:.2f}")

    for n,d in enumerate(range(start_idx,end_idx+1),1):
        result=solve_day(d,energy)
        if previous_end is not None and abs(result.dispatch.energy[0]-previous_end)>1e-6:
            raise RuntimeError("Q4-2相邻日期SOC不连续。")
        out.append(result)
        previous_end=float(result.dispatch.energy[-1])
        energy=previous_end
        if verbose or n==1 or n==total or n%30==0:
            print(f"[Q4-2] {n:3d}/{total} {data.dates[d]} | cost={result.dispatch.total_cost:,.2f} | emergency={result.dispatch.emergency.sum():,.2f} kWh | SOC={result.dispatch.energy[0]:.2f}->{result.dispatch.energy[-1]:.2f}")
    return out


# Q4-3 联合场景 SAA-MPC
def solve_q43_stage(
    *,
    base_net_kw: np.ndarray,
    price_pred: np.ndarray,
    scenarios: JointScenarioSet,
    params: ModelParameters,
    start_slot: int,
    start_soc: float,
    previous_grid: np.ndarray|None,
    previous_charge: np.ndarray|None,
    previous_discharge: np.ndarray|None,
    tail_net_kw: np.ndarray | None = None,
    tail_price: np.ndarray | None = None,
) -> StagePlan:
    n=PERIODS-start_slot
    if n<=0:
        raise ValueError("start_slot越界。")
    active=slice(start_slot,PERIODS)
    probs=scenarios.probabilities
    K=len(probs)
    net_s=(base_net_kw[active][None,:]+scenarios.net_residual_kw[:,active])*DT_HOURS
    price_s=np.maximum(price_pred[active][None,:]+scenarios.price_residual[:,active],1e-4)
    expected_p=probs@price_s
    tail_net=np.asarray(tail_net_kw if tail_net_kw is not None else [],dtype=float).reshape(-1)
    tail_p=np.asarray(tail_price if tail_price is not None else [],dtype=float).reshape(-1)
    if tail_net.size!=tail_p.size or not np.all(np.isfinite(tail_net)) or not np.all(np.isfinite(tail_p)):
        raise ValueError("Q4-3跨日前视净负荷和电价必须等长且均为有限值。")
    m=int(tail_net.size)
    tail_net_kwh=tail_net*DT_HOURS
    is_update=previous_grid is not None

    g0=0; c0=n; d0=2*n; s0=3*n; cur=s0+n+1
    if is_update:
        ap0=cur; am0=ap0+n; cur=am0+n
    else:
        ap0=am0=-1
    hstarts=[]; wstarts=[]
    for _ in range(K):
        hstarts.append(cur); wstarts.append(cur+n); cur+=2*n
    if m:
        tg0=cur; tc0=tg0+m; td0=tc0+m; th0=td0+m; tw0=th0+m; ts0=tw0+m
        cur=ts0+m+1
    else:
        tg0=tc0=td0=th0=tw0=ts0=-1
    nvars=cur
    eqrows=K*n+n+(n if is_update else 0)
    if m:
        eqrows += 1+2*m
    Aeq=lil_matrix((eqrows,nvars),dtype=float); beq=np.zeros(eqrows); row=0
    for k in range(K):
        for i in range(n):
            Aeq[row,g0+i]=1; Aeq[row,d0+i]=1; Aeq[row,c0+i]=-1
            Aeq[row,hstarts[k]+i]=1; Aeq[row,wstarts[k]+i]=-1
            beq[row]=net_s[k,i]; row+=1
    for i in range(n):
        Aeq[row,s0+i]=-1; Aeq[row,s0+i+1]=1
        Aeq[row,c0+i]=-params.charge_efficiency; Aeq[row,d0+i]=1/params.discharge_efficiency
        row+=1
    old_active=None
    if is_update:
        old_active=np.asarray(previous_grid[active],dtype=float)
        for i in range(n):
            Aeq[row,g0+i]=1; Aeq[row,ap0+i]=-1; Aeq[row,am0+i]=1
            beq[row]=old_active[i]; row+=1
    if m:
        # 跨日SOC与当天末端严格衔接，但窗口最终SOC只计价值、不固定数值。
        Aeq[row,ts0]=1; Aeq[row,s0+n]=-1; row+=1
        for i in range(m):
            Aeq[row,tg0+i]=1; Aeq[row,td0+i]=1; Aeq[row,th0+i]=1
            Aeq[row,tc0+i]=-1; Aeq[row,tw0+i]=-1
            beq[row]=tail_net_kwh[i]; row+=1
        for i in range(m):
            Aeq[row,ts0+i]=-1; Aeq[row,ts0+i+1]=1
            Aeq[row,tc0+i]=-params.charge_efficiency
            Aeq[row,td0+i]=1/params.discharge_efficiency
            row+=1
    assert row==eqrows

    bounds=[]
    bounds += [(0,None)]*n
    bounds += [(0,params.max_energy_per_slot)]*n
    bounds += [(0,params.max_energy_per_slot)]*n
    bounds += [(start_soc,start_soc)] + [(params.capacity_min,params.capacity_max)]*n
    if is_update:
        bounds += [(0,None)]*n
        bounds += [(0,float(v)) for v in old_active]
    for _ in range(K):
        bounds += [(0,None)]*n + [(0,None)]*n
    if m:
        bounds += [(0,None)]*m
        bounds += [(0,params.max_energy_per_slot)]*m
        bounds += [(0,params.max_energy_per_slot)]*m
        bounds += [(0,None)]*m + [(0,None)]*m
        bounds += [(params.capacity_min,params.capacity_max)]*(m+1)

    obj=np.zeros(nvars)
    if is_update:
        obj[ap0:ap0+n]=params.increase_multiplier*expected_p
        obj[am0:am0+n]=-params.cancellation_refund_multiplier*expected_p
    else:
        obj[g0:g0+n]=expected_p
    for k in range(K):
        obj[hstarts[k]:hstarts[k]+n]=probs[k]*params.emergency_multiplier*price_s[k]
    if m:
        obj[tg0:tg0+m]=tail_p
        obj[th0:th0+m]=params.emergency_multiplier*tail_p
    terminal_index=ts0+m if m else s0+n
    obj[terminal_index]-=terminal_energy_value(
        np.concatenate([expected_p,tail_p]) if m else expected_p,params
    )
    tie=obj.copy(); tie[c0:c0+n]+=1e-8; tie[d0:d0+n]+=1e-8
    if m:
        tie[tc0:tc0+m]+=1e-8; tie[td0:td0+m]+=1e-8; tie[tw0:tw0+m]+=1e-11
    pri=linprog(tie,A_eq=Aeq.tocsr(),b_eq=beq,bounds=bounds,method="highs")
    if not pri.success:
        raise RuntimeError(f"Q4-3 SAA-MPC失败(start={start_slot})：{pri.message}")
    x=np.where(np.abs(pri.x)<EPS,0.0,pri.x)
    if previous_grid is None:
        G=np.zeros(PERIODS); C=np.zeros(PERIODS); D=np.zeros(PERIODS)
    else:
        G=np.asarray(previous_grid).copy(); C=np.asarray(previous_charge).copy(); D=np.asarray(previous_discharge).copy()
    G[active]=x[g0:g0+n]; C[active]=x[c0:c0+n]; D[active]=x[d0:d0+n]
    exp_em=0.0
    for k in range(K):
        exp_em += probs[k]*float(params.emergency_multiplier*price_s[k]@x[hstarts[k]:hstarts[k]+n])
    return StagePlan(G,C,D,float(obj@x),exp_em,K)


def execute_segment_q43(
    data: ProblemData,
    day_idx: int,
    params: ModelParameters,
    grid: np.ndarray,
    charge: np.ndarray,
    discharge: np.ndarray,
    start: int,
    end: int,
    soc: np.ndarray,
    emergency: np.ndarray,
    waste: np.ndarray,
) -> None:
    net=(data.load_kw[day_idx]-data.pv_kw[day_idx])*DT_HOURS
    for t in range(start,end):
        available=grid[t]+discharge[t]-charge[t]
        gap=net[t]-available
        emergency[t]=max(0.0,gap); waste[t]=max(0.0,-gap)
        soc[t+1]=soc[t]+params.charge_efficiency*charge[t]-discharge[t]/params.discharge_efficiency
        if soc[t+1] < params.capacity_min-1e-5 or soc[t+1] > params.capacity_max+1e-5:
            raise RuntimeError(f"{data.dates[day_idx]} 时段{t} SOC越界：{soc[t+1]}")


def run_q43_one_day(
    data: ProblemData,
    load_pred: np.ndarray,
    price_base: np.ndarray,
    params: ModelParameters,
    day_idx: int,
    policy_key: str,
    scenario_cache: dict[tuple[int,int],JointScenarioSet],
    start_soc: float | None = None,
) -> Q43DayRun:
    start_soc=params.initial_soc if start_soc is None else float(start_soc)
    updates=POLICIES[policy_key]
    d=data.dates[day_idx]
    actual_p=data.actual_price[day_idx]
    def scen(rel: int):
        key=(day_idx,rel)
        if key not in scenario_cache:
            scenario_cache[key]=build_joint_scenarios(data,load_pred,price_base,day_idx,rel,params)
        return scenario_cache[key]

    n0=base_net_forecast(data,load_pred,day_idx,0)
    p0=price_forecast_at_release(data,price_base,day_idx,0,params)
    tail_net,tail_p=build_tail_forecasts(
        data,day_idx,params.lookahead_days,n0,p0,start_slot=0
    )
    plan=solve_q43_stage(base_net_kw=n0,price_pred=p0,scenarios=scen(0),params=params,
                         start_slot=0,start_soc=start_soc,
                         previous_grid=None,previous_charge=None,previous_discharge=None,
                         tail_net_kw=tail_net,tail_price=tail_p)
    initial=plan.grid.copy(); G=plan.grid.copy(); C=plan.charge.copy(); D=plan.discharge.copy()
    versions={0:G.copy()}
    emergency=np.zeros(PERIODS); waste=np.zeros(PERIODS); soc=np.full(PERIODS+1,np.nan); soc[0]=start_soc
    plus_total=np.zeros(PERIODS); minus_total=np.zeros(PERIODS); adj_cost=0.0; executed=0

    for rel in updates:
        start=rel*6
        execute_segment_q43(data,day_idx,params,G,C,D,executed,start,soc,emergency,waste)
        executed=start
        oldG,oldC,oldD=G.copy(),C.copy(),D.copy()
        nn=base_net_forecast(data,load_pred,day_idx,rel)
        pp=price_forecast_at_release(data,price_base,day_idx,rel,params)
        rolling_tail_net,rolling_tail_p=build_tail_forecasts(
            # nn在发布时刻之前按设计含NaN，因此fallback沿用0:00完整预测。
            data,day_idx,params.lookahead_days,n0,p0,start_slot=start
        )
        new=solve_q43_stage(base_net_kw=nn,price_pred=pp,scenarios=scen(rel),params=params,
                            start_slot=start,start_soc=float(soc[start]),
                            previous_grid=oldG,previous_charge=oldC,previous_discharge=oldD,
                            tail_net_kw=rolling_tail_net,tail_price=rolling_tail_p)
        diff=new.grid[start:]-oldG[start:]
        plus=np.maximum(diff,0); minus=np.maximum(-diff,0)
        plus_total[start:]+=plus; minus_total[start:]+=minus
        # 最终真实结算采用附件4对应未来时段的实时价格
        adj_cost += float(params.increase_multiplier*actual_p[start:]@plus -
                          params.cancellation_refund_multiplier*actual_p[start:]@minus)
        G,C,D=new.grid,new.charge,new.discharge
        versions[rel]=G.copy()

    execute_segment_q43(data,day_idx,params,G,C,D,executed,PERIODS,soc,emergency,waste)
    initial_cost=float(actual_p@initial)
    emergency_cost=float(params.emergency_multiplier*actual_p@emergency)
    total=initial_cost+adj_cost+emergency_cost
    return Q43DayRun(
        d,policy_key,initial,G.copy(),C.copy(),D.copy(),emergency,waste,soc,
        plus_total,minus_total,initial_cost,adj_cost,emergency_cost,total,
        float(emergency.sum()),float(waste.sum()),versions
    )


def run_q43_policy(
    data: ProblemData,
    load_pred: np.ndarray,
    price_base: np.ndarray,
    params: ModelParameters,
    start_idx: int,
    end_idx: int,
    policy_key: str,
    scenario_cache: dict[tuple[int,int],JointScenarioSet],
    verbose: bool=False,
    initial_soc: float | None = None,
    initial_previous: Q43DayRun | None = None,
) -> list[Q43DayRun]:
    out=[]; total=end_idx-start_idx+1
    energy=params.initial_soc if initial_soc is None else float(initial_soc)
    previous=initial_previous
    for n,d in enumerate(range(start_idx,end_idx+1),1):
        r=run_q43_one_day(data,load_pred,price_base,params,d,policy_key,scenario_cache,energy)
        if previous is not None and abs(r.soc[0]-previous.soc[-1])>1e-6:
            raise RuntimeError("Q4-3相邻日期SOC不连续。")
        out.append(r)
        previous=r; energy=float(r.soc[-1])
        if verbose or n==1 or n==total or n%30==0:
            print(f"[Q4-3 {POLICY_LABELS[policy_key]}] {n:3d}/{total} {r.date_value} | total={r.total_cost:,.2f} | emergency={r.emergency_kwh:,.2f} kWh | SOC={r.soc[0]:.2f}->{r.soc[-1]:.2f}")
    return out


def build_q43_common_warmup(
    data: ProblemData,
    load_pred: np.ndarray,
    price_base: np.ndarray,
    params: ModelParameters,
    start_idx: int,
    scenario_cache: dict[tuple[int,int],JointScenarioSet],
    verbose: bool=False,
) -> tuple[Q43DayRun | None,float]:
    """预测成熟后用仅0:00策略连续预热，使各候选策略共享评价期初SOC。"""
    previous: Q43DayRun | None=None
    energy=float(params.initial_soc)
    for d in range(21,start_idx):
        r=run_q43_one_day(
            data,load_pred,price_base,params,d,"only_0",scenario_cache,energy
        )
        if previous is not None and abs(r.soc[0]-previous.soc[-1])>1e-6:
            raise RuntimeError("Q4-3预热阶段SOC不连续。")
        previous=r; energy=float(r.soc[-1])
        if verbose and (d%10==0 or d==start_idx-1):
            print(f"[Q4-3共同预热] {r.date_value} SOC={r.soc[0]:.2f}->{energy:.2f}")
    return previous,energy


def summarize_q43(results: list[Q43DayRun]) -> dict[str,float]:
    soc_all=np.concatenate([r.soc for r in results]) if results else np.asarray([np.nan])
    continuity=max((abs(results[i].soc[0]-results[i-1].soc[-1]) for i in range(1,len(results))),default=0.0)
    return {
        "days":float(len(results)),
        "initial_plan_cost_yuan":float(sum(r.initial_plan_cost for r in results)),
        "adjustment_net_cost_yuan":float(sum(r.adjustment_net_cost for r in results)),
        "emergency_cost_yuan":float(sum(r.emergency_cost for r in results)),
        "total_cost_yuan":float(sum(r.total_cost for r in results)),
        "emergency_kwh":float(sum(r.emergency_kwh for r in results)),
        "waste_kwh":float(sum(r.waste_kwh for r in results)),
        "initial_soc_kwh":float(results[0].soc[0]) if results else math.nan,
        "final_soc_kwh":float(results[-1].soc[-1]) if results else math.nan,
        "min_soc_kwh":float(np.nanmin(soc_all)),
        "max_soc_kwh":float(np.nanmax(soc_all)),
        "max_soc_continuity_error_kwh":float(continuity),
    }


def summarize_q42(results: list[Q42Result]) -> dict[str,float]:
    soc_all=np.concatenate([r.dispatch.energy for r in results]) if results else np.asarray([np.nan])
    continuity=max((
        abs(results[i].dispatch.energy[0]-results[i-1].dispatch.energy[-1])
        for i in range(1,len(results))
    ),default=0.0)
    planned=float(sum(r.dispatch.planned_cost for r in results))
    emergency=float(sum(r.dispatch.emergency_cost for r in results))
    return {
        "days":float(len(results)),
        "planned_cost_yuan":planned,
        "emergency_cost_yuan":emergency,
        "total_cost_yuan":planned+emergency,
        "emergency_kwh":float(sum(r.dispatch.emergency.sum() for r in results)),
        "waste_kwh":float(sum(r.dispatch.waste.sum() for r in results)),
        "initial_soc_kwh":float(results[0].dispatch.energy[0]) if results else math.nan,
        "final_soc_kwh":float(results[-1].dispatch.energy[-1]) if results else math.nan,
        "min_soc_kwh":float(np.nanmin(soc_all)),
        "max_soc_kwh":float(np.nanmax(soc_all)),
        "max_soc_continuity_error_kwh":float(continuity),
    }


def price_forecast_accuracy(
    data: ProblemData, price_base: np.ndarray, params: ModelParameters,
    start_idx: int, end_idx: int,
) -> list[dict[str,float]]:
    rows=[]
    for rel in RELEASES:
        errs=[]
        start=rel*6
        for d in range(start_idx,end_idx+1):
            try:
                pred=price_forecast_at_release(data,price_base,d,rel,params)
            except ValueError:
                continue
            errs.append(data.actual_price[d,start:]-pred[start:])
        if errs:
            e=np.concatenate(errs)
            rows.append({
                "release_hour":float(rel),
                "mae_yuan_per_kwh":float(np.mean(np.abs(e))),
                "rmse_yuan_per_kwh":float(np.sqrt(np.mean(e**2))),
                "bias_yuan_per_kwh":float(np.mean(e)),
            })
    return rows


def build_q43_daily_voi(policy_results: dict[str,list[Q43DayRun]]) -> list[dict[str,object]]:
    req=["only_0","0+6","0+6+12","0+6+12+18"]
    if not all(k in policy_results for k in req): return []
    n=min(len(policy_results[k]) for k in req)
    rows=[]
    for i in range(n):
        r0,r6,r12,r18=(policy_results[k][i] for k in req)
        rows.append({
            "date":r0.date_value.isoformat(),
            "voi_6_yuan":r0.total_cost-r6.total_cost,
            "voi_12_yuan":r6.total_cost-r12.total_cost,
            "voi_18_yuan":r12.total_cost-r18.total_cost,
        })
    return rows


def read_q2_fixed_price(path: Path) -> np.ndarray:
    """在问题4内部读取问题2采用的144时段固定电价。"""
    if not path.exists():
        raise FileNotFoundError(f"找不到附件1：{path}")
    wb=openpyxl.load_workbook(path,read_only=True,data_only=True)
    try:
        rows=list(wb.active.iter_rows(min_row=2,values_only=True))
    finally:
        wb.close()
    if len(rows)!=PERIODS:
        raise ValueError(f"附件1应有{PERIODS}个时段，实际{len(rows)}个。")
    price=np.asarray([row[1] for row in rows],dtype=float)
    if not np.all(np.isfinite(price)) or np.any(price<0):
        raise ValueError("附件1电价存在空值、非数值或负数。")
    return price


def solve_q2_fixed_endpoint_dispatch(
    fixed_price: np.ndarray,
    grid: np.ndarray,
    actual_load_kw: np.ndarray,
    actual_pv_kw: np.ndarray,
    start_soc: float,
    end_soc: float,
    params: ModelParameters,
) -> tuple[np.ndarray,float]:
    """固定合同及首尾SOC，重放问题2当天的实际调度。"""
    price=np.asarray(fixed_price,dtype=float).reshape(-1)
    grid=np.asarray(grid,dtype=float).reshape(-1)
    load=np.asarray(actual_load_kw,dtype=float).reshape(-1)
    pv=np.asarray(actual_pv_kw,dtype=float).reshape(-1)
    if any(values.size!=PERIODS for values in (price,grid,load,pv)):
        raise ValueError("Q2重放的电价、合同、负荷和光伏均须含144个时段。")
    if not all(np.all(np.isfinite(values)) for values in (price,grid,load,pv)):
        raise ValueError("Q2重放输入含空值或非数值。")
    start_soc=float(start_soc)
    end_soc=float(end_soc)
    if not params.capacity_min<=start_soc<=params.capacity_max:
        raise ValueError("Q2重放的日初SOC超出储能容量边界。")
    if not params.capacity_min<=end_soc<=params.capacity_max:
        raise ValueError("Q2重放的日末SOC超出储能容量边界。")

    # x=[C,D,H,W,E]；合同G固定，只求当天充放电、紧急购电及弃电。
    T=PERIODS
    c0,d0,h0,w0,e0=0,T,2*T,3*T,4*T
    nvars=5*T+1
    net=(load-pv)*DT_HOURS
    Aeq=lil_matrix((2*T,nvars),dtype=float)
    beq=np.zeros(2*T,dtype=float)
    for t in range(T):
        Aeq[t,c0+t]=-1.0
        Aeq[t,d0+t]=1.0
        Aeq[t,h0+t]=1.0
        Aeq[t,w0+t]=-1.0
        beq[t]=net[t]-grid[t]
        r=T+t
        Aeq[r,e0+t]=-1.0
        Aeq[r,e0+t+1]=1.0
        Aeq[r,c0+t]=-params.charge_efficiency
        Aeq[r,d0+t]=1.0/params.discharge_efficiency

    bounds=[]
    bounds += [(0.0,params.max_energy_per_slot)]*T
    bounds += [(0.0,params.max_energy_per_slot)]*T
    bounds += [(0.0,None)]*T
    bounds += [(0.0,None)]*T
    bounds += [(start_soc,start_soc)]
    bounds += [(params.capacity_min,params.capacity_max)]*(T-1)
    bounds += [(end_soc,end_soc)]

    emergency_obj=np.zeros(nvars,dtype=float)
    emergency_obj[h0:h0+T]=params.emergency_multiplier*price
    # 日末SOC已固定；保留常数型末端价值项，以复现问题2两级优化的容差口径。
    emergency_obj[e0+T]=-terminal_energy_value(price,params)
    primary=linprog(
        emergency_obj,A_eq=Aeq.tocsr(),b_eq=beq,bounds=bounds,method="highs"
    )
    if not primary.success:
        raise RuntimeError(f"Q2固定首尾SOC重放失败：{primary.message}")

    secondary_obj=np.zeros(nvars,dtype=float)
    secondary_obj[c0:c0+T]=1.0
    secondary_obj[d0:d0+T]=1.0
    secondary_obj[w0:w0+T]=1e-6
    tolerance=max(1e-6,abs(primary.fun)*1e-9)
    secondary=linprog(
        secondary_obj,
        A_ub=csr_matrix(emergency_obj.reshape(1,-1)),
        b_ub=np.asarray([primary.fun+tolerance]),
        A_eq=Aeq.tocsr(),b_eq=beq,bounds=bounds,method="highs",
    )
    result=secondary if secondary.success else primary
    x=np.where(np.abs(result.x)<EPS,0.0,result.x)
    charge=x[c0:c0+T]
    discharge=x[d0:d0+T]
    emergency=x[h0:h0+T]
    waste=x[w0:w0+T]
    energy=x[e0:e0+T+1]
    balance=grid+discharge+emergency-charge-waste-net
    state=(energy[1:]-energy[:-1]
           -params.charge_efficiency*charge
           +discharge/params.discharge_efficiency)
    if max(float(np.max(np.abs(balance))),float(np.max(np.abs(state))))>1e-5:
        raise RuntimeError("Q2固定首尾SOC重放未通过供需平衡或状态残差检查。")
    return emergency,float(params.emergency_multiplier*price@emergency)


def replay_q2_fixed_price_baseline(
    data: ProblemData,
    expected_dates: list[date],
) -> dict[str,float]:
    path=BASE_DIR.parent/"问题2"/"result2.xlsx"
    if not path.exists():
        raise FileNotFoundError("问题2/result2.xlsx不存在。")
    wb=openpyxl.load_workbook(path,read_only=True,data_only=True)
    try:
        required=("计划购电量","充放电量","紧急购电量")
        if any(name not in wb.sheetnames for name in required):
            raise ValueError("result2.xlsx缺少必要工作表。")
        saved_dates={
            parse_date_like(row[0]) for row in wb["计划购电量"].iter_rows(min_row=2,values_only=True)
            if row[0] is not None
        }
        if saved_dates!=set(expected_dates):
            raise ValueError("问题2基准日期与当前问题4回测日期不一致。")

        fixed_price=read_q2_fixed_price(
            discover_input(BASE_DIR.parent,"附件1.xlsx","附件1")
        )
        q2_params=ModelParameters()

        storage={
            parse_date_like(row[0]):row
            for row in wb["充放电量"].iter_rows(min_row=2,values_only=True)
            if row[0] is not None
        }
        saved_emergency: dict[date,float]={}
        current_date: date | None=None
        for row in wb["紧急购电量"].iter_rows(min_row=2,values_only=True):
            if row[0] is not None:
                current_date=parse_date_like(row[0])
            if current_date is not None and isinstance(row[2],(int,float)):
                saved_emergency[current_date]=saved_emergency.get(current_date,0.0)+float(row[2])

        lookup={d:i for i,d in enumerate(data.dates)}
        planned_cost=emergency_cost=emergency_kwh=0.0
        max_difference=0.0
        for row in wb["计划购电量"].iter_rows(min_row=2,values_only=True):
            if row[0] is None:
                continue
            day=parse_date_like(row[0]); j=lookup[day]
            grid=np.asarray(row[1:PERIODS+1],dtype=float)
            sr=storage.get(day)
            if sr is None or not isinstance(sr[13],(int,float)) or not isinstance(sr[14],(int,float)):
                raise ValueError(f"result2.xlsx缺少{day}的首尾SOC。")
            emergency,day_emergency_cost=solve_q2_fixed_endpoint_dispatch(
                fixed_price,grid,data.load_kw[j],data.pv_kw[j],
                float(sr[13]),float(sr[14]),q2_params,
            )
            difference=abs(float(emergency.sum())-saved_emergency.get(day,0.0))
            max_difference=max(max_difference,difference)
            if difference>1e-3:
                raise ValueError(f"Q2固定首尾SOC重放在{day}相差{difference:.6f}kWh。")
            planned_cost+=float(fixed_price@grid)
            emergency_cost+=day_emergency_cost
            emergency_kwh+=float(emergency.sum())
        return {
            "plan":planned_cost,"adjust":0.0,"emergency":emergency_cost,
            "energy":emergency_kwh,"total":planned_cost+emergency_cost,
            "max_replay_error_kwh":max_difference,
        }
    finally:
        wb.close()


def style_num(cell, value: float) -> None:
    cell.value=float(value); cell.number_format="0.0000"; cell.alignment=Alignment(horizontal="center",vertical="center")


def merge_emergency(emergency: np.ndarray, labels: list[str]) -> list[tuple[str,float]]:
    out=[]; t=0
    while t<PERIODS:
        if emergency[t] <= EMERGENCY_THRESHOLD:
            t+=1; continue
        s=t; total=0.0
        while t<PERIODS and emergency[t] > EMERGENCY_THRESHOLD:
            total += float(emergency[t]); t+=1
        if t-s==1:
            label=labels[s]
        else:
            first=labels[s].split("-")[0]; last=labels[t-1].split("-")[-1]
            label=f"{first}-{last}"
        out.append((label,total))
    return out


def _init_sheet_header(ws, headers: list[str]) -> None:
    for c,h in enumerate(headers,1):
        cell=ws.cell(1,c,h); cell.font=Font(name="微软雅黑",bold=True); cell.alignment=Alignment(horizontal="center")
    ws.freeze_panes="B2"; ws.sheet_view.showGridLines=False


def create_q42_workbook(path: Path, results: list[Q42Result], price_acc: list[dict[str,float]], params: ModelParameters) -> None:
    wb=Workbook(); ws0=wb.active; ws0.title="计划购电量"; ws1=wb.create_sheet("充放电量"); ws2=wb.create_sheet("紧急购电量"); ws3=wb.create_sheet("年度汇总"); ws4=wb.create_sheet("电价预测精度")
    labs=natural_labels(); _init_sheet_header(ws0,["日期",*labs,"全天计划购电费(元)"])
    for i,r in enumerate(results,2):
        ws0.cell(i,1,r.date_value).number_format="yyyy/m/d"
        for j,v in enumerate(r.plan.grid,2): style_num(ws0.cell(i,j),v)
        style_num(ws0.cell(i,PERIODS+2),r.dispatch.planned_cost)
    headers=["日期"]
    for b in BLOCK_LABELS: headers += [f"{b}充电量(kWh)",f"{b}放电量(kWh)"]
    headers += ["0:00储电量(kWh)","24:00储电量(kWh)"]
    _init_sheet_header(ws1,headers)
    for i,r in enumerate(results,2):
        ws1.cell(i,1,r.date_value).number_format="yyyy/m/d"; col=2
        cb=r.dispatch.charge.reshape(6,24).sum(1); db=r.dispatch.discharge.reshape(6,24).sum(1)
        for c,dv in zip(cb,db): style_num(ws1.cell(i,col),c); style_num(ws1.cell(i,col+1),dv); col+=2
        style_num(ws1.cell(i,col),r.dispatch.energy[0]); style_num(ws1.cell(i,col+1),r.dispatch.energy[-1])
    _init_sheet_header(ws2,["日期","紧急购电时间段","紧急购电量(kWh)"])
    for r in results:
        merged=merge_emergency(r.dispatch.emergency,labs)
        if not merged: merged=[("无",0.0)]
        for j,(lab,val) in enumerate(merged):
            ws2.append([r.date_value if j==0 else None,lab,val]); rr=ws2.max_row
            if j==0: ws2.cell(rr,1).number_format="yyyy/m/d"
            style_num(ws2.cell(rr,3),val)
    s=summarize_q42(results)
    _init_sheet_header(ws3,["指标","数值"])
    for name,val in [("天数",len(results)),("计划购电费(元)",s['planned_cost_yuan']),("紧急购电费(元)",s['emergency_cost_yuan']),("总费用(元)",s['total_cost_yuan']),("紧急购电量(kWh)",s['emergency_kwh']),("富余电量(kWh)",s['waste_kwh']),("评价期初SOC(kWh)",s['initial_soc_kwh']),("评价期末SOC(kWh)",s['final_soc_kwh']),("最低SOC(kWh)",s['min_soc_kwh']),("最高SOC(kWh)",s['max_soc_kwh']),("最大跨日SOC误差(kWh)",s['max_soc_continuity_error_kwh']),("固定滚动窗口(h)",(params.lookahead_days+1)*24),("终端价值系数",params.terminal_value_scale)]:
        ws3.append([name,val]); style_num(ws3.cell(ws3.max_row,2),val)
    _init_sheet_header(ws4,["发布时间","MAE(元/kWh)","RMSE(元/kWh)","Bias(元/kWh)"])
    for r in price_acc:
        ws4.append([f"{int(r['release_hour']):02d}:00",r['mae_yuan_per_kwh'],r['rmse_yuan_per_kwh'],r['bias_yuan_per_kwh']])
        for c in range(2,5): style_num(ws4.cell(ws4.max_row,c),ws4.cell(ws4.max_row,c).value)
    for ws in wb.worksheets: ws.column_dimensions['A'].width=18
    path.parent.mkdir(parents=True,exist_ok=True); wb.save(path); wb.close()


def create_q43_workbook(path: Path, results: list[Q43DayRun], summary: dict[str,dict[str,float]], price_acc: list[dict[str,float]], voi: list[dict[str,object]], params: ModelParameters) -> None:
    wb=Workbook(); w0=wb.active; w0.title="计划购电量"; w1=wb.create_sheet("调整购电量"); w2=wb.create_sheet("充放电量"); w3=wb.create_sheet("紧急购电量"); w4=wb.create_sheet("策略汇总"); w5=wb.create_sheet("电价预测精度"); w6=wb.create_sheet("逐日VOI"); w7=wb.create_sheet("模型诊断")
    labs=contract_labels(); _init_sheet_header(w0,["日期",*labs,"初始计划购电费(元)"]); _init_sheet_header(w1,["日期",*labs,"调整后合同费用(元)"])
    for i,r in enumerate(results,2):
        for ws in (w0,w1): ws.cell(i,1,r.date_value).number_format="yyyy/m/d"
        for j,v in enumerate(r.initial_grid,2): style_num(w0.cell(i,j),v)
        for j,v in enumerate(r.final_grid,2): style_num(w1.cell(i,j),v)
        style_num(w0.cell(i,PERIODS+2),r.initial_plan_cost); style_num(w1.cell(i,PERIODS+2),r.initial_plan_cost+r.adjustment_net_cost)
    headers=["日期"]
    for b in BLOCK_LABELS: headers += [f"{b}充电量(kWh)",f"{b}放电量(kWh)"]
    headers += ["0:00储电量(kWh)","24:00储电量(kWh)"]
    _init_sheet_header(w2,headers)
    for i,r in enumerate(results,2):
        w2.cell(i,1,r.date_value).number_format="yyyy/m/d"; col=2
        cb=r.executed_charge.reshape(6,24).sum(1); db=r.executed_discharge.reshape(6,24).sum(1)
        for c,dv in zip(cb,db): style_num(w2.cell(i,col),c); style_num(w2.cell(i,col+1),dv); col+=2
        style_num(w2.cell(i,col),r.soc[0]); style_num(w2.cell(i,col+1),r.soc[-1])
    _init_sheet_header(w3,["日期","紧急购电时间段","紧急购电量(kWh)"])
    for r in results:
        merged=merge_emergency(r.emergency,labs) or [("无",0.0)]
        for j,(lab,val) in enumerate(merged):
            w3.append([r.date_value if j==0 else None,lab,val]); rr=w3.max_row
            if j==0: w3.cell(rr,1).number_format="yyyy/m/d"
            style_num(w3.cell(rr,3),val)
    _init_sheet_header(w4,["策略","全年总费用(元)","初始计划费(元)","调整净费用(元)","紧急购电费(元)","紧急购电量(kWh)","富余电量(kWh)","评价期初SOC(kWh)","评价期末SOC(kWh)","最大跨日SOC误差(kWh)"])
    for k in POLICIES:
        if k not in summary: continue
        s=summary[k]; w4.append([POLICY_LABELS[k],s['total_cost_yuan'],s['initial_plan_cost_yuan'],s['adjustment_net_cost_yuan'],s['emergency_cost_yuan'],s['emergency_kwh'],s['waste_kwh'],s['initial_soc_kwh'],s['final_soc_kwh'],s['max_soc_continuity_error_kwh']])
        for c in range(2,11): style_num(w4.cell(w4.max_row,c),w4.cell(w4.max_row,c).value)
    _init_sheet_header(w5,["发布时间","MAE(元/kWh)","RMSE(元/kWh)","Bias(元/kWh)"])
    for r in price_acc:
        w5.append([f"{int(r['release_hour']):02d}:00",r['mae_yuan_per_kwh'],r['rmse_yuan_per_kwh'],r['bias_yuan_per_kwh']])
        for c in range(2,5): style_num(w5.cell(w5.max_row,c),w5.cell(w5.max_row,c).value)
    _init_sheet_header(w6,["日期","6:00边际VOI(元)","12:00边际VOI(元)","18:00边际VOI(元)"])
    for r in voi:
        w6.append([r['date'],r['voi_6_yuan'],r['voi_12_yuan'],r['voi_18_yuan']])
        for c in range(2,5): style_num(w6.cell(w6.max_row,c),w6.cell(w6.max_row,c).value)
    _init_sheet_header(w7,["指标","数值"])
    selected=summarize_q43(results)
    for name,val in [("6000kWh含义","仅为全期初始SOC"),("SOC边界","跨日连续，不设每日6000kWh终值"),("固定滚动窗口(h)",(params.lookahead_days+1)*24),("终端价值系数",params.terminal_value_scale),("输出策略",POLICY_LABELS[results[0].policy_key] if results else ""),("评价期初SOC(kWh)",selected['initial_soc_kwh']),("评价期末SOC(kWh)",selected['final_soc_kwh']),("最低SOC(kWh)",selected['min_soc_kwh']),("最高SOC(kWh)",selected['max_soc_kwh']),("最大跨日SOC误差(kWh)",selected['max_soc_continuity_error_kwh'])]:
        w7.append([name,val])
        if isinstance(val,(int,float)): style_num(w7.cell(w7.max_row,2),val)
    for ws in wb.worksheets: ws.column_dimensions['A'].width=18
    path.parent.mkdir(parents=True,exist_ok=True); wb.save(path); wb.close()


def try_fill_q42_template(template: Path|None, output: Path, results: list[Q42Result], price_acc: list[dict[str,float]], params: ModelParameters) -> bool:
    """若附件5/result4-2.xlsx具有常见宽表布局，则复制后填写；否则返回False。"""
    if template is None or not template.exists():
        return False
    shutil.copy2(template, output)
    wb=openpyxl.load_workbook(output)
    required=["计划购电量","充放电量","紧急购电量"]
    if any(x not in wb.sheetnames for x in required):
        wb.close(); output.unlink(missing_ok=True); return False
    w0,w1,w2=[wb[x] for x in required]
    if w0.max_column < PERIODS+1:
        wb.close(); output.unlink(missing_ok=True); return False
    # 计划购电量：日期 + 144格；若末尾有费用列则一并填写。
    for i,r in enumerate(results,2):
        w0.cell(i,1,r.date_value).number_format="yyyy/m/d"
        for j,v in enumerate(r.plan.grid,2): style_num(w0.cell(i,j),v)
        if w0.max_column >= PERIODS+3:
            style_num(w0.cell(i,PERIODS+2),float(r.plan.grid.sum()))
            style_num(w0.cell(i,PERIODS+3),r.dispatch.planned_cost)
        elif w0.max_column >= PERIODS+2:
            style_num(w0.cell(i,PERIODS+2),r.dispatch.planned_cost)
    # 充放电量：日期 + 12个分段量 + 2个SOC。
    if w1.max_column == 6:
        if w1.max_row>1: w1.delete_rows(2,w1.max_row-1)
        for r in results:
            cb=r.dispatch.charge.reshape(6,24).sum(1); db=r.dispatch.discharge.reshape(6,24).sum(1)
            for b in range(6):
                w1.append([r.date_value if b==0 else None,BLOCK_LABELS[b],float(cb[b]),float(db[b]),"0:00" if b==0 else ("24:00" if b==1 else None),float(r.dispatch.energy[0]) if b==0 else (float(r.dispatch.energy[-1]) if b==1 else None)])
                rr=w1.max_row
                if b==0: w1.cell(rr,1).number_format="yyyy/m/d"
                for c in (3,4,6):
                    if isinstance(w1.cell(rr,c).value,(int,float)): style_num(w1.cell(rr,c),w1.cell(rr,c).value)
    elif w1.max_column >= 15:
        for i,r in enumerate(results,2):
            w1.cell(i,1,r.date_value).number_format="yyyy/m/d"; col=2
            cb=r.dispatch.charge.reshape(6,24).sum(1); db=r.dispatch.discharge.reshape(6,24).sum(1)
            for cv,dv in zip(cb,db): style_num(w1.cell(i,col),cv); style_num(w1.cell(i,col+1),dv); col+=2
            style_num(w1.cell(i,col),r.dispatch.energy[0]); style_num(w1.cell(i,col+1),r.dispatch.energy[-1])
    # 紧急购电量重写数据区。
    if w2.max_row>1: w2.delete_rows(2,w2.max_row-1)
    labs=natural_labels()
    for r in results:
        merged=merge_emergency(r.dispatch.emergency,labs) or [("无",0.0)]
        for j,(lab,val) in enumerate(merged):
            w2.append([r.date_value if j==0 else None,lab,val]); rr=w2.max_row
            if j==0: w2.cell(rr,1).number_format="yyyy/m/d"
            style_num(w2.cell(rr,3),val)
    # 追加诊断表，不破坏官方模板原工作表。
    for title in ("年度汇总","电价预测精度"):
        if title in wb.sheetnames: del wb[title]
    ws=wb.create_sheet("年度汇总"); _init_sheet_header(ws,["指标","数值"])
    s=summarize_q42(results)
    for name,val in [("天数",len(results)),("计划购电费(元)",s['planned_cost_yuan']),("紧急购电费(元)",s['emergency_cost_yuan']),("总费用(元)",s['total_cost_yuan']),("紧急购电量(kWh)",s['emergency_kwh']),("富余电量(kWh)",s['waste_kwh']),("评价期初SOC(kWh)",s['initial_soc_kwh']),("评价期末SOC(kWh)",s['final_soc_kwh']),("最低SOC(kWh)",s['min_soc_kwh']),("最高SOC(kWh)",s['max_soc_kwh']),("最大跨日SOC误差(kWh)",s['max_soc_continuity_error_kwh']),("固定滚动窗口(h)",(params.lookahead_days+1)*24),("终端价值系数",params.terminal_value_scale)]:
        ws.append([name,val]); style_num(ws.cell(ws.max_row,2),val)
    wa=wb.create_sheet("电价预测精度"); _init_sheet_header(wa,["发布时间","MAE(元/kWh)","RMSE(元/kWh)","Bias(元/kWh)"])
    for r in price_acc:
        wa.append([f"{int(r['release_hour']):02d}:00",r['mae_yuan_per_kwh'],r['rmse_yuan_per_kwh'],r['bias_yuan_per_kwh']])
        for c in range(2,5): style_num(wa.cell(wa.max_row,c),wa.cell(wa.max_row,c).value)
    wb.save(output); wb.close(); return True


def try_fill_q43_template(template: Path|None, output: Path, results: list[Q43DayRun], summary: dict[str,dict[str,float]], price_acc: list[dict[str,float]], voi: list[dict[str,object]], params: ModelParameters) -> bool:
    """若附件5/result4-3.xlsx具有问题3常见宽表布局，则复制后填写。"""
    if template is None or not template.exists():
        return False
    shutil.copy2(template, output)
    wb=openpyxl.load_workbook(output)
    required=["计划购电量","调整购电量","充放电量","紧急购电量"]
    if any(x not in wb.sheetnames for x in required):
        wb.close(); output.unlink(missing_ok=True); return False
    w0,w1,w2,w3=[wb[x] for x in required]
    if w0.max_column < PERIODS+1 or w1.max_column < PERIODS+1:
        wb.close(); output.unlink(missing_ok=True); return False
    for i,r in enumerate(results,2):
        for ws in (w0,w1): ws.cell(i,1,r.date_value).number_format="yyyy/m/d"
        for j,v in enumerate(r.initial_grid,2): style_num(w0.cell(i,j),v)
        for j,v in enumerate(r.final_grid,2): style_num(w1.cell(i,j),v)
        if w0.max_column>=PERIODS+3:
            style_num(w0.cell(i,PERIODS+2),float(r.initial_grid.sum()))
            style_num(w0.cell(i,PERIODS+3),r.initial_plan_cost)
        elif w0.max_column>=PERIODS+2: style_num(w0.cell(i,PERIODS+2),r.initial_plan_cost)
        if w1.max_column>=PERIODS+3:
            style_num(w1.cell(i,PERIODS+2),float(r.final_grid.sum()))
            style_num(w1.cell(i,PERIODS+3),r.initial_plan_cost+r.adjustment_net_cost)
        elif w1.max_column>=PERIODS+2: style_num(w1.cell(i,PERIODS+2),r.initial_plan_cost+r.adjustment_net_cost)
    if w2.max_column==6:
        if w2.max_row>1: w2.delete_rows(2,w2.max_row-1)
        for r in results:
            cb=r.executed_charge.reshape(6,24).sum(1); db=r.executed_discharge.reshape(6,24).sum(1)
            for b in range(6):
                w2.append([r.date_value if b==0 else None,BLOCK_LABELS[b],float(cb[b]),float(db[b]),"0:00" if b==0 else ("24:00" if b==1 else None),float(r.soc[0]) if b==0 else (float(r.soc[-1]) if b==1 else None)])
                rr=w2.max_row
                if b==0: w2.cell(rr,1).number_format="yyyy/m/d"
                for c in (3,4,6):
                    if isinstance(w2.cell(rr,c).value,(int,float)): style_num(w2.cell(rr,c),w2.cell(rr,c).value)
    elif w2.max_column>=15:
        for i,r in enumerate(results,2):
            w2.cell(i,1,r.date_value).number_format="yyyy/m/d"; col=2
            cb=r.executed_charge.reshape(6,24).sum(1); db=r.executed_discharge.reshape(6,24).sum(1)
            for cv,dv in zip(cb,db): style_num(w2.cell(i,col),cv); style_num(w2.cell(i,col+1),dv); col+=2
            style_num(w2.cell(i,col),r.soc[0]); style_num(w2.cell(i,col+1),r.soc[-1])
    if w3.max_row>1: w3.delete_rows(2,w3.max_row-1)
    labs=contract_labels()
    for r in results:
        merged=merge_emergency(r.emergency,labs) or [("无",0.0)]
        for j,(lab,val) in enumerate(merged):
            w3.append([r.date_value if j==0 else None,lab,val]); rr=w3.max_row
            if j==0: w3.cell(rr,1).number_format="yyyy/m/d"
            style_num(w3.cell(rr,3),val)
    for title in ("策略汇总","电价预测精度","逐日VOI","模型诊断"):
        if title in wb.sheetnames: del wb[title]
    ws=wb.create_sheet("策略汇总"); _init_sheet_header(ws,["策略","全年总费用(元)","初始计划费(元)","调整净费用(元)","紧急购电费(元)","紧急购电量(kWh)","富余电量(kWh)","评价期初SOC(kWh)","评价期末SOC(kWh)","最大跨日SOC误差(kWh)"])
    for k in POLICIES:
        if k not in summary: continue
        x=summary[k]; ws.append([POLICY_LABELS[k],x['total_cost_yuan'],x['initial_plan_cost_yuan'],x['adjustment_net_cost_yuan'],x['emergency_cost_yuan'],x['emergency_kwh'],x['waste_kwh'],x['initial_soc_kwh'],x['final_soc_kwh'],x['max_soc_continuity_error_kwh']])
        for c in range(2,11): style_num(ws.cell(ws.max_row,c),ws.cell(ws.max_row,c).value)
    wa=wb.create_sheet("电价预测精度"); _init_sheet_header(wa,["发布时间","MAE(元/kWh)","RMSE(元/kWh)","Bias(元/kWh)"])
    for r in price_acc:
        wa.append([f"{int(r['release_hour']):02d}:00",r['mae_yuan_per_kwh'],r['rmse_yuan_per_kwh'],r['bias_yuan_per_kwh']])
        for c in range(2,5): style_num(wa.cell(wa.max_row,c),wa.cell(wa.max_row,c).value)
    wv=wb.create_sheet("逐日VOI"); _init_sheet_header(wv,["日期","6:00边际VOI(元)","12:00边际VOI(元)","18:00边际VOI(元)"])
    for r in voi:
        wv.append([r['date'],r['voi_6_yuan'],r['voi_12_yuan'],r['voi_18_yuan']])
        for c in range(2,5): style_num(wv.cell(wv.max_row,c),wv.cell(wv.max_row,c).value)
    wd=wb.create_sheet("模型诊断"); _init_sheet_header(wd,["指标","数值"])
    selected=summarize_q43(results)
    for name,val in [("6000kWh含义","仅为全期初始SOC"),("SOC边界","跨日连续，不设每日6000kWh终值"),("固定滚动窗口(h)",(params.lookahead_days+1)*24),("终端价值系数",params.terminal_value_scale),("输出策略",POLICY_LABELS[results[0].policy_key] if results else ""),("评价期初SOC(kWh)",selected['initial_soc_kwh']),("评价期末SOC(kWh)",selected['final_soc_kwh']),("最低SOC(kWh)",selected['min_soc_kwh']),("最高SOC(kWh)",selected['max_soc_kwh']),("最大跨日SOC误差(kWh)",selected['max_soc_continuity_error_kwh'])]:
        wd.append([name,val])
        if isinstance(val,(int,float)): style_num(wd.cell(wd.max_row,2),val)
    wb.save(output); wb.close(); return True


def generate_figures(data, q42, q43_selected, q43_summary, figure_dir, rolling_results=None, q2_baseline=None):
    """正文四图：环境、费用、滚动机制、价格响应。求解与Excel精度不变。

    图形契约：横向定量组合图，白底，600 dpi PNG及可编辑SVG/PDF。
    费用只比较相同回测日期；缺失值不填零。分布图包含空闲时段，
    展示条件关联而非电价的单因素因果效应。
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager, colors
    from matplotlib.patches import Patch
    from matplotlib.ticker import FormatStrFormatter
    fonts = {f.name for f in font_manager.fontManager.ttflist}
    font = next((f for f in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC")
                 if f in fonts), "DejaVu Sans")
    navy, purple, teal, orange, gray = "#355C7D", "#7075A6", "#479C91", "#D6856C", "#A6ADB5"
    figure_dir.mkdir(parents=True, exist_ok=True)
    lookup = {d: i for i, d in enumerate(data.dates)}
    dates = [r.date_value for r in q42]
    price = np.array([data.actual_price[lookup[d]] for d in dates])
    typical = [date(2025,3,20), date(2025,6,21), date(2025,9,23), date(2025,12,21)]
    outputs, captions = [], []
    def save(fig, name):
        for ext in ("png", "svg", "pdf"):
            path = figure_dir / f"{name}.{ext}"
            fig.savefig(path, dpi=600, facecolor="white")
            outputs.append(path)
        plt.close(fig)
    def clean(ax):
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_color("#CCD3DA")
        ax.tick_params(length=3)
        ax.set_axisbelow(True)
        ax.grid(axis="y", color="#EAEDEF", lw=.5)
    def step(ax, edges, values, **kw):
        if not kw.get("fill", False):
            kw.setdefault("baseline", None)
        return ax.stairs(values, edges, **kw)
    style = {"font.family": font, "font.size": 9, "axes.titlesize": 10,
             "axes.labelsize": 9, "xtick.labelsize": 8, "ytick.labelsize": 8,
             "legend.fontsize": 8, "axes.unicode_minus": False,
             "text.color": navy, "axes.labelcolor": navy,
             "xtick.color": "#657381", "ytick.color": "#657381",
             "pdf.fonttype": 42, "svg.fonttype": "none"}
    with plt.rc_context(style):
        # 1. 每小时汇集全年六个10分钟区间，分布保留日际与小时内波动。
        from matplotlib.lines import Line2D
        price_green, price_green_edge = "#2A9D8F", "#1F6F63"
        hourly=[price[:,h*6:(h+1)*6].ravel() for h in range(24)]
        fig,ax=plt.subplots(figsize=(8.2,3.65))
        fig.subplots_adjust(left=.085,right=.985,top=.81,bottom=.15)
        fig.suptitle("实时电价的日内分布",fontsize=13,y=.97)
        positions=np.arange(24)+.5
        for h,values in enumerate(hourly):
            if np.ptp(values)>1e-10:
                vp=ax.violinplot([values],positions=[positions[h]],widths=.76,
                                 showmeans=False,showmedians=False,showextrema=False,
                                 points=100,bw_method=.20)
                for body in vp["bodies"]:
                    body.set(facecolor=price_green,edgecolor=price_green_edge,alpha=.30,linewidth=.65)
            q1,median,q3=np.quantile(values,[.25,.5,.75])
            ax.plot([positions[h]]*2,[q1,q3],lw=2.2,color=price_green,zorder=3)
            ax.scatter(positions[h],median,s=13,color=navy,edgecolor="white",linewidth=.5,zorder=4)
        ax.set(xlim=(0,24),ylim=(min(0,float(price.min())),float(price.max())*1.08),
               xticks=np.arange(0,25,4),xticklabels=[f"{h}:00" for h in range(0,25,4)],
               xlabel="供电时刻",ylabel="实时电价 / (元/kWh)")
        clean(ax);ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
        ax.get_xticklabels()[-1].set_ha("right")
        fig.legend(handles=[Patch(fc=price_green,alpha=.3,label="电价分布"),
                            Line2D([],[],color=price_green,lw=2.2,label="四分位区间"),
                            Line2D([],[],ls="",marker="o",color=navy,markersize=4,label="中位数")],
                   loc="upper center",bbox_to_anchor=(.53,.89),ncol=3,frameon=False)
        save(fig,"fig4_1_dynamic_price_landscape")
        captions.append("图4-1：每小时汇集回测期各日的六个10分钟实际电价，形成24组样本。小提琴在各组实际最小值至最大值内估计密度，带宽因子0.20、等最大宽度，因此宽度仅表示组内相对密度，不能跨小时比较绝对密度；粗线为P25–P75，点为中位数。未改变时间索引、未抽样或删除尾部观测。")

        # 2. 同期、可追溯费用分项；负调整费向零轴下方堆叠。
        records = [None,
                   dict(plan=sum(r.dispatch.planned_cost for r in q42), adjust=0.,
                        emergency=sum(r.dispatch.emergency_cost for r in q42),
                        energy=sum(float(r.dispatch.emergency.sum()) for r in q42)),
                   None,
                   dict(plan=sum(r.initial_plan_cost for r in q43_selected),
                        adjust=sum(r.adjustment_net_cost for r in q43_selected),
                        emergency=sum(r.emergency_cost for r in q43_selected),
                        energy=sum(r.emergency_kwh for r in q43_selected))]
        missing = []
        if q2_baseline is not None:
            records[0]=dict(
                plan=q2_baseline["plan"],adjust=0.0,
                emergency=q2_baseline["emergency"],energy=q2_baseline["energy"],
            )
            captions.append(
                "Q2费用溯源：使用result2.xlsx保存的144时段购电合同及每日首尾SOC，"
                "固定首尾状态重放当天调度；无需重新训练预测或执行48小时随机规划。"
                f"全年最大紧急购电量核验误差为{q2_baseline['max_replay_error_kwh']:.6f} kWh。"
            )
        else:
            missing.append("Q2基准无法核验")
        for problem,slot in ((3,2),):
            path = BASE_DIR.parent / f"问题{problem}" / f"result{problem}.xlsx"
            if not path.exists():
                missing.append(f"Q{problem}结果缺失"); continue
            wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
            try:
                ds = {parse_date_like(row[0]) for row in wb["计划购电量"].iter_rows(min_row=2,values_only=True) if row[0] is not None}
                if ds != set(dates):
                    missing.append(f"Q{problem}统计日期不一致"); continue
                if problem == 3:
                    vals = list(wb["年度策略汇总"].values)
                    rows = [dict(zip(vals[0],v)) for v in vals[1:]]
                    # 与终端表4-3的固定电价基准一致。
                    r = next(r for r in rows if r["policy"] == "0:00+6:00+12:00")
                    records[slot] = dict(plan=r["initial_plan_cost_yuan"],adjust=r["adjustment_net_cost_yuan"],
                                         emergency=r["emergency_cost_yuan"],energy=r["emergency_kwh"])
            except (KeyError, StopIteration, ValueError, TypeError, ImportError, OSError) as exc:
                missing.append(f"Q{problem}基准无法核验")
                print(f"绘图基准Q{problem}未采用：{exc}")
            finally:
                wb.close()
        # 2. 四方案费用构成：扇区仅编码非负费用占比，总额直接标数。
        fig,axes=plt.subplots(1,4,figsize=(8.2,3.75))
        fig.subplots_adjust(left=.025,right=.975,top=.77,bottom=.27,wspace=.16)
        fig.suptitle("四种购电方案的费用构成",fontsize=13,y=.97)
        fig.legend(handles=[Patch(fc=navy,label="计划购电费"),
                            Patch(fc=teal,label="调整净费用"),
                            Patch(fc=orange,label="紧急购电费")],
                   loc="upper center",bbox_to_anchor=(.5,.90),ncol=3,frameon=False)
        for ax,record,name in zip(axes,records,["Q2","Q4-2","Q3","Q4-3"]):
            ax.text(.5,1.015,name,transform=ax.transAxes,ha="center",va="bottom",fontsize=11)
            if record is None:
                ax.text(.5,.5,"基准不可核验",transform=ax.transAxes,ha="center")
                ax.set_axis_off(); continue
            fees=np.array([record[k] for k in ("plan","adjust","emergency")],dtype=float)
            total=float(fees.sum())
            if total>0 and np.all(fees>=0):
                ax.pie(fees,colors=[navy,teal,orange],startangle=90,counterclock=False,
                       radius=1.,wedgeprops=dict(width=.23,edgecolor="white",linewidth=.55))
                ax.text(0,.08,f"{total/10000:,.2f}",ha="center",va="center",
                        fontsize=12,color=navy,fontweight="bold")
                ax.text(0,-.20,"总费用 / 万元",ha="center",va="center",fontsize=7,color="#657381")
            else:
                # 净调整费为负时不能伪造饼图占比，仅列出带符号的真实费用。
                ax.text(.5,.55,f"{total/10000:,.2f}",transform=ax.transAxes,ha="center",fontsize=12)
                ax.text(.5,.35,"含负费用，不绘制占比",transform=ax.transAxes,ha="center",fontsize=7)
                ax.set_axis_off()
            for i,(label,value,col) in enumerate(zip(["计划费","调整费","紧急费"],fees,[navy,teal,orange])):
                y=-.13-i*.115
                ax.text(.06,y,label,transform=ax.transAxes,ha="left",va="center",fontsize=8,color=col)
                ax.text(.94,y,f"{value/10000:,.2f}",transform=ax.transAxes,ha="right",va="center",fontsize=8,color=col)
        fig.text(.5,.035,"单位：万元",ha="center",fontsize=7,color="#657381")
        save(fig,"fig4_2_q42_monthly_cost_risk")
        captions.append("图4-2：四个等尺寸圆环分别展示Q2、Q4-2、Q3和Q4-3的计划费、调整净费用、紧急购电费占比；圆环大小不代表总额，中心与下方数字为真实金额，单位万元。各扇区角度按原始金额计算，不人为放大小占比；若出现负费用则不绘制占比。Q3基准采用6:00、12:00更新策略，Q4-3采用输出Excel策略。预测方法与策略差异亦可能影响结果，不能将方案差异全部归因为电价。"+"；".join(missing))

        # 3. 每个点代表一天，按未执行区间分别计算增购和减购，保留零值。
        runs=rolling_results or q43_selected
        daily=[]
        for hour in (6,12,18):
            pairs=[]
            for r in runs:
                if hour not in r.grid_versions or hour-6 not in r.grid_versions: continue
                diff=np.asarray(r.grid_versions[hour]-r.grid_versions[hour-6])[hour*6:]
                pairs.append((float(np.maximum(-diff,0).sum()),float(np.maximum(diff,0).sum())))
            daily.append(np.asarray(pairs,dtype=float).reshape(-1,2))
        fig,axes=plt.subplots(1,3,figsize=(8.2,3.3),sharex=True,sharey=True)
        fig.subplots_adjust(left=.09,right=.98,top=.73,bottom=.20,wspace=.12)
        fig.suptitle("预报更新后的每日增购与减购",fontsize=13,y=.97)
        upper=max([float(v.max()) for v in daily if v.size]+[1000.])*1.15
        for ax,h,points in zip(axes,(6,12,18),daily):
            ax.set_xscale("symlog",linthresh=100,linscale=.5)
            ax.set_yscale("symlog",linthresh=100,linscale=.5)
            ax.plot([0,upper],[0,upper],ls="--",color="#A9B4BD",lw=.8,zorder=1)
            if points.size:
                reduce=points[:,0]>=points[:,1]
                ax.scatter(points[reduce,0],points[reduce,1],s=13,c=teal,alpha=.45,edgecolors="none",zorder=2)
                ax.scatter(points[~reduce,0],points[~reduce,1],s=13,c=orange,alpha=.45,edgecolors="none",zorder=2)
                mean=points.mean(axis=0)
                ax.scatter(*mean,s=58,marker="D",c=navy,edgecolors="white",linewidths=1,zorder=4)
            else: ax.text(.5,.5,"未启用",transform=ax.transAxes,ha="center")
            ax.set_title(f"{h}:00 更新",fontsize=10,pad=9)
            ax.set(xlim=(-10,upper),ylim=(-10,upper),xlabel="减购电量 / kWh")
            ticks=[v for v in [0,100,1000,10000] if v<upper]
            ax.set_xticks(ticks,labels=[str(v) for v in ticks])
            ax.set_yticks(ticks,labels=[str(v) for v in ticks])
            clean(ax);ax.grid(False);ax.grid(color="#EDF0F2",lw=.45)
            ax.minorticks_off()
        axes[0].set_ylabel("增购电量 / kWh")
        fig.legend(handles=[Line2D([],[],marker="o",ls="",color=teal,label="净减购",markersize=4),
                            Line2D([],[],marker="o",ls="",color=orange,label="净增购",markersize=4),
                            Line2D([],[],marker="D",ls="",color=navy,label="均值",markersize=4),
                            Line2D([],[],ls="--",color="#A9B4BD",label="等量线")],
                   loc="upper center",bbox_to_anchor=(.54,.89),ncol=4,frameon=False,fontsize=7)
        save(fig,"fig4_3_q43_policy_fingerprint")
        captions.append("图4-3：四次更新策略下，每点为一天一次更新的未执行合同修订量；横轴为减购绝对量，纵轴为增购量，不将增减相抵。双轴同尺度，0–100 kWh线性，超过100 kWh为对数，保留全部零值和极值；虚线为增减相等，菱形为算术均值。有效天数（6/12/18时）："+str([len(v) for v in daily])+"。更新共同受负荷、光伏、电价预测和储能状态影响。")
        # 4. 实际电价分位档内净储能功率；保留所有空闲零值。
        p=np.concatenate([data.actual_price[lookup[r.date_value]] for r in q43_selected])
        net=np.concatenate([(r.executed_charge-r.executed_discharge)/DT_HOURS for r in q43_selected])
        cuts=np.quantile(p,[.2,.4,.6,.8])
        bins=np.searchsorted(cuts,p,side="left")
        groups=[net[bins==i] for i in range(5)]
        # 4. 横向箱体与同档位运行比例对齐；空闲时段保留。
        charge=np.concatenate([r.executed_charge for r in q43_selected])
        discharge=np.concatenate([r.executed_discharge for r in q43_selected])
        fig,(ax,activity)=plt.subplots(1,2,figsize=(8.2,3.8),sharey=True,
                                      gridspec_kw={"width_ratios":[1.8,1]})
        fig.subplots_adjust(left=.16,right=.98,top=.71,bottom=.16,wspace=.14)
        fig.suptitle("储能价格响应：功率分布与运行状态",fontsize=13,y=.97)
        bp=ax.boxplot(groups,positions=np.arange(5),orientation="horizontal",widths=.32,patch_artist=True,
                      showfliers=False,whis=(5,95),showmeans=True,
                      meanprops=dict(marker="D",markerfacecolor=navy,markeredgecolor="white",markersize=4),
                      medianprops=dict(color=navy,lw=1.4),
                      whiskerprops=dict(color="#899CA6",lw=.8),capprops=dict(color="#899CA6",lw=.8))
        for patch,fill,edge in zip(bp["boxes"],
                                  ["#BBDDD5","#D0E4DE","#E4E8EA","#EBD4CB","#E4BBAA"],
                                  [teal,teal,"#93A3AE",orange,orange]):
            patch.set(facecolor=fill,edgecolor=edge,linewidth=1.)
        bounds=np.r_[p.min(),cuts,p.max()]
        labels=[f"{name}  {bounds[i]:.2f}–{bounds[i+1]:.2f}" for i,name in enumerate(["低价","较低价","中价","较高价","高价"])]
        simultaneous=(charge>1e-6)&(discharge>1e-6)
        simultaneous_count=int(simultaneous.sum())
        print(f"绘图审计：同时充放电时段 {simultaneous_count}；不修改模型，单独显示该状态。")
        for i in range(5):
            use=bins==i
            # 四类互斥状态，不能把同时充放电重复计入充电和放电。
            ch=100*np.mean((charge[use]>1e-6)&~simultaneous[use]) if use.any() else 0.
            ds=100*np.mean((discharge[use]>1e-6)&~simultaneous[use]) if use.any() else 0.
            both=100*np.mean(simultaneous[use]) if use.any() else 0.
            idle=100-ch-ds-both
            left=0.
            for amount,col in [(ds,orange),(idle,"#E4E8EB"),(ch,teal),(both,purple)]:
                activity.barh(i,amount,left=left,height=.38,color=col,edgecolor="white",lw=.5)
                if amount>=15: activity.text(left+amount/2,i,f"{amount:.2f}",ha="center",va="center",fontsize=7,color="white" if col in (teal,purple) else navy)
                left+=amount
        ax.set(yticks=np.arange(5),yticklabels=labels,xlim=(-5500,5500),xticks=[-5000,0,5000],
               xlabel="净功率 / kW",ylim=(4.6,-.6))
        ax.axvline(0,color="#A8B3BA",lw=.7,ls="--")
        activity.set(xlim=(0,100),xticks=[0,50,100],xlabel="时段占比 / %")
        for panel in (ax,activity):
            clean(panel);panel.grid(False);panel.grid(axis="x",color="#EDF0F2",lw=.5)
        activity.tick_params(labelleft=False,left=False)
        activity.spines["left"].set_visible(False)
        ax.set_title("净储能功率",fontsize=10,pad=10)
        activity.set_title("运行状态",fontsize=10,pad=10)
        fig.legend(handles=[Patch(fc=orange,label="放电"),Patch(fc="#E4E8EB",label="空闲"),
                            Patch(fc=teal,label="充电"),Patch(fc=purple,label="同时充放电"),
                            Line2D([],[],marker="D",ls="",color=navy,label="净功率均值",markersize=4)],
                   loc="upper center",bbox_to_anchor=(.53,.89),ncol=5,frameon=False,fontsize=7)
        save(fig,"fig4_4_storage_price_response")
        captions.append(f"图4-4：输出策略全回测价格按20/40/60/80%分位数分档。左图包含全部空闲零值，箱体P25–P75、中线中位数、菱形均值、须线P5–P95；净功率=(充电量−放电量)/(1/6小时)。右图按同一档位统计互斥的放电/空闲/充电/同时充放电时段比例，数字为百分比，小于15%的段省略文字但保留真实宽度。同时充放电指充、放电量均大于1e-6 kWh，共{simultaneous_count}个时段，未修改原模型结果。价格分档使用未舍入边界，相同边界价归较低档，标签单位元/kWh。条件关联不等于价格单因素因果效应。")
    captions.append("模型口径：问题4-2与问题4-3均采用SOC跨日连续、固定48小时滚动窗口和窗口末端储能价值；6000 kWh仅为全期初始状态，不是每日强制首尾值。图形种类沿用原方案，曲线、费用及储能响应均由修改后的回放结果重新计算。")
    captions.append("读图补充：图3中净减购类含增减相等的边界点（包括零调整日）；等量线为增购量=减购量。图4净功率为充电功率减去放电功率，正值表示净充电，负值表示净放电。")
    (figure_dir/"figure_captions.txt").write_text("\n\n".join(captions),encoding="utf-8")
    return outputs
def print_result_tables(q42: list[Q42Result], q43: list[Q43DayRun], params: ModelParameters, q2_baseline=None) -> None:
    """终端两位小数；固定电价基准仅在日期一致、字段可核实时采用。"""
    import unicodedata
    days = [date(2025,3,20), date(2025,6,21), date(2025,9,23), date(2025,12,21)]
    def fmt(value):
        return f"{value:.2f}" if value is not None else "未提供"
    def table(headers, rows):
        def width(s):
            return sum(0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in s)
        widths = [max(width(r[i]) for r in [headers,*rows])+2 for i in range(len(headers))]
        border = "+" + "+".join("-"*w for w in widths) + "+"
        print(border)
        for row in [headers,*rows]:
            print("|" + "|".join(" "+v+" "*(w-width(v)-1) for v,w in zip(row,widths))+"|")
            print(border)
    m42={r.date_value:r for r in q42}; m43={r.date_value:r for r in q43}
    rows42=[]; rows43=[]
    for d in days:
        label=f"{d.year}/{d.month}/{d.day}"
        r=m42.get(d)
        values=([float(r.plan.grid.sum()),r.dispatch.planned_cost,float(r.dispatch.emergency.sum()),
                 r.dispatch.emergency_cost,r.dispatch.total_cost] if r else None)
        rows42.append([label]+([fmt(v) for v in values] if values else ["未计算"]*5))
        r=m43.get(d)
        values=([float(r.initial_grid.sum()),float(r.final_grid.sum()),r.adjustment_net_cost,
                 r.emergency_kwh,r.emergency_cost,r.total_cost] if r else None)
        rows43.append([label]+([fmt(v) for v in values] if values else ["未计算"]*6))
    print("\n表4-1 波动电价下问题4-2典型日购电结果")
    table(["日期","计划购电量/kWh","计划购电费/元","紧急购电量/kWh","紧急购电费/元","总购电费用/元"],rows42)
    print("\n表4-2 波动电价下问题4-3典型日滚动购电结果")
    table(["日期","0:00计划购电量/kWh","最终购电量/kWh","调整净费用/元",
           "紧急购电量/kWh","紧急购电费/元","总购电费用/元"],rows43)
    if q43:
        print(f"问题4-3采用输出Excel中的策略：{POLICY_LABELS[q43[0].policy_key]}。")
    s42=summarize_q42(q42); s43=summarize_q43(q43)
    print("\n跨日储能状态与滚动窗口诊断")
    table(["模型","评价期初SOC/kWh","评价期末SOC/kWh","最低SOC/kWh","最高SOC/kWh","最大跨日误差/kWh"],[
        ["问题4-2",fmt(s42['initial_soc_kwh']),fmt(s42['final_soc_kwh']),fmt(s42['min_soc_kwh']),fmt(s42['max_soc_kwh']),fmt(s42['max_soc_continuity_error_kwh'])],
        ["问题4-3",fmt(s43['initial_soc_kwh']),fmt(s43['final_soc_kwh']),fmt(s43['min_soc_kwh']),fmt(s43['max_soc_kwh']),fmt(s43['max_soc_continuity_error_kwh'])],
    ])
    print(
        f"注：6000.00 kWh仅是全期初始状态；评价期初SOC由此前连续预热得到。"
        f"优化窗口={(params.lookahead_days+1)*24}小时，窗口末端SOC计入经济价值而不固定为6000。"
    )
    expected=set(m42)
    notes=[]
    def baseline(problem):
        if problem==2 and q2_baseline is not None:
            notes.append(
                "问题2固定电价基准由result2.xlsx的购电合同和首尾SOC快速重放；"
                f"最大紧急电量误差{q2_baseline['max_replay_error_kwh']:.6f}kWh。"
            )
            return q2_baseline["energy"],None,q2_baseline["total"]
        path=BASE_DIR.parent/f"问题{problem}"/f"result{problem}.xlsx"
        if not path.exists():
            notes.append(f"问题{problem}基准文件不存在。")
            return None,None,None
        wb=openpyxl.load_workbook(path,read_only=True,data_only=True)
        try:
            dates={parse_date_like(row[0]) for row in wb["计划购电量"].iter_rows(min_row=2,values_only=True) if row[0] is not None}
            if dates != expected:
                notes.append(f"问题{problem}基准日期与当前回测不一致，未进行比较。")
                return None,None,None
            if problem==3:
                ws=wb["年度策略汇总"]
                records=list(ws.values)
                rows=[dict(zip(records[0],r)) for r in records[1:]]
                chosen=next((r for r in rows if r.get("policy")=="0:00+6:00+12:00"),None)
                if chosen is None:
                    notes.append("问题3缺少0:00+6:00+12:00策略汇总。")
                    return None,None,None
                notes.append("问题3固定电价基准采用0:00+6:00+12:00策略；策略或预测方法差异也可能影响费用变化。")
                return chosen["emergency_kwh"],chosen["adjustment_net_cost_yuan"],chosen["total_cost_yuan"]
            amount=sum(float(row[2]) for row in wb["紧急购电量"].iter_rows(min_row=2,values_only=True)
                       if len(row)>2 and isinstance(row[2],(int,float)))
            notes.append("问题2现有Excel未保存总购电费用，且合并紧急电量不能精确还原分时费用；对应费用与变化率标为未提供。")
            return amount,None,None
        except (KeyError,ValueError,TypeError) as exc:
            notes.append(f"问题{problem}基准字段无法核验：{exc}")
            return None,None,None
        finally:
            wb.close()
    em2,adj2,cost2=baseline(2); em3,adj3,cost3=baseline(3)
    cost42=sum(r.dispatch.total_cost for r in q42); cost43=sum(r.total_cost for r in q43)
    change=lambda cost,base: fmt(100*(cost-base)/base) if base is not None and base!=0 else "未提供"
    print("\n表4-3 固定电价与波动电价下购电策略比较")
    table(["模型","电价条件","紧急购电量/kWh","调整净费用/元","总购电费用/元","相对基准变化/%"],[
        ["问题2","固定电价",fmt(em2),"—",fmt(cost2),"—"],
        ["问题4-2","波动电价",fmt(sum(float(r.dispatch.emergency.sum()) for r in q42)),"—",fmt(cost42),change(cost42,cost2)],
        ["问题3","固定电价",fmt(em3),fmt(adj3),fmt(cost3),"—"],
        ["问题4-3","波动电价",fmt(sum(r.emergency_kwh for r in q43)),fmt(sum(r.adjustment_net_cost for r in q43)),fmt(cost43),change(cost43,cost3)]])
    print("注：变化率=(波动电价费用−对应固定电价费用)/固定电价费用×100%；正值表示费用增加。")
    for note in notes: print("注："+note)


def parse_args() -> argparse.Namespace:
    parent=BASE_DIR.parent
    p=argparse.ArgumentParser(description="C题问题4：动态电价下Q4-2与Q4-3联合求解")
    p.add_argument("--actual",type=Path,default=None,help="附件2.xlsx")
    p.add_argument("--pv-forecast",type=Path,default=None,help="附件3.xlsx")
    p.add_argument("--dynamic-price",type=Path,default=None,help="附件4.xlsx")
    p.add_argument("--template42",type=Path,default=parent/"附件5"/"result4-2.xlsx")
    p.add_argument("--template43",type=Path,default=parent/"附件5"/"result4-3.xlsx")
    p.add_argument("--output42",type=Path,default=BASE_DIR/"result4-2.xlsx")
    p.add_argument("--output43",type=Path,default=BASE_DIR/"result4-3.xlsx")
    p.add_argument("--fig-dir",type=Path,default=BASE_DIR/"figures")
    p.add_argument("--start",default="2025-02-01")
    p.add_argument("--end",default="2025-12-31")
    p.add_argument("--k",type=int,default=7)
    p.add_argument("--residual-days",type=int,default=28)
    p.add_argument("--lookahead-days",type=int,choices=[0,1,2],default=1,
                   help="固定滚动窗口附加天数；1对应48小时窗口")
    p.add_argument("--terminal-value-scale",type=float,default=1.0,
                   help="窗口末端价值系数；lambda_E=系数×放电效率×预测电价中位数")
    p.add_argument("--no-plot",action="store_true")
    p.add_argument("--verbose",action="store_true")
    return p.parse_args()


def main() -> None:
    args=parse_args(); parent=BASE_DIR.parent
    actual=args.actual or discover_input(parent,"附件2.xlsx","附件2")
    pvf=args.pv_forecast or discover_input(parent,"附件3.xlsx","附件3")
    dyn=args.dynamic_price or discover_input(parent,"附件4.xlsx","附件4")
    print("输入文件："); print(" 附件2:",actual); print(" 附件3:",pvf); print(" 附件4:",dyn)
    params=ModelParameters(
        k_scenarios=max(1,args.k),residual_days=max(7,args.residual_days),
        lookahead_days=int(args.lookahead_days),
        terminal_value_scale=float(args.terminal_value_scale),
    )
    if params.terminal_value_scale<0:
        raise ValueError("terminal-value-scale不能为负。")
    data=load_problem_data(actual,pvf,dyn)
    load_pred=build_load_forecasts(data,params); price_base=build_price_base_forecasts(data,params)
    idx={d:i for i,d in enumerate(data.dates)}; sd=datetime.strptime(args.start,"%Y-%m-%d").date(); ed=datetime.strptime(args.end,"%Y-%m-%d").date()
    if sd not in idx or ed not in idx: raise ValueError("起止日期必须存在于附件2/4。")
    s,e=idx[sd],idx[ed]
    if s<22: raise ValueError("至少需要21天历史，建议从2025-02-01开始。")
    if s>e: raise ValueError("start不能晚于end。")

    cache: dict[tuple[int,int],JointScenarioSet]={}
    representative_lambda=terminal_energy_value(data.actual_price[:max(s,1)],params)
    print(
        f"\n储能边界：6000kWh仅为全期初值；SOC跨日连续；"
        f"固定滚动窗口={(params.lookahead_days+1)*24}小时；"
        f"历史电价口径下参考末端价值={representative_lambda:.6f}元/kWh"
    )
    print("\n========== 求解 Q4-2 ==========")
    q42=run_q42(data,load_pred,price_base,params,s,e,cache,args.verbose)
    pacc=price_forecast_accuracy(data,price_base,params,s,e)
    template42=args.template42 if args.template42.exists() else None
    if not try_fill_q42_template(template42,args.output42,q42,pacc,params):
        create_q42_workbook(args.output42,q42,pacc,params)
    q42_total=sum(r.dispatch.total_cost for r in q42)
    print(f"Q4-2 全期总费用：{q42_total:,.2f} 元")
    q2_baseline=None
    try:
        q2_baseline=replay_q2_fixed_price_baseline(data,[r.date_value for r in q42])
        print(
            f"Q2固定电价基准快速核验完成：总费用={q2_baseline['total']:,.2f}元；"
            f"最大紧急电量误差={q2_baseline['max_replay_error_kwh']:.6f}kWh"
        )
    except (FileNotFoundError,KeyError,ValueError,TypeError,RuntimeError,OSError) as exc:
        print(f"Q2固定电价基准暂未采用：{exc}")

    print("\n========== 求解 Q4-3 ==========")
    policies: dict[str,list[Q43DayRun]]={}; summaries: dict[str,dict[str,float]]={}
    common_previous,common_start_soc=build_q43_common_warmup(
        data,load_pred,price_base,params,s,cache,args.verbose
    )
    print(f"Q4-3各候选策略共同评价期初SOC：{common_start_soc:.2f} kWh")
    for key in POLICIES:
        rs=run_q43_policy(
            data,load_pred,price_base,params,s,e,key,cache,args.verbose,
            initial_soc=common_start_soc,initial_previous=common_previous,
        )
        policies[key]=rs; summaries[key]=summarize_q43(rs)
        summaries[key]["rolling_horizon_hours"]=float((params.lookahead_days+1)*24)
        summaries[key]["terminal_value_scale"]=float(params.terminal_value_scale)
    # 与问题3正式模型一致：输出策略预先指定为0+6+12，不能按事后真实费用挑选。
    output_key="0+6+12"
    selected=policies[output_key]
    voi=build_q43_daily_voi(policies)
    template43=args.template43 if args.template43.exists() else None
    if not try_fill_q43_template(template43,args.output43,selected,summaries,pacc,voi,params):
        create_q43_workbook(args.output43,selected,summaries,pacc,voi,params)
    print("\nQ4-3策略比较：")
    for k in POLICIES:
        ss=summaries[k]; print(f" {POLICY_LABELS[k]:<24} {ss['total_cost_yuan']:>14,.2f} 元")
    print(f"预先选定输出策略：{POLICY_LABELS[output_key]}，总费用={summaries[output_key]['total_cost_yuan']:,.2f} 元")

    print_result_tables(q42,selected,params,q2_baseline)
    args.fig_dir.mkdir(parents=True,exist_ok=True)
    if not args.no_plot:
        generate_figures(data,q42,selected,summaries,args.fig_dir,
                         rolling_results=policies.get("0+6+12+18"),
                         q2_baseline=q2_baseline)
    print("\n输出完成：")
    print(" ",args.output42.resolve())
    print(" ",args.output43.resolve())
    print(" ",args.fig_dir.resolve())


if __name__ == "__main__":
    main()
